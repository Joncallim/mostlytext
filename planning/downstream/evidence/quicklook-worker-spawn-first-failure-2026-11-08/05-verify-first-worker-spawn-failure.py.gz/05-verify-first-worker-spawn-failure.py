import hashlib,json,pathlib,plistlib,stat,subprocess,zipfile
root=pathlib.Path(__file__).parent;a=root/'native-first-artifact/javascriptcore-quicklook-capability';repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext';head='abb866566d4b1012c8fda84aa3abf75040f07b6f';base='324155cc9cfb45116d32a2a05c2f0d392507ecea';actual='fe06bb7dcc27b194276c77d8a9c87a7a66a448bb';git=lambda *v:subprocess.check_output(['git',*v],cwd=repo);sha=lambda b:hashlib.sha256(b).hexdigest()
for label,run,conclusion in [('native',42430116954,'failure'),('compliance',42430116919,'success')]:
 r=json.loads((root/(label+'-first-run.json')).read_bytes());assert r['id']==run and r['head_sha']==head and r['run_attempt']==1 and r['conclusion']==conclusion
 with zipfile.ZipFile(root/(label+'-complete-first-workflow-logs.zip')) as z:assert z.testzip() is None
r=json.loads((a/'receipt.json').read_bytes());assert r['checkout']==actual and git('show','-s','--format=%P',actual).decode().split()==[base,head]
assert git('rev-parse',actual+'^{tree}').decode().strip()==git('merge-tree','--write-tree',base,head).decode().splitlines()[0]==git('rev-parse',head+'^{tree}').decode().strip()
assert git('rev-parse',actual+':MacDown2').decode().strip()==git('rev-parse',base+':MacDown2').decode().strip()==r['root_product_tree']
for p,h in r['source_sha256'].items():assert sha(git('show',actual+':'+p))==h,p
for p,h in r['generated_sha256'].items():assert sha((a/'fixture'/p).read_bytes())==h,p
for row in r['compiled_before_test'].values():
 p=a/row['blob'];assert stat.S_ISREG(p.lstat().st_mode) and len(p.read_bytes())==row['bytes'] and sha(p.read_bytes())==row['sha256']
assert len(r['compiled_before_test'])==71
worker=r['compiled_before_test']['worker'];assert worker['sha256']==r['built']['worker_executable_sha256']=='38435f6f2f7c745dd32b823428d13d68da35d6c209127f6df67ded087a39714a'
assert r['built']['entitlements']==plistlib.loads((a/'provider-actual-entitlements.plist').read_bytes())=={'com.apple.security.app-sandbox':True,'com.apple.security.files.user-selected.read-only':True}
assert r['built']['worker_entitlements']==plistlib.loads((a/'worker-actual-entitlements.plist').read_bytes())=={'com.apple.security.app-sandbox':True,'com.apple.security.inherit':True}
code=subprocess.run(['codesign','--display','--entitlements','-','--xml',str(a/worker['blob'])],capture_output=True,check=True);raw=code.stdout if b'<?xml' in code.stdout else code.stderr;assert plistlib.loads(raw[raw.index(b'<?xml'):])==r['built']['worker_entitlements']
summary=json.loads((root/'actual-independent-summary.json').read_bytes());assert {k:summary[k] for k in ['totalTestCount','passedTests','failedTests','skippedTests','expectedFailures']}=={'totalTestCount':3,'passedTests':2,'failedTests':1,'skippedTests':0,'expectedFailures':0}
assert len(summary['testFailures'])==1 and summary['testFailures'][0]['testIdentifierString']=='WorkerFinderTests/testActualInheritedWorkerNormalAndPhysicalDeadline()'
owned=json.loads((a/'owned/status.json').read_bytes());assert owned['returncode']==65 and not owned['timed_out'] and not owned['cancelled'] and owned['app_cleanup_requested']==[]
observer=json.loads((a/'observer-result.json').read_bytes());driver=json.loads((a/'host-ui-driver.json').read_bytes());assert not observer['errors'] and observer['stopped_after_ui'] and not observer['timed_out'] and not observer['stream_forced_cleanup'] and driver['observer_returncode']==0 and driver['observer_forced_cleanup'] is False and driver['ui_supervisor_returncode']==65
stream=(a/'observer-stream.log').read_bytes();assert sha(stream)==observer['stream_sha256'] and len(stream)==observer['stream_bytes']
last=None
for row in observer['snapshots']:
 raw=(a/row['file']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256'];last=json.loads(raw)
messages=last['messages'];fail=[m for m in messages if m.startswith('QL_WORKER_PROBE spawn-refused')];assert fail==['QL_WORKER_PROBE spawn-refused id=3 code=4']
assert not any(m.startswith('QL_WORKER_PROBE child=') for m in messages) and not any(m.startswith('QL_WORKER_PROBE factory') for m in messages)
assert any('QL_WORKER_PROBE executable id=3 sha256='+worker['sha256']==m for m in messages)
for path in ['FinderTests/ColdFinderTests.swift','FinderTests/JSCFinderTests.swift','Provider/JavaScriptCapability.swift','Provider.entitlements']:
 assert git('show',head+':.github/quicklook-jsc-probe/'+path)==git('show',base+':.github/quicklook-jsc-probe/'+path)
proof={'head':head,'actual_checkout':actual,'actual_parents':[base,head],'canonical_inputs':len(r['source_sha256']),'copied_source':len(r['fixture_source_sha256']),'generated':len(r['generated_sha256']),'all_actual_compiled_role_bytes_verified':71,'actual_worker_signature_entitlements_independently_read_from_downloaded_MachO':r['built']['worker_entitlements'],'actual_provider_entitlements_exact_original_two':True,'original_cold_and_JSC_cases':'2PASS; byte-unchanged original source','actual_worker_case':'FAILED before admitted child result; Process.run throws numeric code4','actual_domain_description_underlying':'NOT_CAPTURED in original provider event; numeric4 alone does not establish sandbox denial or any specific cause','actual_worker_executable_hash_before_spawn_matches_downloaded_binary':worker['sha256'],'normal_child_result_and_held_timer_retirement':'NOT_REACHED; no valid child/deadline/factory record','whole_first':'FAIL, no waiver or unchanged retry','actual_owned_UI':'65 normal owned exit; no timeout/force/skip/expected','own_live_observer':'Raw stream and every own-generation snapshot digest bound; stopped/reaped normally despite UI failure','scope':'Exact first failed inherited-worker feasibility only; no new authority, product activation, child admission/retirement, untrusted engine/resource or fullQL-REPLY claim'}
(root/'first-worker-spawn-failure-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof)
