import hashlib,json,pathlib,plistlib,stat,subprocess,zipfile
root=pathlib.Path(__file__).parent;a=root/'native-first-artifact/javascriptcore-quicklook-capability';repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext';head='00cc5af3b4a79beca094b3b3c3b712a355df8bfa';base='38f14a37eb8aa80033f54eb8ba468ecb2630135c';actual='c63e0a951873e71c0ac5f626772184f061e486de';git=lambda *v:subprocess.check_output(['git',*v],cwd=repo);sha=lambda b:hashlib.sha256(b).hexdigest()
for label,run,conclusion in [('native',42432445955,'failure'),('compliance',42432446029,'success')]:
 r=json.loads((root/(label+'-first-run.json')).read_bytes());assert r['id']==run and r['head_sha']==head and r['run_attempt']==1 and r['conclusion']==conclusion
 with zipfile.ZipFile(root/(label+'-complete-first-workflow-logs.zip')) as z:assert z.testzip() is None
r=json.loads((a/'receipt.json').read_bytes());assert r['checkout']==actual and git('show','-s','--format=%P',actual).decode().split()==[base,head]
assert git('rev-parse',actual+'^{tree}').decode().strip()==git('merge-tree','--write-tree',base,head).decode().splitlines()[0]
assert git('rev-parse',actual+':MacDown2').decode().strip()==git('rev-parse',base+':MacDown2').decode().strip()==r['root_product_tree']
for p,h in r['source_sha256'].items():assert sha(git('show',actual+':'+p))==h,p
for p,h in r['generated_sha256'].items():assert sha((a/'fixture'/p).read_bytes())==h,p
for row in r['compiled_before_test'].values():
 p=a/row['blob'];assert stat.S_ISREG(p.lstat().st_mode) and len(p.read_bytes())==row['bytes'] and sha(p.read_bytes())==row['sha256']
assert len(r['compiled_before_test'])==71
worker=r['compiled_before_test']['worker'];assert worker['sha256']==r['built']['worker_executable_sha256']=='38435f6f2f7c745dd32b823428d13d68da35d6c209127f6df67ded087a39714a'
assert r['built']['entitlements']==plistlib.loads((a/'provider-actual-entitlements.plist').read_bytes())=={'com.apple.security.app-sandbox':True,'com.apple.security.files.user-selected.read-only':True}
assert r['built']['worker_entitlements']==plistlib.loads((a/'worker-actual-entitlements.plist').read_bytes())=={'com.apple.security.app-sandbox':True,'com.apple.security.inherit':True}
code=subprocess.run(['codesign','--display','--entitlements','-','--xml',str(a/worker['blob'])],capture_output=True,check=True);raw=code.stdout if b'<?xml' in code.stdout else code.stderr;assert plistlib.loads(raw[raw.index(b'<?xml'):])==r['built']['worker_entitlements']
summary=json.loads((root/'actual-independent-summary.json').read_bytes());assert {k:summary[k] for k in ['totalTestCount','passedTests','failedTests','skippedTests','expectedFailures']}=={'totalTestCount':3,'passedTests':2,'failedTests':1,'skippedTests':0,'expectedFailures':0}
assert len(summary['testFailures'])==1 and summary['testFailures'][0]['testIdentifierString']=='WorkerFinderTests/testActualInheritedWorkerNormalAndPhysicalDeadline()'
owned=json.loads((a/'owned/status.json').read_bytes());assert owned['returncode']==65 and not owned['timed_out'] and not owned['cancelled'] and owned['app_cleanup_requested']==[]
observer=json.loads((a/'observer-result.json').read_bytes());driver=json.loads((a/'host-ui-driver.json').read_bytes());assert not observer['errors'] and observer['stopped_after_ui'] and not observer['timed_out'] and not observer['stream_forced_cleanup'] and driver['observer_returncode']==0 and driver['observer_forced_cleanup'] is False and driver['ui_supervisor_returncode']==65
stream=(a/'observer-stream.log').read_bytes();assert sha(stream)==observer['stream_sha256'] and len(stream)==observer['stream_bytes']
last=None
for row in observer['snapshots']:
 raw=(a/row['file']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256'];last=json.loads(raw)
messages=last['messages'];fail=[m for m in messages if m.startswith('QL_WORKER_PROBE spawn-refused')];assert fail==['QL_WORKER_PROBE spawn-refused id=3 code=4']
assert not any(m.startswith('QL_WORKER_PROBE child=') for m in messages) and not any(m.startswith('QL_WORKER_PROBE factory') for m in messages)
assert any('QL_WORKER_PROBE executable id=3 sha256='+worker['sha256']==m for m in messages)
for path in ['FinderTests/ColdFinderTests.swift','FinderTests/JSCFinderTests.swift','Provider/JavaScriptCapability.swift','Provider.entitlements']:
 assert git('show',head+':.github/quicklook-jsc-probe/'+path)==git('show',base+':.github/quicklook-jsc-probe/'+path)
import importlib.util
spec=importlib.util.spec_from_file_location('actual_preparation','/Volumes/Fast SSD/CORTANA-GitHub/worktrees/github/mostlytext-quicklook-worker-inheritance/.github/scripts/prepare-quicklook-jsc-probe.py');probe=importlib.util.module_from_spec(spec);spec.loader.exec_module(probe)
assert sha(pathlib.Path(spec.origin).read_bytes())==r['source_sha256']['.github/scripts/prepare-quicklook-jsc-probe.py']
generations=probe.replay_live_stream(stream,observer['nonce'])
assert len(generations)==len(observer['snapshots'])
for row,(position,own_messages) in zip(observer['snapshots'],generations):
 snap=json.loads((a/row['file']).read_bytes());assert row['stream_position']==position and snap['messages']==own_messages
assert driver['errors']==["RuntimeError('First actual Finder UI execution failed: 65')"]
errors=probe.decode_worker_spawn_errors(messages,worker['sha256']);assert len(errors)==1
error=errors[0];assert error['provider_pid']==7374 and error['error']['domain']=='NSCocoaErrorDomain' and error['error']['code']==4 and error['underlying']==[]
assert error['unix_permissions']==493 and error['read_access']==0 and error['read_errno']==0 and error['execute_access']==-1 and error['execute_errno']==1
(p if False else root).joinpath('actual-precise-worker-spawn-error.json').write_text(json.dumps(error,indent=2)+'\n')
proof={'actual_precise_spawn_error':error,'diagnostic_retention_bug':'Actual driver records expected UI65 exception in errors; validate_host_recording still rejects all driver.errors, so worker-spawn-errors.json NOT_WRITTEN. Actual bounded complete3chunks/digest successfully decoded independently from validated own-nonce raw stream and snapshots; no rerun required for these facts.','head':head,'actual_checkout':actual,'actual_parents':[base,head],'canonical_inputs':len(r['source_sha256']),'copied_source':len(r['fixture_source_sha256']),'generated':len(r['generated_sha256']),'all_actual_compiled_role_bytes_verified':71,'actual_worker_signature_entitlements_independently_read_from_downloaded_MachO':r['built']['worker_entitlements'],'actual_provider_entitlements_exact_original_two':True,'original_cold_and_JSC_cases':'2PASS; byte-unchanged original source','actual_worker_case':'FAILED before admitted child result; Process.run throws numeric code4','actual_domain_description_underlying':'NSCocoaErrorDomain4 file does not exist; no underlying error. Real X_OK access returns-1/EPERM despite mode0755 and readable bytes; no child admitted. This proves execution access refusal for this embedded file, not its precise OS policy source or universal impossibility of child/XPC architectures.','actual_worker_executable_hash_before_spawn_matches_downloaded_binary':worker['sha256'],'normal_child_result_and_held_timer_retirement':'NOT_REACHED; no valid child/deadline/factory record','whole_first':'FAIL, no waiver or unchanged retry','actual_owned_UI':'65 normal owned exit; no timeout/force/skip/expected','own_live_observer':'Raw stream and every own-generation snapshot digest bound; stopped/reaped normally despite UI failure','scope':'Exact first failed inherited-worker feasibility only; no new authority, product activation, child admission/retirement, untrusted engine/resource or fullQL-REPLY claim'}
(root/'first-worker-spawn-failure-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof)
