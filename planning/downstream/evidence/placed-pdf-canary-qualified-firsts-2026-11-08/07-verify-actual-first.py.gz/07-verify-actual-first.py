import hashlib,importlib.util,json,pathlib,subprocess,zipfile
root=pathlib.Path(__file__).parent
repo=pathlib.Path('/Volumes/Fast SSD/CORTANA-GitHub/worktrees/github/mostlytext-pdf-snapshot-frame-diagnosis')
head='1eb8d9419f2690d78354531800f7a76e8f5f71b2';base='7867621005a65950bb0db994b8cddaa2f5367412';tested='4b17469c1d43860652b0dba5862622b513a9f747'
git=lambda *v:subprocess.check_output(['git',*v],cwd=repo).decode().strip()
sha=lambda b:hashlib.sha256(b).hexdigest()
for label,run in [('native',42447473633),('compliance',42447473478)]:
 d=json.loads((root/(label+'-first-run.json')).read_bytes());assert d['id']==run and d['head_sha']==head and d['run_attempt']==1 and d['status']=='completed' and d['conclusion']=='success'
 with zipfile.ZipFile(root/(label+'-complete-first-workflow-logs.zip')) as z:assert z.testzip() is None
assert git('show','-s','--format=%P',tested)==base+' '+head
assert git('rev-parse',head+'^{tree}')==git('rev-parse',tested+'^{tree}')==git('merge-tree','--write-tree',base,head)
assert git('diff','--name-only',base,head,'--','MacDown2','compliance')==''
a=root/'native-first-artifact/actual-placed-pdf-canary';r=json.loads((a/'placed-pdf-receipt.json').read_bytes())
assert r['checkout']==tested and len(r['source_sha256'])==8 and r['native_returncode']==0 and r['app_GUI_launches']==0 and r['qualified_fixed_oracle'] is True
assert r['host']['uid']==501 and '26.7.2' in r['host']['os'] and 'Xcode 26.0.1' in r['host']['xcode']
for p,h in r['source_sha256'].items():assert sha(subprocess.check_output(['git','show',head+':'+p],cwd=repo))==h
assert sha((a/'read-placed-pdf').read_bytes())==r['compiled_sha256']
path=repo/'.github/scripts/verify-placed-pdf-canary.py';assert path.read_bytes()==subprocess.check_output(['git','show',head+':.github/scripts/verify-placed-pdf-canary.py'],cwd=repo)
spec=importlib.util.spec_from_file_location('frozen_canary',path);probe=importlib.util.module_from_spec(spec);spec.loader.exec_module(probe)
evaluations={}
for name in ['original','corrected']:
 raw=(a/(name+'.pdf')).read_bytes();assert (sha(raw),len(raw))==probe.PDFS[name] and r['pdfs'][name]=={'sha256':sha(raw),'bytes':len(raw)}
 observed=json.loads((a/(name+'-selection.json')).read_bytes());assert observed['sha256']==sha(raw) and observed['bytes']==len(raw)
 result=probe.evaluate(observed);assert result==r['actual_evaluations'][name] and result['page_count']==(2 if name=='original' else 1) and result['short_fixture_accepted']==(name=='corrected');evaluations[name]=result
# Compare actual returned selections, independently of the placement oracle, with the prior native observation.
prior=json.loads(__import__('gzip').decompress((repo/'.github/fixtures/original-canary-selections.json.gz').read_bytes()))
for name in ['original','corrected']:
 observed=json.loads((a/(name+'-selection.json')).read_bytes())
 for original,current in zip(prior['pages'][0]['character_geometry'],observed['pages'][0]['character_geometry']):
  assert original['utf16_index']==current['utf16_index'] and original['raw_index_text']==current['raw_index_text']
  if not original['raw_index_text'].isspace():
   for key in ['selection_text','selection_bounds','selection_present','selection_geometry_state']:assert original[key]==current[key]
 assert len(prior['pages'][0]['character_geometry'])==len(observed['pages'][0]['character_geometry'])
proof={'source':head,'base':base,'actual_tested':tested,'actual_parents':git('show','-s','--format=%P',tested).split(),'source_tested_computed_tree':git('rev-parse',tested+'^{tree}'),'source_bindings':8,'actual_downloaded_compiled_sha256':r['compiled_sha256'],'all_firsts':'PASS','actual_evaluations':evaluations,'all_actual_nonwhitespace_selections_match_prior_original_native_observation':True,'complete_stderr_bytes':(a/'native.stderr').stat().st_size,'complete_stdout_bytes':(a/'native.stdout').stat().st_size,'scope':'Fixed retained-output qualifier only. No product/pin changes, original validator remains failed, no menu/normalQuit/exactRC/release claim. Scoped orthogonal self-review.'}
(root/'actual-first-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
