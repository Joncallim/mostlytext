import hashlib,io,json,pathlib,re,subprocess,zipfile
root=pathlib.Path(__file__).parent;artifacts=root/'42426698984-first-artifact';repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext';head='6cad56275c1d9a71a9ee95daa066bd1fcae68965';sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *v:subprocess.check_output(['git',*v],cwd=repo)
run=json.loads((root/'42426698984-first-run.json').read_bytes());assert run['head_sha']==head and run['run_attempt']==1 and run['conclusion']=='success'
with zipfile.ZipFile(root/'42426698984-complete-first-workflow-logs.zip') as z:assert z.testzip() is None
folders=sorted(artifacts.iterdir());assert len(folders)==10
receipts={a.name:json.loads((a/'receipt.json').read_bytes()) for a in folders};paths=sorted({p for d in receipts.values() for p in d['source_sha256']})
additional=['planning/downstream/native-ui-hosted-batches.json','planning/downstream/native-ui-required-cases.json'];paths=sorted(set(paths+additional));raw=git('cat-file','--batch',) if False else subprocess.check_output(['git','cat-file','--batch'],input=''.join(head+':'+p+'\n' for p in paths).encode(),cwd=repo);stream=io.BytesIO(raw);hashes={};selected={}
for p in paths:
 header=stream.readline().split();assert len(header)==3 and header[1]==b'blob',p;data=stream.read(int(header[2]));assert stream.read(1)==b'\n';hashes[p]=sha(data)
 if p in additional or p.endswith('Package.resolved'):selected[p]=data
plan=json.loads(selected[additional[0]]);manifest=json.loads(selected[additional[1]]);ids=sorted(x['id'] for x in manifest['cases']);assert len(ids)==38 and sorted(c for group in plan['batches'] for c in group['cases'])==ids
pins=json.loads(selected['MacDown2/Packages/MacDownKit/Package.resolved'])['pins'];assert len(pins)==24
proofs=[];passed=[];positives=0
for group in plan['batches']:
 label=group['id'];a=artifacts/('hosted-ui-matrix-'+label);d=receipts[a.name];assert d['checkout']==head and d['pins']==pins and all(hashes[p]==h for p,h in d['source_sha256'].items())
 assert d['batch_contract']['batch']==label and d['batch_contract']['cases']==group['cases'] and d['batch_contract']['all_discovered_ui_ids']==ids
 assert d['passed'] is True and d['errors']==[] and d['execution_started'] is True and d['source_unchanged_after'] is True and d['built_before']==d['built_after']
 for p,h in d['generated_sha256'].items():assert sha((a/'fixture'/p).read_bytes())==h,p
 for p,target in d['fixture_mapping'].items():assert hashes[p]==d['generated_sha256'][target]
 for p,h in d['actual_xctestruns'].items():assert sha((a/p).read_bytes())==h
 assert sha((a/'test-inputs/MacDown2UITests').read_bytes())==d['test_executable_sha256']
 assert d['actual_build_configuration']['CONFIGURATION']=='Debug' and d['actual_build_configuration']['SWIFT_ACTIVE_COMPILATION_CONDITIONS']=='DEBUG' and d['actual_build_configuration']['PRODUCT_BUNDLE_IDENTIFIER']=='app.mostlytext.MostlyText'
 gui=d['actual_gui'];assert gui['uid']==501 and gui['on_console'] and gui['login_done'] and gui['screen_lock_field'] is not True and gui['keyboard_input_source']=='com.apple.keylayout.US'
 assert [c['selected'] for c in d['batch_cases']]==group['cases']
 for result_label,result in d['results'].items():
  raw=subprocess.check_output(['xcrun','xcresulttool','get','test-results','summary','--path',str(a/(result_label+'.xcresult'))]);summary=json.loads(raw);assert summary==result['summary']
  for k,v in {'totalTestCount':1,'passedTests':1,'failedTests':0,'skippedTests':0,'expectedFailures':0}.items():assert type(summary[k]) is int and summary[k]==v
  owned=json.loads((a/(result_label+'-owned/status.json')).read_bytes());assert owned==result['owned'] and owned['returncode']==0 and not owned['timed_out'] and not owned['cancelled'] and owned['app_cleanup_requested']==[]
  identity=json.loads((a/(result_label+'-owned/identity.json')).read_bytes());assert identity['checkout']==head
  selected_id=result['selected'];target,cls,method=selected_id.split('/');pattern=r"Test Case '-\["+re.escape(target)+r'\.'+re.escape(cls)+' '+re.escape(method)+r"\]' ";log=(a/(result_label+'.log')).read_text();assert len(re.findall(pattern+'started',log))==len(re.findall(pattern+'passed',log))==1 and not re.search(pattern+'failed',log)
  assert result['passed'] is True
  if result_label=='positive':positives+=1
  else:assert identity['app_sha256']==d['built_before']['executable_sha256']
 for case in d['batch_cases']:
  assert case['status']=='PASSED' and case['source_and_products_verified_after'] is True and case['app_after']==d['built_before'];passed.append(case['selected'])
 proofs.append({'batch':label,'original_cases':len(group['cases']),'positive_controls':1,'canonical_inputs':len(d['source_sha256']),'generated':len(d['generated_sha256']),'actual_original_test_binary_SHA256':d['test_executable_sha256'],'actual_raw_results':'all original + positive PASS, no skips/expected/timeouts/force'})
 print(label,'complete original/positive raw results, inputs and owned lifecycle verified',flush=True)
assert sorted(passed)==ids and len(passed)==38 and positives==10
proof={'source':head,'actual_native_original_checkout':head,'actual_original_cases':38,'genuine_positive_controls':10,'full_complete_first_workflow':'PASS','batch_proofs':proofs,'limits':'Original ordinary Debug engineering journeys only; not extra/repeated/final/protected/signed acceptance. Original test binaries independently downloaded/hashed; app before/after hashes are runner records, actual app bytes not downloaded.'};(root/'original38-first-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print('ALL38 original +10 genuine positive cases independently verified',flush=True)
