import hashlib,io,json,pathlib,re,subprocess,sys
root=pathlib.Path(__file__).parent;repo=pathlib.Path('/Volumes/Fast SSD/CORTANA-GitHub/mostlytext');head=sys.argv[1];name=sys.argv[2];slug=name.replace('/','--');config=sys.argv[3];pair=sys.argv[4];p=root/name;r=json.loads((p/'receipt.json').read_text());assert r['mutation_pair']==pair and r['configuration']==config and r['testability'] and r['additional_compilation_condition']=='RELEASE_PREVIEW_PROBE'
requests=[head+':'+n for n in sorted(r['source_sha256'])]+[head+':MacDown2/Packages/MacDownKit/Package.resolved'];blobs={};stream=io.BytesIO(subprocess.check_output(['git','cat-file','--batch'],cwd=repo,input=('\n'.join(requests)+'\n').encode()))
for key in requests:
 hdr=stream.readline().split();assert hdr[1]==b'blob',key;blobs[key]=stream.read(int(hdr[2]));assert stream.read(1)==b'\n'
for n,d in r['source_sha256'].items():assert hashlib.sha256(blobs[head+':'+n]).hexdigest()==d,n
tracked=['planning/downstream/evidence/actual-app-hosted-plan-2026-11-07','.github/scripts/preview_compiled_inputs.py','.github/scripts/test-preview-compiled-inputs.py','.github/scripts/test-preview-diagnostic-host.py','.github/scripts/test-preview-native-architecture.py','MacDown2','.github/scripts/verify-preview-grant-probe.py','.github/workflows/preview-grant-probe.yml','.github/scripts/check-preview-parsed-frame.py','.github/scripts/test-preview-grant-tripwire.py','.github/scripts/run-preview-grant-probe.py','.github/scripts/run-owned-app-tests.py','.github/scripts/test-run-owned-app-tests.py']
expected_names=set(subprocess.check_output(['git','ls-tree','-r','--name-only',head,'--',*tracked],cwd=repo,text=True).splitlines());assert expected_names==set(r['source_sha256']), 'Missing/extra tracked input receipt'
assert subprocess.check_output(['git','rev-parse',r['checkout']+'^{tree}'],cwd=repo,text=True).strip()==subprocess.check_output(['git','rev-parse',head+'^{tree}'],cwd=repo,text=True).strip(), 'Checkout tree mismatch'
assert json.loads(blobs[requests[-1]])['pins']==r['pins']
count,suites=57,18
log=(p/'probe.log').read_text()
assert re.search(f'Test run with {count} tests in {suites} suites failed .* with 1 issue',log)
failures=[line for line in log.splitlines() if 'recorded an issue at' in line]
assert len(failures)==1 and 'aNewParsedRevisionReplacesTheLoadWithoutAnotherModelEdit()' in failures[0]
assert 'Mounted Textual never copied its admitted image; final HTML: <p>fixture</p>' in log
assert 'PREVIEW_NETWORK_CONTROL live=true loaded=true deniedRequests=0' in log
initial_identity=json.loads((p/'diagnostics/identity.json').read_text())
assert initial_identity['checkout']==r['checkout']
network=json.loads((p/'network.json').read_text());assert not network['denied_requests'] and '/control' in network['paths'] and '/control-webkit' in network['paths']
assert not (p/'parsed-frame-results.json').exists() and not (p/'selection-probe.log').exists()
import plistlib,stat
assert head=='6cad56275c1d9a71a9ee95daa066bd1fcae68965' and r['checkout']=='a0b06507e4a721ffb84c98c45824c21bf26849c7'
assert r['current_main_baseline']=='427d15fa5da94d4045a02e7f6a005648d09e38c5' and r['diagnostic_only'] is False and r['qualification_candidate'] is True
assert r['resource_trace_enabled'] is True and r['fixture_window_lifetime_observer'] is True and r['renderer_preference_observer'] is False
assert len(r['pins'])==24
phases=['initial'];phase_proofs={};compiled={}
for phase in phases:
 binding=json.loads((p/('compiled-'+phase+'.json')).read_text());verified=json.loads((p/('compiled-'+phase+'-verified.json')).read_text())
 assert binding['phase']==verified['phase']==phase and binding['configuration']==verified['configuration']==config
 assert verified['compiled_inputs_unchanged_after'] is True and verified['actual_owned_app_matches_captured_executable'] is True
 roles={'app_executable','app_info','test_executable','xctestrun','generated_project'}
 if config=='Debug':roles|={'app_debug_dylib','app_preview_dylib'}
 assert set(binding['inputs'])==roles;captured={}
 for role,row in binding['inputs'].items():
  assert row['blob']=='compiled-inputs/blobs/'+row['sha256'];f=p/row['blob'];st=f.lstat();assert stat.S_ISREG(st.st_mode) and st.st_nlink==1 and st.st_size<=256*1024*1024
  raw=f.read_bytes();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'];captured[role]=raw
 info=plistlib.loads(captured['app_info']);plan=plistlib.loads(captured['xctestrun']);target=plan['MacDown2Tests']
 assert info['CFBundleIdentifier']=='app.mostlytext.MostlyText' and info['CFBundleExecutable']=='MacDown2'
 expected={'BlueprintName':'MacDown2Tests','ProductModuleName':'MacDown2Tests','TestHostPath':'__TESTROOT__/'+config+'/MacDown2.app','TestHostBundleIdentifier':'app.mostlytext.MostlyText','TestBundlePath':'__TESTHOST__/Contents/PlugIns/MacDown2Tests.xctest','IsAppHostedTestBundle':True}
 assert all(target[k]==v for k,v in expected.items())
 app=pathlib.PurePosixPath(binding['inputs']['app_executable']['path']).parents[2]
 assert str(app)=='/Users/runner/work/_temp/preview-grant-app/Build/Products/'+config+'/MacDown2.app'
 assert binding['inputs']['test_executable']['path']==str(app/'Contents/PlugIns/MacDown2Tests.xctest/Contents/MacOS/MacDown2Tests')
 if config=='Debug':
  for role,image in [('app_debug_dylib','MacDown2.debug.dylib'),('app_preview_dylib','__preview.dylib')]:assert binding['inputs'][role]['path']==str(app/'Contents/MacOS'/image)
 owned_folder='diagnostics' if phase=='initial' else 'selection-diagnostics' if phase=='selection' else 'parsed-frame-'+phase+'-diagnostics'
 ident=json.loads((p/owned_folder/'identity.json').read_text());owned=json.loads((p/owned_folder/'status.json').read_text())
 assert ident['checkout']==r['checkout'] and ident['app']==binding['inputs']['app_executable']['path'] and ident['app_sha256']==binding['inputs']['app_executable']['sha256']
 assert verified['actual_owned']==owned and owned['returncode']==65 and owned['timed_out'] is False and owned['cancelled'] is False and owned['app_cleanup_requested']==[]
 command=ident['command'];assert command[0]=='xcodebuild' and command.count('test-without-building')==1 and command.count('ONLY_ACTIVE_ARCH=YES')==1 and command[command.index('-destination')+1]=='platform=macOS,arch=arm64'
 assert '-onlyUsePackageVersionsFromResolvedFile' in command and command[command.index('-configuration')+1]==config
 actual_raw=subprocess.check_output(['xcrun','xcresulttool','get','test-results','summary','--path',str(p/('actual-'+phase+'.xcresult'))]);actual=json.loads(actual_raw)
 raw_target=root/(slug+'-'+phase+'-actual-independent-summary.json');raw_target.write_bytes(actual_raw)
 assert actual==verified['actual_summary']==json.loads((p/('actual-'+phase+'-summary.json')).read_text())
 n=count if phase=='initial' else 1 if phase=='selection' or pair=='viewport' else 3;failed=1
 for k,v in {'totalTestCount':n,'passedTests':n-failed,'failedTests':failed,'skippedTests':0,'expectedFailures':0}.items():assert type(actual[k]) is int and actual[k]==v,(phase,k,actual[k])
 testsraw=subprocess.check_output(['xcrun','xcresulttool','get','test-results','tests','--path',str(p/('actual-'+phase+'.xcresult'))]);(root/(slug+'-'+phase+'-actual-independent-tests.json')).write_bytes(testsraw)
 def nodes(rows):
  for row in rows:
   yield row
   yield from nodes(row.get('children',[]))
 cases=[x for x in nodes(json.loads(testsraw)['testNodes']) if x.get('nodeType')=='Test Case'];assert len(cases)==n,(phase,len(cases),n)
 assert sum(x['result']=='Passed' for x in cases)==n-failed and sum(x['result']=='Failed' for x in cases)==failed
 if True:
  wanted='aNewParsedRevisionReplacesTheLoadWithoutAnotherModelEdit()'
  failures=[x for x in cases if x['result']=='Failed'];assert failures[0]['name']==wanted,(pair,failures)
 phase_proofs[phase]={'actual_summary':actual,'raw_result_cases':len(cases),'owned':owned,'downloaded_compiled_roles':{role:row['sha256'] for role,row in binding['inputs'].items()}}
 compiled[phase]=binding
assert subprocess.check_output(['git','show','-s','--format=%P',r['checkout']],cwd=repo,text=True).split()==['324155cc9cfb45116d32a2a05c2f0d392507ecea',head]
marker=re.findall(r'NATIVE_COPY_OWNERSHIP oldAcceptedStale=true fixedRefusedNoWrite=true freshActualWrite=true seeded=(\d+) refused=(\d+) fresh=(\d+)',log)
assert len(marker)==1 and int(marker[0][0])<int(marker[0][1])<int(marker[0][2])
assert next(x for x in cases if x['name']=='aNoWriteNativeCopyCannotReuseAnEarlierImage()')['result']=='Passed'
proof={'source_head':head,'checkout':r['checkout'],'configuration':config,'mutation_pair':pair,'canonical_inputs_verified':len(r['source_sha256']),'pins':24,'actual_first_initial_tests':57,'passed':56,'failed':1,'skips':0,'expected_failures':0,'exact_failed_case':'aNewParsedRevisionReplacesTheLoadWithoutAnotherModelEdit()','actual_native_copy':'<p>fixture</p>; no admitted PNG data','all_actual_initial_compiled_blobs_downloaded_and_digest_verified':True,'actual_raw_summary_and_case_nodes_independently_read':True,'phase_proofs':phase_proofs,'selection_and_mutant_restoration':'NOT_RUN after genuine initial failure','actual_native_copy_ownership_counterexample':{'old_accepts_stale':True,'fixed_refuses_no_write':True,'genuine_fresh_copy':True,'generations':marker[0]},'failure_only_manual_loader_decode':'Not renderer publication/readiness proof','scope':'Actual first Release revision failure preserved, no unchanged retry/deadline waiver/sole cause/native qualification or owner/signed acceptance.'}
(root/(slug+'-first-failure-independently-verified.json')).write_text(json.dumps(proof,indent=2)+'\n');print({k:v for k,v in proof.items() if k!='phase_proofs'})
