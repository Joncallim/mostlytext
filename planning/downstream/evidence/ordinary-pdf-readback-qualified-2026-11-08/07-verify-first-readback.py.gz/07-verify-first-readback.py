import gzip,hashlib,json,pathlib,subprocess,zipfile
from PIL import Image
root=pathlib.Path(__file__).parent;a=root/'native-first-artifact/actual-original-pdf-readback';repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext';head='5d2ab0f7896210c16f097cb7a6f6f41f0bb31675';base='324155cc9cfb45116d32a2a05c2f0d392507ecea';actual='d0560fc1b6e81f0404452dcd23b07fa3b31d2fc2';git=lambda *v:subprocess.check_output(['git',*v],cwd=repo);sha=lambda b:hashlib.sha256(b).hexdigest()
for label,run in [('native',42427273752),('compliance',42427273706)]:
 d=json.loads((root/(label+'-first-run.json')).read_bytes());assert d['id']==run and d['head_sha']==head and d['run_attempt']==1 and d['conclusion']=='success'
 with zipfile.ZipFile(root/(label+'-complete-first-workflow-logs.zip')) as z:assert z.testzip() is None
r=json.loads((a/'pdf-readback-receipt.json').read_bytes());o=json.loads((a/'actual-pdf-readback.json').read_bytes());assert r['checkout']==actual and git('show','-s','--format=%P',actual).decode().split()==[base,head]
assert git('rev-parse',actual+'^{tree}').decode().strip()==git('merge-tree','--write-tree',base,head).decode().splitlines()[0]==git('rev-parse',head+'^{tree}').decode().strip()
assert git('rev-parse',actual+':MacDown2')==git('rev-parse',base+':MacDown2')
for p,h in r['source_sha256'].items():assert sha(git('show',actual+':'+p))==h,p
assert len(r['source_sha256'])==5 and r['app_GUI_launches']==0 and r['diagnostic_only'] is True and r['qualification_candidate'] is False
p='planning/downstream/evidence/ordinary-export-pdf-original-failure-2026-11-08/';manifest=json.loads(git('show',actual+':'+p+'manifest.json'));assert len(manifest['records'])==16
for row in manifest['records']:
 data=gzip.decompress(git('show',actual+':'+p+row['file']));assert len(data)==row['bytes'] and sha(data)==row['sha256']
 if row['original_name']=='ordinary-export.pdf':assert data==(a/'documents/ordinary-export.pdf').read_bytes()
assert r['actual_original_guard']['returncode']==-5 and 'ValidateActualExportPDF.Refusal.invalid' in r['actual_original_guard']['stderr'] and not r['actual_original_guard']['stdout']
assert r['actual_readback']['returncode']==0 and not r['actual_readback']['stderr'] and r['readback_complete'] is True
assert r['pdf_sha256']==o['sha256']==sha((a/'documents/ordinary-export.pdf').read_bytes())=='ce2b5cc91a8a774c894c43d0f1fe56d4f95cce32171a80c8c2b0f70785af0ae6'
assert o['bytes']==16424 and o['diagnostic_only'] is True and o['qualification_candidate'] is False and len(o['pages'])==2
pred=o['original_guard_predicates'];assert pred['exact_raw_canary'] is False and all(v is True for k,v in pred.items() if k!='exact_raw_canary')
assert o['raw_document_text']=='NATIVE\nEXPORT\nCANARY\n_\n_\nA café document with bold and code.\nKey Value\nalpha beta\n'
images=[]
for index,page in enumerate(o['pages']):
 assert page['index']==index and page['media_box']==[0,0,612,792]
 image=Image.open(a/f'actual-pdf-page-{index+1}.png').convert('RGB');assert image.size==(612,792)
 nonwhite=sum(min(pixel)<245 for pixel in image.getdata());images.append({'page':index+1,'PNG_sha256':sha((a/f'actual-pdf-page-{index+1}.png').read_bytes()),'independent_PNG_nonwhite_pixels':nonwhite,'native_raw_raster_nonwhite_pixels':page['actual_raster_nonwhite_pixels']})
 assert (nonwhite>0)==(index==0) and (page['actual_raster_nonwhite_pixels']>0)==(index==0)
assert o['pages'][1]['raw_page_text']==o['pages'][1]['media_box_selection_text']==''
proof={'source':head,'actual_checkout':actual,'base':base,'actual_tree':git('rev-parse',actual+'^{tree}').decode().strip(),'five_canonical_source_bindings_verified':True,'all16_original_failure_records_exact':True,'product_pins_unchanged':True,'complete_native_and_compliance_firsts':'success','actual_original_unchanged_guard':'FAILED -5 Refusal.invalid; retained as counterexample, not whole journey retry/pass','precise_original_failed_predicate':'exact raw canary only; all other original guard predicates true','actual_PDFKit_text':o['raw_document_text'],'pages':images,'actual_app_GUI_launches':0,'diagnostic_only':True,'qualification_candidate':False,'binary_evidence':'Runner records both compiled helper hashes; binaries are not downloaded and no independent binary-byte verification claimed','scope':'Exact original PDFKit extraction/visible media-box selection/raster facts only; two original issues are oracle text-order assumption and real extra blank page. No product generation-path cause, PDF acceptance, normalQuit or finalRC claim.'}
(root/'first-readback-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
