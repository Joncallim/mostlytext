import hashlib,json,pathlib,plistlib,re,subprocess,uuid,zipfile
root=pathlib.Path(__file__).parent
artifact=root/'native-first-artifact/javascriptcore-quicklook-capability'
repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext'
head='82918e3d064981aa995c481c53433b2e73f56968';base='08c29fb2deed890928bc5a82863b9377612d690d';actual='c5a4dd49a5ca97ddb09bdf17c75142d5574f0aee'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
def read(name):return json.loads((artifact/name).read_bytes())
r=read('receipt.json')
for label,run in [('native',42411864430),('compliance',42411864370)]:
 run_record=json.loads((root/(label+'-first-run.json')).read_bytes())
 assert run_record['id']==run and run_record['head_sha']==head and run_record['run_attempt']==1 and run_record['conclusion']=='success' and run_record['status']=='completed'
assert r['checkout']==actual
assert git('show','-s','--format=%P',actual).decode().strip().split()==[base,head]
assert git('merge-tree','--write-tree',base,head).decode().splitlines()[0]==git('rev-parse',actual+'^{tree}').decode().strip()
assert git('diff','--name-only',base,head,'--','MacDown2','.github/quicklook-reply-probe','.github/scripts/prepare-quicklook-reply-probe.py','.github/workflows/quicklook-reply-probe.yml')==b''
assert r['root_product_tree']==git('rev-parse',base+':MacDown2').decode().strip()
for name,digest in r['source_sha256'].items():assert sha(git('show',actual+':'+name))==digest,(name,'canonical')
for name,digest in r['fixture_source_sha256'].items():assert sha((artifact/'fixture'/name).read_bytes())==digest,(name,'copied')
for name,digest in r['generated_sha256'].items():assert sha((artifact/'fixture'/name).read_bytes())==digest,(name,'generated')
for role,row in r['compiled_before_test'].items():
 raw=(artifact/row['blob']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],role
assert len(r['compiled_before_test'])==69 and r['built']==r['built_before_test']
host_role='bundle:QLReplyProbeAutomationHost.app/Contents/MacOS/QLReplyProbeAutomationHost'
assert host_role in r['compiled_before_test']
for bundle in ['QLReplyProbeContainer.app','QLReplyProbeAutomationHost.app','QLReplyProbeFinderTests-Runner.app']:
 assert 'bundle:'+bundle+'/Contents/Info.plist' in r['compiled_before_test']
 assert 'bundle:'+bundle+'/Contents/_CodeSignature/CodeResources' in r['compiled_before_test']
for name in ['Testing','XCTestCore','XCTest','XCTestSupport','XCUIAutomation','XCTAutomationSupport','XCUnit']:
 assert any('Frameworks/'+name+'.framework/' in k for k in r['compiled_before_test'])
provider=artifact/r['compiled_before_test']['provider']['blob']
metadata=subprocess.run(['codesign','--display','--entitlements',':-',str(provider)],capture_output=True,check=True)
(root/'actual-downloaded-provider-entitlements.plist').write_bytes(metadata.stdout)
assert plistlib.loads(metadata.stdout)=={'com.apple.security.app-sandbox':True,'com.apple.security.files.user-selected.read-only':True}
for name in ['mostlytext-ql-reply-static.md','mostlytext-ql-jsc.md']:assert (artifact/name).read_bytes()==b'# Hosted Quick Look fixture\n' and sha((artifact/name).read_bytes())==r['selected_fixture_sha256']
owned=read('owned/status.json');identity=read('owned/identity.json');driver=read('host-ui-driver.json');observer=read('observer-result.json')
assert owned['returncode']==0 and owned['timed_out'] is False and owned['cancelled'] is False and owned['app_cleanup_requested']==[]
assert identity['checkout']==driver['checkout']==observer['checkout']==actual and identity['app_sha256']==r['compiled_before_test']['provider']['sha256']
assert identity['command']==driver['command'][5:] and driver['command'][4]=='--'
assert driver['errors']==observer['errors']==[] and driver['ui_started'] is True and driver['ui_supervisor_returncode']==0
assert driver['observer_returncode']==0 and driver['observer_forced_cleanup'] is False and driver['observer_pid']==observer['pid']
assert observer['mode']=='live-ndjson' and observer['timed_out'] is False and observer['stopped_after_ui'] is True
assert observer['stream_forced_cleanup'] is False and observer['stream_unexpected_exit'] is False and observer['stream_returncode']==-15
assert driver['ui_completed_monotonic']<=driver['observer_stop_requested_monotonic']<=observer['stop_signal_monotonic']<=observer['finished_monotonic']
assert 0<observer['admitted_monotonic']-observer['started_monotonic']<5 and observer['elapsed_seconds']<300
assert observer['stream_command']==['/usr/bin/log','stream','--style','ndjson','--level','info','--predicate','(subsystem == "app.mostlytext.qljscprobe") OR (subsystem == "app.mostlytext.qljscobserver")']
nonce=observer['nonce'];assert str(uuid.UUID(nonce)).upper()==nonce
control_path='/Users/runner/work/_temp/mostlytext-qljsc/observer-control'
assert observer['control_sha256']==r['compiled_before_test']['observer_control']['sha256']
build=read('observer-control-build.json');assert build['returncode']==0 and 'error' not in build and build['binary_sha256']==observer['control_sha256']
assert build['source_sha256']==r['generated_sha256']['ObserverControl.swift']
assert build['command']==['xcrun','swiftc','-O','-swift-version','6','-strict-concurrency=complete','-warnings-as-errors','-target','arm64-apple-macos26.0','-parse-as-library','/Users/runner/work/_temp/mostlytext-qljsc/fixture/ObserverControl.swift','-o',control_path]
assert 1<=len(observer['control_attempts'])<=25
for attempt in observer['control_attempts']:
 assert attempt['command']==[control_path,nonce] and attempt['returncode']==0 and attempt['stdout']==attempt['stderr']==''
 assert observer['started_monotonic']<=attempt['started_monotonic']<=attempt['completed_monotonic']<=observer['admitted_monotonic'] and attempt['completed_monotonic']-attempt['started_monotonic']<3
stream=(artifact/'observer-stream.log').read_bytes();assert len(stream)==observer['stream_bytes'] and sha(stream)==observer['stream_sha256'] and stream.endswith(b'\n')
assert (artifact/'observer-stream-errors.txt').read_bytes()==b''
position=0;messages=[];generations=[];echoes=[];provider_events=[]
for line in stream.splitlines(keepends=True):
 position+=len(line)
 if line.startswith(b'Filtering the log data using '):continue
 event=json.loads(line);assert event['subsystem'] in ['app.mostlytext.qljscprobe','app.mostlytext.qljscobserver'] and event['userID']==501
 if event['subsystem']=='app.mostlytext.qljscobserver':
  assert event['eventMessage']=='QL_OBSERVER_CONTROL nonce='+nonce and event['processImagePath']==control_path
  if not echoes:generations.append((position,[]))
  echoes.append(event)
 else:
  assert echoes and event['processImagePath']==identity['app']
  messages.append(event['eventMessage']);provider_events.append(event);generations.append((position,list(messages)))
assert len(generations)==len(observer['snapshots'])<=128
for index,(row,generation) in enumerate(zip(observer['snapshots'],generations)):
 assert row['file']==f'observer-journal/{index:03d}.json' and row['stream_position']==generation[0]
 raw=(artifact/row['file']).read_bytes();v=json.loads(raw)
 assert len(raw)==row['bytes']<=128*1024 and sha(raw)==row['sha256']
 assert v=={'kind':'mostlytext-qljsc-host-observer','checkout':actual,'sequence':index,'messages':generation[1]}
assert (artifact/'provider-observer.json').read_bytes()==(artifact/observer['snapshots'][-1]['file']).read_bytes()
assert {x.name for x in (artifact/'observer-journal').iterdir()}=={f'{i:03d}.json' for i in range(len(generations))}
controls=read('observer-control-events.json');direct=read('provider-events.json')
for echo in echoes:assert any(all(x.get(k)==echo[k] for k in ['processID','machTimestamp','eventMessage','processImagePath']) for x in controls)
assert [x['eventMessage'] for x in direct]==messages
assert not any('container-launched-invalidates-cold-proof' in x for x in messages)
summary=json.loads((root/'actual-independent-summary.json').read_bytes());assert summary==r['actual_ui_summary']
assert {k:summary[k] for k in ['totalTestCount','passedTests','failedTests','skippedTests','expectedFailures']}=={'totalTestCount':2,'passedTests':2,'failedTests':0,'skippedTests':0,'expectedFailures':0}
assert r['diagnostic_only'] is True and r['qualification_candidate'] is False
hex_value='0061736d010000000105016000017f03020100070a0106616e7377657200000a06010400412a0b'
module=bytes.fromhex(hex_value);assert len(module)==39 and sha(module)=='ccf59f0f7a7625ee380ed228905aadfa11072ac14cea1c53d1e7f3953d4d48c6'
reference=read('reference-module.json');assert reference==r['reference_module'] and reference['returncode']==0
assert reference['result']=={'engine':'v24.22.2','moduleHex':hex_value,'bytes':39,'sha256':sha(module),'answer':42,'valid':True}
assert reference['command'][-1]==hex_value and reference['command'][1]=='-e'
source=(artifact/'fixture/Provider/JavaScriptCapability.swift').read_bytes()
assert sha(source)==reference['source_sha256'] and hex_value.encode() in source
observations=[]
for path in (root/'actual-independent-attachments').iterdir():
 if path.suffix=='.json':
  value=json.loads(path.read_bytes())
  if isinstance(value,dict) and value.get('kind')=='mostlytext-qljsc-capability':observations.append(value)
assert observations==[r['javascriptcore_capability_observation']]
o=observations[0];assert o['moduleHex']==hex_value and o['baseJS']==o['wasmAnswer']==42 and o['wasmStatus']=='available' and o['wasmType']=='object'
assert all(o[k]=='undefined' for k in ['workerType','domType','fetchType','objcType']) and all(o[k] is None for k in ['errorPhase','errorName','errorMessage'])
assert 0<o['observed_uptime']-o['started_uptime']<1 and o['request_id']==2
capability_messages=[x for x in messages if x.startswith('QL_JSC_PROBE result=')]
assert len(capability_messages)==1
live=json.loads(capability_messages[0].split('result=',1)[1]);assert live.keys()==o.keys()
for key in live:
 if key in ['started_uptime','observed_uptime']:assert abs(live[key]-o[key])<1e-10
 else:assert live[key]==o[key],key
proof={'head':head,'checkout':actual,'base':base,'tree':git('rev-parse',actual+'^{tree}').decode().strip(),'canonical_inputs':len(r['source_sha256']),'copied_inputs':len(r['fixture_source_sha256']),'generated_inputs':len(r['generated_sha256']),'compiled_roles':69,'all_three_bundles_captured':True,'provider_permissions_exact':True,'raw_native_cases':2,'passed':2,'failed':0,'skipped':0,'expected_failures':0,'diagnostic_only':True,'qualification_candidate':False,'actual_JS_answer':42,'actual_WASM_answer':42,'module_bytes':39,'module_sha256':sha(module),'hosted_node_reference_valid':True,'capability_seconds':o['observed_uptime']-o['started_uptime'],'OS':r['os'],'observer_generations':len(generations),'live_and_direct_log_exact':True,'control_nonce_correlated':True,'no_forced_cleanup':True,'scope':'Actual minimal JavaScriptCore/WASM diagnostic under unchanged sandbox and user-selected-read-only. No actual D2, host shim, deadline/fallback, production or full QL-REPLY acceptance.'}
(root/'native-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
