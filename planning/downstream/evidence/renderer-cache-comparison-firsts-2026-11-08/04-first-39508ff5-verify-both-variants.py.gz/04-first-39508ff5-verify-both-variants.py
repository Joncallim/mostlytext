import ast,collections,hashlib,importlib.util,io,json,pathlib,re,subprocess,zipfile
root=pathlib.Path(__file__).parent;repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext';fork='/Volumes/Fast SSD/CORTANA-GitHub/Textual-attachment-publication';head='39508ff5ca073319ec8083cdf94a9b854215b33a';base='6cad56275c1d9a71a9ee95daa066bd1fcae68965';pin='dd123d4f7052d84032cafb22c62cd467916518dd';sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *v:subprocess.check_output(['git',*v],cwd=repo)
for label,run,conclusion in [('native',42443157406,'failure'),('compliance',42443169680,'success')]:
 d=json.loads((root/(label+'-first-run.json')).read_bytes());assert d['id']==run and d['head_sha']==head and d['run_attempt']==1 and d['status']=='completed' and d['conclusion']==conclusion
 with zipfile.ZipFile(root/(label+'-complete-first-workflow-logs.zip')) as z:assert z.testzip() is None
assert git('diff','--name-only',base,head,'--','MacDown2').decode().splitlines()==['MacDown2/MacDown2Tests/BufferedPublicationDiagnosticTests.swift']
source=pathlib.Path('/Volumes/Fast SSD/CORTANA-GitHub/worktrees/github/mostlytext-preview-first-failure-diagnostics/.github/scripts/patch-textual-publication-stages.py');assert source.read_bytes()==git('show',head+':.github/scripts/patch-textual-publication-stages.py');spec=importlib.util.spec_from_file_location('frozen_actual_patcher',source);patcher=importlib.util.module_from_spec(spec);spec.loader.exec_module(patcher)
source_ast=ast.parse(git('show',head+':.github/scripts/verify-preview-grant-probe.py'));input_paths=None
for node in ast.walk(source_ast):
 if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=='check_output' and node.args and isinstance(node.args[0],ast.List):
  try:values=ast.literal_eval(node.args[0])
  except ValueError:continue
  if values[:3]==['git','ls-files','-z']:input_paths=values[3:];break
assert input_paths
expected_paths=set(git('ls-tree','-r','--name-only',head,'--',*input_paths).decode().splitlines());canonical_pins=json.loads(git('show',head+':MacDown2/Packages/MacDownKit/Package.resolved'))['pins'];proof={'source':head,'canonical_product_original_tests_pin_graph_base':base,'variants':{}}
for variant in ['original','current-input']:
 a=root/'native-first-artifact'/('preview-grant-app-tests-Release-revision-'+variant);r=json.loads((a/'receipt.json').read_bytes());m=json.loads((a/'textual-effective-source.json').read_bytes());obs=json.loads((a/'textual-stage-observations.json').read_bytes());assert r['checkout']==head and r['diagnostic_variant']==m['variant']==variant and r['effective_textual_source_modified'] is True and r['qualification_candidate'] is False and set(r['source_sha256'])==expected_paths and r['pins']==canonical_pins and len(r['pins'])==24
 stream=io.BytesIO(subprocess.check_output(['git','cat-file','--batch'],cwd=repo,input=''.join(head+':'+p+'\n' for p in sorted(expected_paths)).encode()))
 for p in sorted(expected_paths):
  header=stream.readline().split();assert header[1]==b'blob';raw=stream.read(int(header[2]));assert stream.read(1)==b'\n' and sha(raw)==r['source_sha256'][p],p
 assert m['original_pin']==pin and m['effective_source_modified'] is True and len(m['before'])==296 and len(m['after'])==297
 original_names=subprocess.check_output(['git','ls-tree','-r','--name-only',pin],cwd=fork).decode().splitlines();assert set(original_names)==set(m['before']);assert m['original_tree']==subprocess.check_output(['git','rev-parse',pin+'^{tree}'],cwd=fork).decode().strip()
 stream=io.BytesIO(subprocess.check_output(['git','cat-file','--batch'],cwd=fork,input=''.join(pin+':'+p+'\n' for p in m['before']).encode()))
 for p,row in m['before'].items():
  header=stream.readline().split();assert header[1]==b'blob';raw=stream.read(int(header[2]));assert stream.read(1)==b'\n' and sha(raw)==row['sha256'] and len(raw)==row['bytes'] and raw==(a/row['blob']).read_bytes()
 changed=patcher.transformed({p:(a/m['before'][p]['blob']).read_bytes() for p in patcher.EXPECTED},variant);assert sorted(changed)==m['changed_paths'] and len(changed)==5
 for p,row in m['after'].items():
  raw=(a/row['blob']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256'] and raw==(changed[p] if p in changed else (a/m['before'][p]['blob']).read_bytes())
 compiled_raw=(a/'compiled-initial.json').read_bytes();compiled=json.loads(compiled_raw);binding=json.loads((a/'textual-compiled-binding.json').read_bytes());assert binding['effective_source_manifest_sha256']==obs['effective_source_manifest_sha256']==sha((a/'textual-effective-source.json').read_bytes()) and binding['compiled_manifest_sha256']==sha(compiled_raw) and len(compiled['inputs'])==5
 for role,row in compiled['inputs'].items():
  raw=(a/row['blob']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256']==binding['actual_compiled_role_hashes'][role]
 identity=json.loads((a/'diagnostics/identity.json').read_bytes());owned=json.loads((a/'diagnostics/status.json').read_bytes());assert identity['checkout']==head and identity['app_sha256']==compiled['inputs']['app_executable']['sha256'] and owned==obs['actual_owned_status'] and owned['returncode']==(65 if variant=='original' else 0) and not owned['timed_out'] and not owned['cancelled'] and owned['app_cleanup_requested']==[] and 0<owned['elapsed_seconds']<600
 raw=subprocess.check_output(['xcrun','xcresulttool','get','test-results','summary','--path',str(a/'actual-initial.xcresult')]);actual=json.loads(raw);assert actual==obs['actual_summary'];wanted={'totalTestCount':58,'passedTests':57 if variant=='original' else 58,'failedTests':1 if variant=='original' else 0,'skippedTests':0,'expectedFailures':0};assert all(actual[k]==v for k,v in wanted.items());(root/(variant+'-actual-independent-summary.json')).write_bytes(raw)
 host=json.loads((a/'textual-diagnostic-host.json').read_bytes());assert host==obs['actual_diagnostic_host'] and host['variant']==variant and host['uid']==host['effective_uid']==501 and host['user']=='runner' and host['home']=='/Users/runner' and host['GITHUB_ACTIONS']=='true' and host['GITHUB_REPOSITORY']=='Joncallim/mostlytext' and host['RUNNER_TEMP']=='/Users/runner/work/_temp'
 assert obs['scenario_errors']==[] and obs['trace_limit_reached'] is False
 names=['initial',*[f'{i:02d}-{j}' for i in range(12) for j in ['production','revision']],'final'];assert [x['scenario'] for x in obs['buffered_scenarios']]==names
 log=(a/'probe.log').read_text();pending=[];issues={};started=False;case_rows={}
 for line in log.splitlines():
  if 'Test twentyFourFreshJourneysIncludeControlledCacheFaults() started.' in line:started=True
  if 'recorded an issue' in line:
   assert started and 'twentyFourFreshJourneysIncludeControlledCacheFaults() recorded an issue' in line
   assert 'SecuredMarkdownMountedTests+Support.swift:54:21' in line or 'ProductionPreviewResourceRoutingTests.swift:149:21' in line
   pending.append(line)
  event=re.search(r'TEXTUAL_SCENARIO name=(\S+)',line)
  if event:issues[event.group(1)]=pending;pending=[]
  if 'Test twentyFourFreshJourneysIncludeControlledCacheFaults() failed' in line or 'Test twentyFourFreshJourneysIncludeControlledCacheFaults() passed' in line:started=False
 assert not pending and set(issues)==set(names)
 for name,row in zip(names,obs['buffered_scenarios']):
  assert row==json.loads((a/'textual-scenarios'/(name+'.json')).read_bytes()) and not row['overflow'] and len(row['events'])<4000 and row['qualification_candidate'] is False
  fault='none' if name=='initial' or name!='final' and int(name[:2])<10 else 'inline' if name.startswith('10-') else 'fragment';assert row['fault']==fault
  suppression=sum('controlled-suppression' in e for e in row['events']);counter=collections.Counter()
  for e in row['events']:
   event=re.search(r'stage=(\S+) attachedRuns=(\d+)',e)
   if event:counter[event.group(1)+'/'+event.group(2)]+=1
  if name not in ['initial','final']:assert counter['attachments-ready/1']>0
  if fault=='none' or variant=='current-input':assert suppression==0
  elif name!='final':assert suppression>0 and issues[name]
  case_rows[name]={'fault':fault,'actual_issues':len(issues[name]),'threw':row['threw'],'suppression_events':suppression,'stage_counts':dict(counter)}
 if variant=='original':
  assert sum(len(v) for v in issues.values())==13 and sum(len(issues[f'{i:02d}-{j}']) for i in range(10) for j in ['production','revision'])==7
  assert set(k for k,v in issues.items() if v and k[:2] not in ['10','11'])=={'00-revision','01-revision','02-revision','03-revision','05-revision','06-production','08-revision'}
  assert case_rows['01-revision']['stage_counts']==case_rows['04-revision']['stage_counts'] and case_rows['01-revision']['actual_issues']==1 and case_rows['04-revision']['actual_issues']==0
  for name,row in case_rows.items():
   if row['fault']=='none' and row['actual_issues']:
    assert row['stage_counts']['inline-existing-change/1']>0 and row['stage_counts']['inline-resolved-output/1']>0 and row['stage_counts']['fragment-existing-change/1']>0 and row['stage_counts']['builder-init/1']>0
 else:assert sum(len(v) for v in issues.values())==0
 proof['variants'][variant]={'canonical_source_bindings':len(expected_paths),'actual_downloaded_original_effective_fork_files':[296,297],'all5_actual_changed_Swift_files_match_exact_transform':True,'actual_downloaded_compiled_roles':5,'actual_raw_summary':wanted,'actual_owned':owned,'actual_scenarios':case_rows,'interpretation':('Seven unforced normal-scenario failures reproduce stale nativeCopy with both inline/fragment updates and attachment-bearing builder construction observed; All listed stage events are present by end-of-scenario; their timing relative to the actual failed Copy is NOT_CAPTURED, so neither missing nor late callback cause is established. Four injected fault scenarios also fail with six issues. Original57standalone tests pass.' if variant=='original' else 'All57originals plus24fresh journeys in one aggregate pass; both publication callbacks removed by source, so injected suppression has no required callback to withhold. Instrumented prototype only, not uninstrumented production qualification.')}
proof['conclusion']='The prototype prevents actual observed normal-scenario staleCopy in this controlled comparison. Completed buffers contain all upstream stages, but lack a failure-point marker. The timing of these events relative to failed Copy is unknown; the functional differential motivates minimal layer variants and failure-only checkpoints without establishing a specific cause. Need orthogonal minimal variants and uninstrumented canonical qualification before fork/pin/product changes.';proof['scope']='No sole historical OS cause, fullPreview or release closure. threw=false is not a passing assertion oracle; raw native issue events and summaries are authoritative.'
(root/'both-variants-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print('Bothactualvariants/source/24pins/296original297effectivefiles/5compiledroles/native58outcomes verified. Original7unforced+4controlled failures; prototype24fresh+57original PASS. No missing-callback rootcause claim.')
