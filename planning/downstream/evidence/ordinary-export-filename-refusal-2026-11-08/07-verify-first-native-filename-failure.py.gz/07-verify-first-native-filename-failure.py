import hashlib,io,json,pathlib,plistlib,re,subprocess,zipfile
root=pathlib.Path(__file__).parent;a=root/'native-first-artifact/ordinary-release-export-panel';repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext';head='70c5ef922d1c6e6bccccf1ad41b77b096c6ef22e';actual='f8d3b0ecb2bcfed5df02810c8022e63f571cd01d';parent='ed5a9409dcfbe62263dda0dd8157d8ea4f827e7f';git=lambda *x:subprocess.check_output(['git',*x],cwd=repo);sha=lambda b:hashlib.sha256(b).hexdigest();d=json.loads((a/'receipt.json').read_bytes())
for label,run,c in [('native',42421882343,'failure'),('compliance',42421949561,'success')]:
 row=json.loads((root/(label+'-first-run.json')).read_bytes());assert row['id']==run and row['head_sha']==head and row['run_attempt']==1 and row['conclusion']==c
 with zipfile.ZipFile(root/(label+'-complete-first-workflow-logs.zip')) as z:assert z.testzip() is None
assert d['checkout']==actual and git('show','-s','--format=%P',actual).decode().split()==[parent,head]
assert git('rev-parse',actual+'^{tree}').decode().strip()==git('merge-tree','--write-tree',parent,head).decode().splitlines()[0]
assert git('rev-parse',actual+':MacDown2').decode().strip()==git('rev-parse',parent+':MacDown2').decode().strip()==d['ordinary_export']['product_tree']=='1b01b78e3415d8261fa18bfb4c90c180ffa22a7f'
requests=[actual+':'+p for p in sorted(d['source_sha256'])];stream=io.BytesIO(git('cat-file','--batch') if False else subprocess.check_output(['git','cat-file','--batch'],cwd=repo,input=('\n'.join(requests)+'\n').encode()));blobs={}
for request in requests:
 header=stream.readline().split();assert header[1]==b'blob';raw=stream.read(int(header[2]));assert stream.read(1)==b'\n';name=request.split(':',1)[1];assert sha(raw)==d['source_sha256'][name];blobs[name]=raw
assert len(blobs)==1639 and d['pins']==json.loads(blobs['MacDown2/Packages/MacDownKit/Package.resolved'])['pins'] and len(d['pins'])==24
for name,h in d['generated_sha256'].items():assert sha((a/'fixture'/name).read_bytes())==h
for role,row in d['export_compiled_before'].items():
 raw=(a/row['blob']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
assert len(d['export_compiled_before'])==411
settings=next(x['buildSettings'] for x in d['ordinary_export']['actual_build_settings'] if x['target']=='MacDown2');assert settings['CONFIGURATION']=='Release' and not settings.get('SWIFT_ACTIVE_COMPILATION_CONDITIONS','').split() and settings['ONLY_ACTIVE_ARCH']=='YES' and settings['ARCHS']=='arm64' and d['ordinary_export']['actual_executable_architectures']=='arm64'
for label,passed,failed in [('positive',1,0),('export',0,1)]:
 row=d['ui_results'][label];summary=json.loads((root/(label+'-actual-independent-summary.json')).read_bytes());owned=json.loads((a/(label+'-owned/status.json')).read_bytes());assert row['summary']==summary and row['owned']==owned
 assert {k:summary[k] for k in ['totalTestCount','passedTests','failedTests','skippedTests','expectedFailures']}=={'totalTestCount':1,'passedTests':passed,'failedTests':failed,'skippedTests':0,'expectedFailures':0}
 assert owned['returncode']==(65 if failed else 0) and not owned['timed_out'] and not owned['cancelled'] and owned['app_cleanup_requested']==[]
assert d['criteria']=={'benign_control':True,'file_open_acknowledged':True} and d['errors'] and d['passed'] is False
assert [x['operation'] for x in d['applications']]==['launch','inspect','cleanup'] and len({(x['pid'],x['birth'],x['executable']) for x in d['applications']})==1
assert d['applications'][-1]['terminated'] is True
source=a/'documents'/pathlib.PurePosixPath(d['source_file']).name;assert sha(source.read_bytes())==d['source_file_sha256']==d['ordinary_export']['source_sha256'] and {x.name for x in (a/'documents').iterdir()}=={source.name}
summary=d['ui_results']['export']['summary'];assert len(summary['testFailures'])==1 and 'Require the actual unique filename field with the source-derived default' in summary['testFailures'][0]['failureText']
trees=list((root/'export-actual-independent-attachments').glob('*.txt'));assert len(trees)==1;tree=trees[0].read_text();assert "identifier: 'saveAsNameTextField', value: focus-42421882343, Keyboard Focused" in tree
proof={'head':head,'actual_checkout':actual,'parent':parent,'canonical_inputs':1639,'pins':24,'generated':len(d['generated_sha256']),'actual_downloaded_compiled_roles':411,'actual_ordinary_Release_ARM_no_added_test_flags':True,'actual_benign_positive_passed':True,'actual_Export_case':'FAILED: source-derived filename assertion incorrectly expects visible .html extension','actual_observed_AX':'Initial before-Cancel attachment: saveAsNameTextField value=focus-42421882343, extension hidden; no separately exported failed-second-panel custom attachment','actual_initial_Cancel_and_reopen':'Completed before the single filename-field assertion failure','actual_HTML_PDF_outputs':'NOT_RUN; only unchanged original source exists','root_app_termination':'Identity-bound FORCE cleanup on failed journey; not normal Quit acceptance','owned_UI_no_timeout_or_force':True,'scope':'Actual first ordinary Release failure is a private native filename-selector expectation defect, not a verified HTML/PDF product failure or acceptance. Complete first original logs/artifacts and raw results retained.'}
(root/'first-native-filename-failure-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof)
