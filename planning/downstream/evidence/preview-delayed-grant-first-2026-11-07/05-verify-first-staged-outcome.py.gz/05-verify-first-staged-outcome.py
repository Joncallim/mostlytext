import hashlib,json,pathlib,subprocess
r=pathlib.Path(__file__).parent;p=r/'image-diagnosis-first-artifact/preview-grant-app-tests-Debug-revision';b=p/'delayed-grant-diagnosis';head='5efe437fe1b98e2bc52822345b94277a31b6d6d7'
d=json.loads((b/'result.json').read_text());assert d['checkout']==head and d['diagnostic_only'] and not d['qualification_candidate'] and d['original_compiled_inputs_unchanged']
original=json.loads((p/'compiled-initial.json').read_text());binding=json.loads((b/'compiled-initial.json').read_text());assert binding['inputs']==original['inputs'] and len(binding['inputs'])==7
for role,row in binding['inputs'].items():
 raw=(b/row['blob']).read_bytes();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
 assert (p/row['blob']).read_bytes()==raw
identity=json.loads((b/'diagnostics/identity.json').read_text());owned=json.loads((b/'diagnostics/status.json').read_text());assert owned==d['actual_owned'] and owned['returncode']==65 and not owned['timed_out'] and not owned['cancelled'] and owned['app_cleanup_requested']==[]
assert identity['checkout']==head and identity['app_sha256']==original['inputs']['app_executable']['sha256']
cmd=identity['command'];assert cmd.count('-only-testing:MacDown2Tests/PreviewDelayedGrantDiagnosisTests')==1 and len([s for s in cmd if s.startswith('-only-testing:')])==1
assert '-onlyUsePackageVersionsFromResolvedFile' in cmd and cmd[cmd.index('-destination')+1]=='platform=macOS,arch=arm64'
raw=subprocess.check_output(['xcrun','xcresulttool','get','test-results','summary','--path',str(b/'actual-staged.xcresult')]);summary=json.loads(raw);assert summary==d['actual_summary']==json.loads((b/'actual-staged-summary.json').read_text())
for k,v in {'totalTestCount':1,'passedTests':0,'failedTests':1,'skippedTests':0,'expectedFailures':0}.items():assert type(summary[k]) is int and summary[k]==v
assert len(summary['testFailures'])==1;failure=summary['testFailures'][0];assert failure['testIdentifierString']=='PreviewDelayedGrantDiagnosisTests/anObservedDeniedImageCanLoadAfterTheSameDocumentReceivesItsGrant()'
assert failure['failureText']=='Expectation failed: (current.mutationGeneration → 1) == (original.mutationGeneration → 0)'
log=(b/'probe.log').read_text();issues=[s for s in log.splitlines() if 'recorded an issue' in s];assert len(issues)==1 and 'PreviewDelayedGrantDiagnosisTests.swift:42:9' in issues[0]
assert 'Test run with 1 test in 1 suite failed' in log and 'production-delayed-grant-copy-failure' not in log and 'Restarting after unexpected' not in log
assert d['original_initial_owned']['returncode']==0
proof={'head':head,'first_run':42385745698,'diagnostic_only':True,'qualification_candidate':False,'downloaded_original_and_staged_compiled_roles_verified':7,'staged_actual_summary':summary,'owned':owned,'only_actual_issue':issues[0],'scope':'First stagedB fails its generation comparison0to1 across the pre-observation wait, not an image-copy assertion. Original55 and original selection/mutation/restoration pass independently; diagnostic does not reproduce/repair/waive historical fc29 image failure. No cause of the generation transition is proved, no native retry.'}
(r/'image-diagnosis-first-staged-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');(r/'image-diagnosis-first-staged-actual-independent-summary.json').write_bytes(raw);print({k:v for k,v in proof.items() if k not in ['staged_actual_summary','owned']})
