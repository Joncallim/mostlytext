from pathlib import Path
import hashlib,json,plistlib,re,subprocess
root=Path(__file__).parent;a=root/'native-first-artifact/actual-renderer-quicklook-deadline';repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext'
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(name):return json.loads((a/name).read_bytes())
r=read('receipt.json');head='0beace2290d79681fe2e565874cb468de2074e08';base='fe5e8d3051cb0fed3d815e4ced287c665ca08509';actual='861089b90b4dd744a8e780c8423ea2e62b040af6'
assert r['checkout']==actual and git('show','-s','--format=%P',actual).decode().strip().split()==[base,head]
assert git('merge-tree','--write-tree',base,head).decode().splitlines()[0]==git('rev-parse',actual+'^{tree}').decode().strip()
names=list(r['source_sha256']);data=subprocess.check_output(['git','cat-file','--batch'],cwd=repo,input=('\n'.join(actual+':'+n for n in names)+'\n').encode());position=0
for name in names:
 end=data.index(b'\n',position);fields=data[position:end].split();assert fields[1]==b'blob';count=int(fields[2]);start=end+1
 assert sha(data[start:start+count])==r['source_sha256'][name],name;position=start+count+1
assert position==len(data)
for name,expected in r['fixture_source_sha256'].items():
 raw=(a/'original-project.yml.txt').read_bytes() if name=='project.yml' else (a/'fixture'/name).read_bytes();assert sha(raw)==expected,name
for name,expected in r['generated_sha256'].items():assert sha((a/'fixture'/name).read_bytes())==expected,name
assert len(r['compiled_before_test'])==111 and len(r['compiled_products_before_helpers'])==109 and r['native_execution_admitted'] is True
for name,row in r['compiled_before_test'].items():
 raw=(a/row['blob']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],name
for name,row in r['compiled_products_before_helpers'].items():assert r['compiled_before_test'][name]==row
for name in ['harness.html','render.js','d2-browser.js']:
 found=[v for k,v in r['compiled_before_test'].items() if 'Resources/MacDownKit_D2Rendering.bundle/' in k and k.endswith('/'+name)];assert len(found)==1,name
 assert found[0]['sha256']==r['source_sha256']['MacDown2/Packages/MacDownKit/Sources/D2Rendering/Resources/'+name]
provider=a/r['compiled_before_test']['provider']['blob'];metadata=subprocess.run(['codesign','--display','--entitlements',':-',str(provider)],capture_output=True,check=True)
(root/'actual-downloaded-provider-entitlements.plist').write_bytes(metadata.stdout)
assert plistlib.loads(metadata.stdout)=={'com.apple.security.app-sandbox':True,'com.apple.security.files.user-selected.read-only':True}
assert len(r['package_pins'])==len(r['actual_package_pins'])==24
assert {p['identity']:p['state']['revision'] for p in r['package_pins']}=={p['identity']:p['revision'] for p in r['actual_package_pins']}
g=read('gate-controls.json');assert g['build_returncode']==0 and 'error' not in g and [(x['name'],x['returncode']) for x in g['phases']]==[('original',0),('wrong-caller',42),('restored',0)]
assert all(x['binary_sha256']==g['binary_sha256']==r['compiled_before_test']['gate_controls']['sha256'] for x in g['phases'])
assert 'DIRECT_CONTROL_REFUSED premature refund' in (a/'gate-controls-wrong-caller.log').read_text()
for phase in ['original','restored']:assert 'DIRECT_GATE_CONTROLS passed:64concurrent' in (a/('gate-controls-'+phase+'.log')).read_text()
status=read('owned/status.json');identity=read('owned/identity.json');driver=read('host-ui-driver.json');observer=read('observer-result.json')
assert status['returncode']==65 and status['timed_out'] is status['cancelled'] is False and status['app_cleanup_requested']==[]
assert identity['checkout']==driver['checkout']==observer['checkout']==actual and identity['app_sha256']==r['compiled_before_test']['provider']['sha256']
assert driver['ui_started'] is True and driver['ui_supervisor_returncode']==65 and driver['observer_returncode']==0 and driver['observer_forced_cleanup'] is False
assert observer['errors']==[] and observer['timed_out'] is False and observer['stream_forced_cleanup'] is False and observer['stream_unexpected_exit'] is False
assert observer['stopped_after_ui'] is True and driver['ui_completed_monotonic']<=driver['observer_stop_requested_monotonic']<=observer['stop_signal_monotonic']
raw=(a/'observer-stream.log').read_bytes();assert len(raw)==observer['stream_bytes'] and sha(raw)==observer['stream_sha256']
position=0;echo=False;messages=[];generations=[]
for line in raw.splitlines(keepends=True):
 position+=len(line)
 if line.startswith(b'Filtering the log data using '):continue
 value=json.loads(line)
 if value['subsystem']=='app.mostlytext.qldeadlineobserver':
  assert value['eventMessage']=='QL_OBSERVER_CONTROL nonce='+observer['nonce']
  if not echo:generations.append((position,[]));echo=True
 else:
  assert value['subsystem']=='app.mostlytext.qldeadlineprobe' and echo
  messages.append(value['eventMessage']);generations.append((position,list(messages)))
assert len(generations)==len(observer['snapshots'])
for i,(row,generation) in enumerate(zip(observer['snapshots'],generations)):
 record=(a/row['file']).read_bytes();value=json.loads(record)
 assert len(record)==row['bytes'] and sha(record)==row['sha256'] and row['stream_position']==generation[0]
 assert value['checkout']==actual and value['sequence']==i and value['messages']==generation[1]
assert [x['eventMessage'] for x in read('provider-events.json')]==messages
assert (a/'provider-observer.json').read_bytes()==(a/observer['snapshots'][-1]['file']).read_bytes()
assert any(x['subsystem']=='app.mostlytext.qldeadlineobserver' and x['eventMessage']=='QL_OBSERVER_CONTROL nonce='+observer['nonce'] for x in read('observer-control-events.json'))
summary=json.loads((root/'actual-independent-summary.json').read_bytes());assert {k:summary[k] for k in ['totalTestCount','passedTests','failedTests','skippedTests','expectedFailures']}=={'totalTestCount':2,'passedTests':1,'failedTests':1,'skippedTests':0,'expectedFailures':0}
assert len(summary['testFailures'])==1 and 'real D2 renderer must produce a rich positive' in summary['testFailures'][0]['failureText']
phases=[]
for message in messages:
 m=re.fullmatch(r'QL_DEADLINE_PROBE ([a-z-]+) id=(\d+) uptime=([\d.]+)',message)
 if m:phases.append((m[1],int(m[2]),float(m[3])))
assert [x[0] for x in phases]==['callback','worker-start','worker-terminal','selected-failed','reply-failed','factory-failed'] and all(x[1]==2 for x in phases)
assert messages.count('QL_DEADLINE_RENDER_ERROR id=2 detail=rendererUnavailable')==1
assert phases[2][2]-phases[0][2]<2 and not any('selected-fallback' in x for x in messages)
for label,expected in [('native','failure'),('compliance','success')]:
 run=json.loads((root/(label+'-first-run.json')).read_bytes());assert run['head_sha']==head and run['run_attempt']==1 and run['status']=='completed' and run['conclusion']==expected
proof={'head':head,'actual_checkout':actual,'base':base,'canonical_inputs':len(names),'copied_inputs':len(r['fixture_source_sha256']),'generated_inputs':len(r['generated_sha256']),'actual_pins':24,'downloaded_execution_roles':111,'pre_console_product_roles_preserved':109,'actual_D2_harness_JS_source_correspondence':True,'provider_permissions_exact':True,'hosted_direct_gate_modes':[0,42,0],'same_binary':g['binary_sha256'],'raw_native_cases':2,'passed':1,'failed':1,'skipped':0,'expected_failures':0,'original_cold_static_positive':'PASS','real_small_D2_positive':'FAILED rendererUnavailable','actual_small_API_duration_seconds':phases[2][2]-phases[0][2],'large_fallback_case':'NOT_RUN','owned_returncode':65,'forced_cleanup':False,'observer_completed_normally':True,'scope':'Actual small D2 API returns generic rendererUnavailable before deadline and supplies one readable error reply. Underlying resource/harness/JS/WebKit phase is UNKNOWN; no sandbox/cold-timing/environment root cause is claimed. Do not accept an error as rich rendering or slow-worker fallback. No unchanged failed native retry or assertion/permission/deadline waiver.'}
(root/'first-runtime-failure-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
