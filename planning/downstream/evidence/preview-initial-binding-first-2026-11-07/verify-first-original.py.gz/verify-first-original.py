import hashlib,io,json,pathlib,re,subprocess,sys
root=pathlib.Path(__file__).parent;repo=pathlib.Path('/Volumes/Fast SSD/CORTANA-GitHub/mostlytext');head=sys.argv[1];name=sys.argv[2];config=sys.argv[3];pair=sys.argv[4];p=root/name;r=json.loads((p/'receipt.json').read_text());assert r['mutation_pair']==pair and r['configuration']==config and r['testability'] and r['additional_compilation_condition']=='RELEASE_PREVIEW_PROBE'
requests=[head+':'+n for n in sorted(r['source_sha256'])]+[head+':MacDown2/Packages/MacDownKit/Package.resolved'];blobs={};stream=io.BytesIO(subprocess.check_output(['git','cat-file','--batch'],cwd=repo,input=('\n'.join(requests)+'\n').encode()))
for key in requests:
 hdr=stream.readline().split();assert hdr[1]==b'blob',key;blobs[key]=stream.read(int(hdr[2]));assert stream.read(1)==b'\n'
for n,d in r['source_sha256'].items():assert hashlib.sha256(blobs[head+':'+n]).hexdigest()==d,n
tracked=['.github/scripts/run-preview-delayed-grant-diagnosis.py','planning/downstream/evidence/actual-app-hosted-plan-2026-11-07','.github/scripts/preview_compiled_inputs.py','.github/scripts/test-preview-compiled-inputs.py','.github/scripts/test-preview-diagnostic-host.py','.github/scripts/test-preview-native-architecture.py','MacDown2','.github/scripts/verify-preview-grant-probe.py','.github/workflows/preview-grant-probe.yml','.github/scripts/check-preview-parsed-frame.py','.github/scripts/test-preview-grant-tripwire.py','.github/scripts/run-preview-grant-probe.py','.github/scripts/run-owned-app-tests.py','.github/scripts/test-run-owned-app-tests.py']
expected_names=set(subprocess.check_output(['git','ls-tree','-r','--name-only',head,'--',*tracked],cwd=repo,text=True).splitlines());assert expected_names==set(r['source_sha256']), 'Missing/extra tracked input receipt'
assert subprocess.check_output(['git','rev-parse',r['checkout']+'^{tree}'],cwd=repo,text=True).strip()==subprocess.check_output(['git','rev-parse',head+'^{tree}'],cwd=repo,text=True).strip(), 'Checkout tree mismatch'
assert json.loads(blobs[requests[-1]])['pins']==r['pins'];log=(p/'probe.log').read_text();count,suites=(56,18) if config=='Release' else (55,17);assert re.search(f'Test run with {count} tests in {suites} suites passed',log);assert 'recorded an issue at' not in log;assert 'PREVIEW_NETWORK_CONTROL live=true loaded=true deniedRequests=0' in log
if config=='Release':assert 'PREVIEW_RELEASE_PROBE sourceBytes=4194304' in log
for function in ['canonicallyEquivalentPublishedBytesCannotBorrowTheCurrentGrant', 'pendingPublishedSourceRetiresThePriorLoadAndKeepsPreviewMounted', 'absentParseRetiresItsPriorLoadWithoutRemovingReadableContent', 'originIsReservedBeforeTheCommandTaskCanRun', 'aHeldChoiceRemainsWithItsWindowWhenAnotherWindowBecomesKey', 'sameTextSaveAsRejectsAnOlderHeldFolderChoice', 'rootAwayAndBackCannotReviveAPendingChoice', 'anOlderCancellationCannotClearANewerPendingSelection', 'theRealFolderSheetFinishesWhenItsOriginWindowCloses', 'theRealMarkdownWindowCopiesGrantedImagesAndRevokesThemOnSaveAs', 'theRealHTMLPaneUsesImmutableHandlersAndPreservesSourceRenderedSwitching', 'cancellationAfterBackingAcquisitionCannotPublishAFolderGrant', 'identicalVisibleBlocksFromAnotherParserCannotKeepThePreviousSourceFrame', 'equalRevisionsFromAnotherParserCannotReusePublishedContributions']:assert re.search(r'Test '+re.escape(function)+r'\(\) passed',log),function
initial_identity=json.loads((p/'diagnostics/identity.json').read_text());assert initial_identity['checkout']==r['checkout']
network=json.loads((p/'network.json').read_text());assert not network['denied_requests'] and '/control' in network['paths'] and '/control-webkit' in network['paths'];status=json.loads((p/'diagnostics/status.json').read_text());assert status['returncode']==0 and not status['timed_out'] and not status['cancelled']
source=blobs[head+':MacDown2/MacDown2/SecuredMarkdownResourceHost.swift'];needle=b'content(loader, current?.loadID)';assert source.count(needle)==1;viewport=b'ZStack(alignment: .topLeading) {\n    content(loader, current?.loadID).id(current?.loadID)\n}.id(currentIdentity)';records=json.loads((p/'parsed-frame-results.json').read_text());expected=[('revision-mutant',source.replace(b'revision = document.revision',b'revision = 0'),3,'failed','Mounted Textual did not admit the expected document-bound image'),('revision-restored',source,3,'passed',None),('viewport-mutant',source.replace(needle,viewport),1,'failed','Resource replacement must retain the native scroll container'),('viewport-restored',source,1,'passed',None),('disappear-mutant',source.replace(b'let retiringContext = slot?.context',b'let retiringContext = current?.context'),3,'failed','A hidden Preview must revoke its previous parsed-frame loader'),('disappear-restored',source,3,'passed',None)]
expected=[x for x in expected if x[0].startswith(pair+'-')];assert len(expected)==2
assert [x['phase'] for x in records]==[x[0] for x in expected]
for row,(phase,raw,n,outcome,message) in zip(records,expected):
 assert row['original_app_sha256']==initial_identity['app_sha256']
 identity=json.loads((p/('parsed-frame-'+phase+'-diagnostics')/'identity.json').read_text());assert identity['app_sha256']==row['app_sha256'] and identity['checkout']==r['checkout']
 assert row['source_sha256']==hashlib.sha256(raw).hexdigest();assert row['returncode']==(65 if outcome=='failed' else 0);phase_log=(p/('parsed-frame-'+phase+'.log')).read_text();assert re.search(f'Test run with {n} '+('test' if n==1 else 'tests')+' in 1 suite '+outcome,phase_log)
 if message:assert message in phase_log
 if phase in ['revision-mutant','disappear-mutant']:assert 'Test aGrantedImageCopiesAsPNGAndLoadsAgainUnderANewDocumentGeneration() passed' in phase_log
 if phase=='revision-mutant':assert 'Test hidingDuringAParsedFrameReplacementRevokesTheRetainedLoader() passed' in phase_log
 if phase=='disappear-mutant':assert 'Test aNewParsedRevisionReplacesTheLoadWithoutAnotherModelEdit() passed' in phase_log
 s=json.loads((p/('parsed-frame-'+phase+'-diagnostics')/'status.json').read_text());assert s['returncode']==row['returncode'] and not s['timed_out'] and not s['cancelled']
for a,b in [(records[0],records[1])]:assert a['app_sha256']!=b['app_sha256'] and a['original_app_sha256']==b['original_app_sha256']==b['app_sha256']
legacy_summary={'source_head':head,'checkout':r['checkout'],'configuration':config,'mutation_pair':pair,'verified_source_hashes':len(r['source_sha256']),'verified_pins':len(r['pins']),'tests':count,'suites':suites,'network':network,'owned_status':status,'actual_application_mutation_and_restoration':records,'phase_observations':[s for s in log.splitlines() if 'PREVIEW_RELEASE_PROBE' in s],'scope':'Production routing and bounded consumers; owner acceptance and signed-artifact gates remain open.'}

import plistlib,stat
assert head=='4f9bd925f0d3e96bd6aeaf93ef04fef3a42b5d2f' and r['checkout']==head
assert r['current_main_baseline']=='427d15fa5da94d4045a02e7f6a005648d09e38c5' and r['diagnostic_only'] is True and r['qualification_candidate'] is False
assert r['resource_trace_enabled'] is True and r['fixture_window_lifetime_observer'] is True and r['renderer_preference_observer'] is False
assert len(r['pins'])==24
phases=['initial','selection',pair+'-mutant',pair+'-restored'];phase_proofs={};compiled={}
for phase in phases:
 binding=json.loads((p/('compiled-'+phase+'.json')).read_text());verified=json.loads((p/('compiled-'+phase+'-verified.json')).read_text())
 assert binding['phase']==verified['phase']==phase and binding['configuration']==verified['configuration']==config
 assert verified['compiled_inputs_unchanged_after'] is True and verified['actual_owned_app_matches_captured_executable'] is True
 roles={'app_executable','app_info','test_executable','xctestrun','generated_project'}
 if config=='Debug':roles|={'app_debug_dylib','app_preview_dylib'}
 assert set(binding['inputs'])==roles;captured={}
 for role,row in binding['inputs'].items():
  assert row['blob']=='compiled-inputs/blobs/'+row['sha256'];f=p/row['blob'];st=f.lstat();assert stat.S_ISREG(st.st_mode) and st.st_nlink==1 and st.st_size<=256*1024*1024
  raw=f.read_bytes();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'];captured[role]=raw
 info=plistlib.loads(captured['app_info']);plan=plistlib.loads(captured['xctestrun']);target=plan['MacDown2Tests']
 assert info['CFBundleIdentifier']=='app.mostlytext.MostlyText' and info['CFBundleExecutable']=='MacDown2'
 expected={'BlueprintName':'MacDown2Tests','ProductModuleName':'MacDown2Tests','TestHostPath':'__TESTROOT__/'+config+'/MacDown2.app','TestHostBundleIdentifier':'app.mostlytext.MostlyText','TestBundlePath':'__TESTHOST__/Contents/PlugIns/MacDown2Tests.xctest','IsAppHostedTestBundle':True}
 assert all(target[k]==v for k,v in expected.items())
 app=pathlib.PurePosixPath(binding['inputs']['app_executable']['path']).parents[2]
 assert str(app)=='/Users/runner/work/_temp/preview-grant-app/Build/Products/'+config+'/MacDown2.app'
 assert binding['inputs']['test_executable']['path']==str(app/'Contents/PlugIns/MacDown2Tests.xctest/Contents/MacOS/MacDown2Tests')
 if config=='Debug':
  for role,image in [('app_debug_dylib','MacDown2.debug.dylib'),('app_preview_dylib','__preview.dylib')]:assert binding['inputs'][role]['path']==str(app/'Contents/MacOS'/image)
 owned_folder='diagnostics' if phase=='initial' else 'selection-diagnostics' if phase=='selection' else 'parsed-frame-'+phase+'-diagnostics'
 ident=json.loads((p/owned_folder/'identity.json').read_text());owned=json.loads((p/owned_folder/'status.json').read_text())
 assert ident['checkout']==r['checkout'] and ident['app']==binding['inputs']['app_executable']['path'] and ident['app_sha256']==binding['inputs']['app_executable']['sha256']
 assert verified['actual_owned']==owned and owned['returncode']==(65 if phase.endswith('-mutant') else 0) and owned['timed_out'] is False and owned['cancelled'] is False and owned['app_cleanup_requested']==[]
 command=ident['command'];assert command[0]=='xcodebuild' and command.count('test-without-building')==1 and command.count('ONLY_ACTIVE_ARCH=YES')==1 and command[command.index('-destination')+1]=='platform=macOS,arch=arm64'
 assert '-onlyUsePackageVersionsFromResolvedFile' in command and command[command.index('-configuration')+1]==config
 actual_raw=subprocess.check_output(['xcrun','xcresulttool','get','test-results','summary','--path',str(p/('actual-'+phase+'.xcresult'))]);actual=json.loads(actual_raw)
 raw_target=root/(name.replace('/','--')+'-'+phase+'-actual-independent-summary.json');raw_target.write_bytes(actual_raw)
 assert actual==verified['actual_summary']==json.loads((p/('actual-'+phase+'-summary.json')).read_text())
 n=count if phase=='initial' else 1 if phase=='selection' or pair=='viewport' else 3;failed=1 if phase.endswith('-mutant') else 0
 for k,v in {'totalTestCount':n,'passedTests':n-failed,'failedTests':failed,'skippedTests':0,'expectedFailures':0}.items():assert type(actual[k]) is int and actual[k]==v,(phase,k,actual[k])
 testsraw=subprocess.check_output(['xcrun','xcresulttool','get','test-results','tests','--path',str(p/('actual-'+phase+'.xcresult'))]);(root/(name.replace('/','--')+'-'+phase+'-actual-independent-tests.json')).write_bytes(testsraw)
 def nodes(rows):
  for row in rows:
   yield row
   yield from nodes(row.get('children',[]))
 cases=[x for x in nodes(json.loads(testsraw)['testNodes']) if x.get('nodeType')=='Test Case'];assert len(cases)==n,(phase,len(cases),n)
 assert sum(x['result']=='Passed' for x in cases)==n-failed and sum(x['result']=='Failed' for x in cases)==failed
 if phase.endswith('-mutant'):
  wanted={'revision':'aNewParsedRevisionReplacesTheLoadWithoutAnotherModelEdit()','viewport':'resourceFrameReplacementKeepsTheNativeScrollContainerPositionAndFocus()','disappear':'hidingDuringAParsedFrameReplacementRevokesTheRetainedLoader()'}[pair]
  failures=[x for x in cases if x['result']=='Failed'];assert failures[0]['name']==wanted,(pair,failures)
 phase_proofs[phase]={'actual_summary':actual,'raw_result_cases':len(cases),'owned':owned,'downloaded_compiled_roles':{role:row['sha256'] for role,row in binding['inputs'].items()}}
 compiled[phase]=binding
sel=(p/'selection-probe.log').read_text();assert 'IMAGE_SELECTION_ORACLE positives=8 negatives=56 capturedBlue=true' in sel and 'IMAGE_SELECTION_GATE completed=8' in sel
for i in range(8):assert 'IMAGE_SELECTION_GENERATION '+str(i)+' requests=1 copiedPNG=true' in sel
for function in ['fileStoreBOMDocumentsRenderAsUTF8WithoutRewritingOriginalBytes','nonUTF8HTMLResourcesKeepBOMBytesAndAuthoritativeResponseProtection','realSubresourcesKeepTheirMIMETypesAndUnknownHTMLIsNotAnImage']:assert re.search(r'Test '+function+r'\(\) passed',log)
arch=json.loads((p/'native-architecture.json').read_text());assert arch=={'execution_architecture':'arm64','binary_architectures':['arm64'],'only_active_arch':True,'app_sha256':initial_identity['app_sha256']}
summary=dict(legacy_summary,all_actual_phase_compiled_blobs_downloaded_and_digest_verified=True,actual_raw_result_counts_and_outcomes_independently_verified=True,actual_controlled_image_positive_generations=8,actual_controlled_image_negative_oracles=56,phase_proofs=phase_proofs,scope='First4f9 diagnostic original55/selection/mutant/restoration actual compiled/result evidence only. Separate stagedB is independently checked; no qualification, image cause, earlier-failure waiver or owner/signed acceptance.')
(root/(name.replace('/','--')+'-independently-verified.json')).write_text(json.dumps(summary,indent=2)+'\n');print({k:summary[k] for k in ['source_head','checkout','configuration','mutation_pair','verified_source_hashes','verified_pins','tests','suites']})
