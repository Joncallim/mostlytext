import hashlib,json,pathlib,plistlib,re,subprocess,uuid,zipfile
root=pathlib.Path(__file__).parent
artifact=root/'native-first-artifact/pending-finder-quicklook-cancellation'
repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext'
head='b6445bfbe34f41009fbfa72db339f49c4d91ca4f';base='c1edd7a13424b3f602e4de0fd8a8be5a7aa3db5a';actual='4f7391ffcc8256c99aefeb9516c824c1faf0e20c'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
def read(name):return json.loads((artifact/name).read_bytes())
r=read('receipt.json')
for label,run in [('native',42404172704),('compliance',42404172739)]:
 run_record=json.loads((root/(label+'-first-run.json')).read_bytes())
 assert run_record['id']==run and run_record['head_sha']==head and run_record['run_attempt']==1 and run_record['conclusion']=='success' and run_record['status']=='completed'
assert r['checkout']==actual
assert git('show','-s','--format=%P',actual).decode().strip().split()==[base,head]
assert git('merge-tree','--write-tree',base,head).decode().splitlines()[0]==git('rev-parse',actual+'^{tree}').decode().strip()
assert git('diff','--name-only',base,head,'--','MacDown2','.github/quicklook-reply-probe','.github/scripts/prepare-quicklook-reply-probe.py','.github/workflows/quicklook-reply-probe.yml')==b''
assert r['root_product_tree']==git('rev-parse',base+':MacDown2').decode().strip()
for name,digest in r['source_sha256'].items():assert sha(git('show',actual+':'+name))==digest,(name,'canonical')
for name,digest in r['fixture_source_sha256'].items():assert sha((artifact/'fixture'/name).read_bytes())==digest,(name,'copied')
for name,digest in r['generated_sha256'].items():assert sha((artifact/'fixture'/name).read_bytes())==digest,(name,'generated')
for role,row in r['compiled_before_test'].items():
 raw=(artifact/row['blob']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],role
assert len(r['compiled_before_test'])==12 and r['built']==r['built_before_test']
provider=artifact/r['compiled_before_test']['provider']['blob']
metadata=subprocess.run(['codesign','--display','--entitlements',':-',str(provider)],capture_output=True,check=True)
(root/'actual-downloaded-provider-entitlements.plist').write_bytes(metadata.stdout)
assert plistlib.loads(metadata.stdout)=={'com.apple.security.app-sandbox':True,'com.apple.security.files.user-selected.read-only':True}
for name in ['mostlytext-ql-reply-static.md','mostlytext-ql-reply-cancel.md']:assert (artifact/name).read_bytes()==b'# Hosted Quick Look fixture\n' and sha((artifact/name).read_bytes())==r['selected_fixture_sha256']
owned=read('owned/status.json');identity=read('owned/identity.json');driver=read('host-ui-driver.json');observer=read('observer-result.json')
assert owned['returncode']==0 and owned['timed_out'] is False and owned['cancelled'] is False and owned['app_cleanup_requested']==[]
assert identity['checkout']==driver['checkout']==observer['checkout']==actual and identity['app_sha256']==r['compiled_before_test']['provider']['sha256']
assert identity['command']==driver['command'][5:] and driver['command'][4]=='--'
assert driver['errors']==observer['errors']==[] and driver['ui_started'] is True and driver['ui_supervisor_returncode']==0
assert driver['observer_returncode']==0 and driver['observer_forced_cleanup'] is False and driver['observer_pid']==observer['pid']
assert observer['mode']=='live-ndjson' and observer['timed_out'] is False and observer['stopped_after_ui'] is True
assert observer['stream_forced_cleanup'] is False and observer['stream_unexpected_exit'] is False and observer['stream_returncode']==-15
assert driver['ui_completed_monotonic']<=driver['observer_stop_requested_monotonic']<=observer['stop_signal_monotonic']<=observer['finished_monotonic']
assert 0<observer['admitted_monotonic']-observer['started_monotonic']<5 and observer['elapsed_seconds']<300
assert observer['stream_command']==['/usr/bin/log','stream','--style','ndjson','--level','info','--predicate','(subsystem == "app.mostlytext.qlcancelprobe") OR (subsystem == "app.mostlytext.qlcancelobserver")']
nonce=observer['nonce'];assert str(uuid.UUID(nonce)).upper()==nonce
control_path='/Users/runner/work/_temp/mostlytext-qlcancel/observer-control'
assert observer['control_sha256']==r['compiled_before_test']['observer_control']['sha256']
build=read('observer-control-build.json');assert build['returncode']==0 and 'error' not in build and build['binary_sha256']==observer['control_sha256']
assert build['source_sha256']==r['generated_sha256']['ObserverControl.swift']
assert build['command']==['xcrun','swiftc','-O','-swift-version','6','-strict-concurrency=complete','-warnings-as-errors','-target','arm64-apple-macos26.0','-parse-as-library','/Users/runner/work/_temp/mostlytext-qlcancel/fixture/ObserverControl.swift','-o',control_path]
assert 1<=len(observer['control_attempts'])<=25
for attempt in observer['control_attempts']:
 assert attempt['command']==[control_path,nonce] and attempt['returncode']==0 and attempt['stdout']==attempt['stderr']==''
 assert observer['started_monotonic']<=attempt['started_monotonic']<=attempt['completed_monotonic']<=observer['admitted_monotonic'] and attempt['completed_monotonic']-attempt['started_monotonic']<3
stream=(artifact/'observer-stream.log').read_bytes();assert len(stream)==observer['stream_bytes'] and sha(stream)==observer['stream_sha256'] and stream.endswith(b'\n')
assert (artifact/'observer-stream-errors.txt').read_bytes()==b''
position=0;messages=[];generations=[];echoes=[];provider_events=[]
for line in stream.splitlines(keepends=True):
 position+=len(line)
 if line.startswith(b'Filtering the log data using '):continue
 event=json.loads(line);assert event['subsystem'] in ['app.mostlytext.qlcancelprobe','app.mostlytext.qlcancelobserver'] and event['userID']==501
 if event['subsystem']=='app.mostlytext.qlcancelobserver':
  assert event['eventMessage']=='QL_OBSERVER_CONTROL nonce='+nonce and event['processImagePath']==control_path
  if not echoes:generations.append((position,[]))
  echoes.append(event)
 else:
  assert echoes and event['processImagePath']==identity['app']
  messages.append(event['eventMessage']);provider_events.append(event);generations.append((position,list(messages)))
assert len(generations)==len(observer['snapshots'])<=128
for index,(row,generation) in enumerate(zip(observer['snapshots'],generations)):
 assert row['file']==f'observer-journal/{index:03d}.json' and row['stream_position']==generation[0]
 raw=(artifact/row['file']).read_bytes();v=json.loads(raw)
 assert len(raw)==row['bytes']<=128*1024 and sha(raw)==row['sha256']
 assert v=={'kind':'mostlytext-qlcancel-host-observer','checkout':actual,'sequence':index,'messages':generation[1]}
assert (artifact/'provider-observer.json').read_bytes()==(artifact/observer['snapshots'][-1]['file']).read_bytes()
assert {x.name for x in (artifact/'observer-journal').iterdir()}=={f'{i:03d}.json' for i in range(len(generations))}
controls=read('observer-control-events.json');direct=read('provider-events.json')
for echo in echoes:assert any(all(x.get(k)==echo[k] for k in ['processID','machTimestamp','eventMessage','processImagePath']) for x in controls)
assert [x['eventMessage'] for x in direct]==messages
assert not any('container-launched-invalidates-cold-proof' in x for x in messages)
summary=json.loads((root/'actual-independent-summary.json').read_bytes());assert summary==r['actual_ui_summary']
assert {k:summary[k] for k in ['totalTestCount','passedTests','failedTests','skippedTests','expectedFailures']}=={'totalTestCount':2,'passedTests':2,'failedTests':0,'skippedTests':0,'expectedFailures':0}
observations=[]
for path in (root/'actual-independent-attachments').iterdir():
 if path.suffix=='.json':
  value=json.loads(path.read_bytes())
  if isinstance(value,dict) and value.get('kind')=='mostlytext-qlcancel-observation':observations.append(value)
assert observations==[r['pending_finder_observation']]
o=observations[0];assert o['selected']=='mostlytext-ql-reply-cancel.md' and o['system_task_cancellation_observed'] is False and o['terminal_kind']=='terminal-completed'
assert o['provider_started']<o['observed_pending']<o['escape_sent']<=o['window_closed']<o['provider_terminal']
entries=[]
for message in messages:
 match=re.fullmatch(r'QL_CANCEL_PROBE (pending|handler|terminal-cancelled|terminal-completed) id=(\d+) uptime=([\d.]+)',message)
 if match and int(match[2])==o['request_id']:entries.append((match[1],float(match[3])))
assert entries==[('pending',o['provider_started']),('terminal-completed',o['provider_terminal'])]
assert o['provider_terminal']-o['provider_started']>=10
proof={'head':head,'checkout':actual,'base':base,'tree':git('rev-parse',actual+'^{tree}').decode().strip(),'canonical_inputs':len(r['source_sha256']),'copied_inputs':len(r['fixture_source_sha256']),'generated_inputs':len(r['generated_sha256']),'downloaded_compiled_roles_verified':12,'provider_permissions_exact':True,'raw_native_cases':2,'passed':2,'failed':0,'skipped':0,'expected_failures':0,'actual_cold_Finder_positive':True,'actual_pending_window_Escape_and_disappearance':True,'actual_system_task_cancellation_observed':False,'provider_wait_seconds':o['provider_terminal']-o['provider_started'],'provider_completion_seconds_after_window_closed':o['provider_terminal']-o['window_closed'],'owned_cleanup_forced':False,'control_echo_latency_seconds':observer['admitted_monotonic']-observer['started_monotonic'],'actual_observer_generations':len(generations),'live_vs_direct_provider_log_exact':True,'control_echo_independently_correlated':True,'scope':'Real Finder closure does NOT propagate cancellation to this cooperative async provider on this hosted macOS26.7.2 run. This is scoped negative feasibility evidence, not a production cancellation pass, real-renderer/fallback/failure-once or full QL-REPLY acceptance.'}
(root/'native-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
