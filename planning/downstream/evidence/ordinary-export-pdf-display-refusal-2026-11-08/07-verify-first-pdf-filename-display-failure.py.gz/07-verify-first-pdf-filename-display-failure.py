import hashlib,io,json,pathlib,plistlib,re,subprocess,zipfile
root=pathlib.Path(__file__).parent;a=root/'native-first-artifact/ordinary-release-export-panel';repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext';head='55eb8bf37dbe99eb7f4cbc217d64b305808dfea8';actual='ec02aee7295416e148b815fad5fa13f6750ae112';parent='ed5a9409dcfbe62263dda0dd8157d8ea4f827e7f';git=lambda *x:subprocess.check_output(['git',*x],cwd=repo);sha=lambda b:hashlib.sha256(b).hexdigest();d=json.loads((a/'receipt.json').read_bytes())
for label,run,c in [('native',42423221480,'failure'),('compliance',42423317927,'success')]:
 row=json.loads((root/(label+'-first-run.json')).read_bytes());assert row['id']==run and row['head_sha']==head and row['run_attempt']==1 and row['conclusion']==c
 with zipfile.ZipFile(root/(label+'-complete-first-workflow-logs.zip')) as z:assert z.testzip() is None
assert d['checkout']==actual and git('show','-s','--format=%P',actual).decode().split()==[parent,head]
assert git('rev-parse',actual+'^{tree}').decode().strip()==git('merge-tree','--write-tree',parent,head).decode().splitlines()[0]
assert git('rev-parse',actual+':MacDown2').decode().strip()==git('rev-parse',parent+':MacDown2').decode().strip()==d['ordinary_export']['product_tree']=='1b01b78e3415d8261fa18bfb4c90c180ffa22a7f'
requests=[actual+':'+p for p in sorted(d['source_sha256'])];stream=io.BytesIO(git('cat-file','--batch') if False else subprocess.check_output(['git','cat-file','--batch'],cwd=repo,input=('\n'.join(requests)+'\n').encode()));blobs={}
for request in requests:
 header=stream.readline().split();assert header[1]==b'blob';raw=stream.read(int(header[2]));assert stream.read(1)==b'\n';name=request.split(':',1)[1];assert sha(raw)==d['source_sha256'][name];blobs[name]=raw
assert len(blobs)==1639 and d['pins']==json.loads(blobs['MacDown2/Packages/MacDownKit/Package.resolved'])['pins'] and len(d['pins'])==24
for name,h in d['generated_sha256'].items():assert sha((a/'fixture'/name).read_bytes())==h
for role,row in d['export_compiled_before'].items():
 raw=(a/row['blob']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
assert len(d['export_compiled_before'])==411
settings=next(x['buildSettings'] for x in d['ordinary_export']['actual_build_settings'] if x['target']=='MacDown2');assert settings['CONFIGURATION']=='Release' and not settings.get('SWIFT_ACTIVE_COMPILATION_CONDITIONS','').split() and settings['ONLY_ACTIVE_ARCH']=='YES' and settings['ARCHS']=='arm64' and d['ordinary_export']['actual_executable_architectures']=='arm64'
for label,passed,failed in [('positive',1,0),('export',0,1)]:
 row=d['ui_results'][label];summary=json.loads((root/(label+'-actual-independent-summary.json')).read_bytes());owned=json.loads((a/(label+'-owned/status.json')).read_bytes());assert row['summary']==summary and row['owned']==owned
 assert {k:summary[k] for k in ['totalTestCount','passedTests','failedTests','skippedTests','expectedFailures']}=={'totalTestCount':1,'passedTests':passed,'failedTests':failed,'skippedTests':0,'expectedFailures':0}
 assert owned['returncode']==(65 if failed else 0) and not owned['timed_out'] and not owned['cancelled'] and owned['app_cleanup_requested']==[]
assert d['criteria']=={'benign_control':True,'file_open_acknowledged':True} and d['errors'] and d['passed'] is False
assert [x['operation'] for x in d['applications']]==['launch','inspect','cleanup']
launch,inspection,cleanup=d['applications'];assert inspection['pid']==launch['pid'] and cleanup['pid'] in [launch['pid'],-1]
assert len({(x['birth'],x['executable']) for x in d['applications']})==1
commands={x['label']:x for x in d['commands']}
assert commands['app-cleanup']['command'][-2:]==[str(launch['pid']),str(launch['birth'])]
assert d['applications'][-1]['terminated'] is True
source=a/'documents'/pathlib.PurePosixPath(d['source_file']).name;assert sha(source.read_bytes())==d['source_file_sha256']==d['ordinary_export']['source_sha256'] and {x.name for x in (a/'documents').iterdir()}=={source.name,'ordinary-export.html'}
summary=d['ui_results']['export']['summary'];assert len(summary['testFailures'])==1
assert 'focus-42423221480.pdf' in summary['testFailures'][0]['failureText'] and 'extension hidden' in summary['testFailures'][0]['failureText']
trees=list((root/'export-actual-independent-attachments').glob('*.txt'));assert len(trees)==5
assert any("identifier: 'saveAsNameTextField', value: focus-42423221480," in p.read_text() for p in trees)
import importlib.util,sys
module_path=pathlib.Path('/Volumes/Fast SSD/CORTANA-GitHub/worktrees/github/mostlytext-quicklook-reply-lifecycle/.github/scripts/run-ordinary-export-acceptance.py')
assert sha(module_path.read_bytes())==d['source_sha256']['.github/scripts/run-ordinary-export-acceptance.py']
sys.path.insert(0,str(module_path.parent));spec=importlib.util.spec_from_file_location('actual_html_oracle',module_path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
actual_html=module.validate_html((a/'documents/ordinary-export.html').read_bytes())
proof={'head':head,'actual_checkout':actual,'parent':parent,'canonical_inputs':1639,'pins':24,'generated':13,'actual_downloaded_compiled_roles':411,'actual_ordinary_Release_ARM_no_added_test_flags':True,'actual_benign_positive_passed':True,'actual_Export_case':'FAILED after real HTML save: PDF default filename displays its correct .pdf extension, not an extension-hidden stem','actual_HTML_output':actual_html,'actual_PDF_output':'NOT_RUN after its default-name display assertion; no PDF file exists','source_preserved':True,'actual_observed_displays':'HTML stem hidden initially; actual PDF full .pdf name recorded in raw failure. Contemporaneous post-format trees/screenshots retained.','root_app_termination':'FORCE cleanup command is bound to actual27817/birth; post-termination object reportsPID-1. Not normal Quit or a stable returned-PID proof','owned_UI_no_timeout_or_force':True,'scope':'First actual ordinary HTML save and independent content/structure/UTF8 proof. Full journey FAILS on a private display assumption; no PDF/normalQuit/exactRC/fidelity/resourcebudget acceptance inferred. Complete firsts/raw results/compiled records retained.'}
(root/'first-pdf-filename-display-failure-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof)
