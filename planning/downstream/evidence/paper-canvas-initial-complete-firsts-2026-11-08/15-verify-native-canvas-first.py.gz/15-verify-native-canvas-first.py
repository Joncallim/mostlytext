import gzip,hashlib,json,pathlib,subprocess,zipfile
from PIL import Image
root=pathlib.Path(__file__).parent;a=root/'native_canvas-first-artifact/native-pdf-snapshot-frames';repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext';git=lambda *v:subprocess.check_output(['git',*v],cwd=repo);sha=lambda b:hashlib.sha256(b).hexdigest();head='3c23e399786089d8ae116a00ac2c80c55369ba59';base='f12d6d357a2a67087db7022060fae798733d3ce7';actual='64243d98115552c941d0086d6cfb6c77eb63a33c'
for label,run in [('native_canvas',42434452443),('compliance',42434452331)]:
 d=json.loads((root/(label+'-first-run.json')).read_bytes());assert d['id']==run and d['head_sha']==head and d['run_attempt']==1 and d['conclusion']=='success'
 with zipfile.ZipFile(root/(label+'-complete-first-workflow-logs.zip')) as z:assert z.testzip() is None
r=json.loads((a/'snapshot-frame-receipt.json').read_bytes());o=json.loads((a/'snapshot-frame-observations.json').read_bytes());assert r['checkout']==actual and git('show','-s','--format=%P',actual).decode().split()==[base,head]
tree=git('rev-parse',actual+'^{tree}').decode().strip();assert tree==git('merge-tree','--write-tree',base,head).decode().splitlines()[0]==git('rev-parse',head+'^{tree}').decode().strip();assert git('rev-parse',actual+':MacDown2/Packages')==git('rev-parse',base+':MacDown2/Packages')
assert len(r['source_sha256'])==8
for p,h in r['source_sha256'].items():assert sha(git('show',actual+':'+p))==h,p
assert r['compiled_sha256']==sha((a/'read-snapshot-frames').read_bytes())
for name,h in r['output_sha256'].items():assert sha((a/name).read_bytes())==h,name
assert r['native_returncode']==0 and r['timed_out'] is False and r['complete_comparison'] and r['diagnostic_only'] is True and r['qualification_candidate'] is False
assert o['diagnostic_only'] is True and o['qualification_candidate'] is False and o['paper_size']==[612,792] and o['margins']==[72,72,90,90]
assert sha((a/'original.html').read_bytes())==r['input_sha256']==o['input_sha256']=='7e6cab53fe7ce75713efb9d50aa15c685f8824b8ff59428a8d16930ec70d2d17'
assert len((a/'original.html').read_bytes())==6978 and (a/'native-stdout.log').read_bytes()==(a/'native-stderr.log').read_bytes()==b''
assert [x['case'] for x in o['completed_cases']]==['original','paper','minimal'];counts=[]
for case in o['completed_cases']:
 name=case['case'];snapshot=(a/(name+'-snapshot.pdf')).read_bytes();output=(a/(name+'-paginated.pdf')).read_bytes();assert len(snapshot)==case['snapshot_bytes'] and sha(snapshot)==case['snapshot_sha256'] and len(output)==case['paginated_bytes'] and sha(output)==case['paginated_sha256']
 assert len(case['pages'])==(2 if name=='original' else 1)
 ink=[]
 for i,page in enumerate(case['pages']):
  png=a/f'{name}-page-{i+1}.png';im=Image.open(png).convert('RGB');assert im.size==(612,792);nonwhite=sum(min(x)<245 for x in im.getdata());assert nonwhite==page['actual_raster_nonwhite_pixels'];ink.append(nonwhite)
 counts.append({'case':name,'view_height':case['view_height'],'snapshot_box':case['snapshot_media_box'],'pages':len(case['pages']),'independent_ink':ink})
assert counts[0]['snapshot_box']==[0,0,794,1123] and counts[0]['independent_ink']==[3692,0]
assert counts[1]['snapshot_box']==[0,0,794,1038] and counts[1]['independent_ink']==[3692]
assert counts[2]['snapshot_box']==[0,0,777,353] and counts[2]['independent_ink']==[3828]
assert sha((a/'original-page-1.png').read_bytes())==sha((a/'paper-page-1.png').read_bytes())=='99297b58780851bf0380dfdf0520ac5e4646c9e1389de396e5893d99e5996a93'
assert sha((a/'original-page-2.png').read_bytes())=='76ec13570f71a5c099ba73c95ec5e81bad1964f49dd29b93259da94ac260bbce'
proof={'source':head,'base':base,'actual_checkout':actual,'actual_source_tested_computed_tree':tree,'eight_canonical_source_bindings':True,'downloaded_actual_helper_bytes_verified':True,'all_original_input_and_generated_output_hashes_verified':True,'complete_native_and_compliance_firsts':'PASS','production_geometry_changed_as_reviewed_packages_pins_project_unchanged':True,'actual_native_stderr':'empty','cases':counts,'mechanism':'Original fixed canvas reproduces exact original two page PNG hashes. Actual-paper canvas produces one page byte-identical PNG to original page1; minimal canvas changes width and pixels.','limits':'Native mechanism proof only; historical normal-print/fallback branch remains unobserved. This observes actual production viewport helper but not the whole ordinary export/normalQuit/final signing.'}
(root/'first-native-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
