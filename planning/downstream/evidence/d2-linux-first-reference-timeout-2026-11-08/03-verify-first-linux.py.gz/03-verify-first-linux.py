from pathlib import Path
import json,subprocess,hashlib,zipfile
root=Path(__file__).parent;a=root/'linux-first-artifact/fixed-d2-linux-reference-first';repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext'
git=lambda *v:subprocess.check_output(['git',*v],cwd=repo)
sha=lambda b:hashlib.sha256(b).hexdigest()
r=json.loads((a/'diagnostic-receipt.json').read_bytes());head='020c85f4f79f938120369ab4dbc95aee877f6ecc'
run=json.loads((root/'linux-first-run.json').read_bytes());assert run['id']==42416059214 and run['head_sha']==head and run['run_attempt']==1 and run['status']=='completed' and run['conclusion']=='failure'
with zipfile.ZipFile(root/'linux-complete-first-workflow-logs.zip') as z:assert z.testzip() is None
assert r['checkout']==head and r['uid']==1001 and r['account']=='runner' and r['native_qualification'] is False
for name,h in r['source_sha256'].items():assert sha(git('show',head+':'+name))==h,name
for name,h in r['copied_sha256'].items():assert sha((a/'fixture'/name).read_bytes())==h,name
assert all(r[k] is True for k in ['source_unchanged_after','copies_unchanged_after','node_unchanged_after','diagnostic_only'])
assert git('diff','d7c45fb4',head,'--','.github/quicklook-jscd2-probe','MacDown2')==b''
phases=json.loads((a/'reference-phases.json').read_bytes());assert len(phases)==15 and [x['phase'] for x in phases][-2:]==['wasm-unpack-start','wasm-unpack-end']
assert phases[-1]['uptime_ms']<1000 and r['returncode']==1 and 'ERR_SCRIPT_EXECUTION_TIMEOUT' in (a/'reference-output.log').read_text()
proof={'head':head,'run':42416059214,'conclusion':'failure','canonical':len(r['source_sha256']),'copied':len(r['copied_sha256']),'all_frozen_D2_host_engine_controls_equal_d7c45fb4':True,'source_copies_node_unchanged_after':True,'phase_count':15,'wasm_unpack_seconds':(phases[-1]['uptime_ms']-phases[-2]['uptime_ms'])/1000,'last_phase':'wasm-unpack-end','last_phase_process_uptime_ms':phases[-1]['uptime_ms'],'reference_failure':'VM15000ms timeout after unpack completed; exact subsequent phase unobserved','native_qualification':False,'complete_first_retained':True,'scope':'Independent Linux reference diagnostic, not Mac native timing/compatibility or production acceptance.'}
(root/'first-linux-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof)
