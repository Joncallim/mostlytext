from pathlib import Path
import json,subprocess,hashlib,plistlib,zipfile
root=Path(__file__).parent;a=root/'native-first-artifact/javascriptcore-d2-quicklook-compatibility';repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext'
git=lambda *x:subprocess.check_output(['git',*x],cwd=repo)
sha=lambda b:hashlib.sha256(b).hexdigest()
head='42d7a806a5a184fab05e4e47bd1d2a589b1f9225';base='5115e73409d78d53fbc9ee52b37e9c98d7169594';actual='1cb1923b973f59797ccdf3f1bc27f2426f533d6e';r=json.loads((a/'receipt.json').read_bytes())
for label,run,c in [('native',42417108375,'failure'),('compliance',42417108349,'success')]:
 d=json.loads((root/(label+'-first-run.json')).read_bytes());assert d['id']==run and d['head_sha']==head and d['run_attempt']==1 and d['status']=='completed' and d['conclusion']==c
 with zipfile.ZipFile(root/(label+'-complete-first-workflow-logs.zip')) as z:assert z.testzip() is None
assert r['checkout']==actual and git('show','-s','--format=%P',actual).decode().strip().split()==[base,head]
assert git('rev-parse',actual+'^{tree}').decode().strip()==git('merge-tree','--write-tree',base,head).decode().splitlines()[0]
for name,h in r['source_sha256'].items():assert sha(git('show',actual+':'+name))==h
for key in ['fixture_source_sha256','generated_sha256']:
 for name,h in r[key].items():assert sha((a/'fixture'/name).read_bytes())==h
for role,row in r['compiled_before_test'].items():
 raw=(a/row['blob']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],role
assert [len(r[k]) for k in ['source_sha256','fixture_source_sha256','generated_sha256','compiled_before_test']]==[29,20,23,69]
expected=['host.js','control.js','d2-browser.js','D2-LICENSE.txt','D2-NOTICE.txt','THIRD_PARTY_NOTICES.md']
assert all(not any(role.endswith('/Contents/Resources/'+name) for role in r['compiled_before_test']) for name in expected)
project=(a/'fixture/QuickLookReplyProbe.xcodeproj/project.pbxproj').read_text();assert 'PBXResourcesBuildPhase' not in project and all(name not in project for name in expected)
ref=r['reference_module'];assert ref['returncode']==0 and ref['copy_controls']['result']['passed']==12 and ref['copy_controls']['result']['failed']==0
svg=(a/'reference-actual.svg').read_bytes();assert len(svg)==ref['result']['svg_bytes']==10928 and sha(svg)==ref['result']['svg_sha256']==r['reference_module']['actual_reference_svg_sha256']
provider=a/r['compiled_before_test']['provider']['blob'];e=subprocess.run(['codesign','--display','--entitlements',':-',str(provider)],capture_output=True,check=True);(root/'actual-downloaded-provider-entitlements.plist').write_bytes(e.stdout);assert plistlib.loads(e.stdout)=={'com.apple.security.app-sandbox':True,'com.apple.security.files.user-selected.read-only':True}
summary=json.loads((root/'actual-independent-summary.json').read_bytes());assert {k:summary[k] for k in ['totalTestCount','passedTests','failedTests','skippedTests','expectedFailures']}=={'totalTestCount':2,'passedTests':1,'failedTests':1,'skippedTests':0,'expectedFailures':0}
assert len(summary['testFailures'])==1 and summary['testFailures'][0]['testIdentifierString'].startswith('JSCD2FinderTests/')
owned=json.loads((a/'owned/status.json').read_bytes());assert owned['returncode']==65 and not owned['timed_out'] and not owned['cancelled'] and owned['app_cleanup_requested']==[]
events=json.loads((a/'provider-events.json').read_bytes());messages=[x['eventMessage'] for x in events];assert sum('callback id=' in x for x in messages)==2 and any('factory id=1' in x for x in messages) and not any('QL_JSCD2_PROBE' in x for x in messages)
proof={'head':head,'actual_checkout':actual,'canonical':29,'copied':20,'generated':23,'actual_downloaded_compiled_roles':69,'full_inventory_correctly_records_missing_mandatory_assets':expected,'actual_generated_project_has_resource_copy_phase':False,'reference_copy_controls_passed':12,'actual_reference_svg_bytes_and_hash_verified':True,'actual_native_cases':2,'passed':1,'failed':1,'skipped':0,'expected_failures':0,'cold_static_Finder_positive':True,'rich_case_failed':'Missing fixture packaging: no JS/assets are in the built provider, no D2 phase observed','native_D2_script_evaluation':'NOT_REACHED','provider_permissions_exact':True,'owned_no_forced_cleanup':True,'complete_firsts_retained':True,'scope':'Actual private resource packaging/preflight defect, not JavaScriptCore/WASM or async-loop refusal. No backfilled resources, native pass, relaxed assertion/deadline or production claim.'}
(root/'first-packaging-failure-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof)
