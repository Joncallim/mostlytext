import hashlib,json,pathlib,subprocess,zipfile
from PIL import Image
root=pathlib.Path(__file__).parent;a=root/'native_canvas-first-artifact/native-pdf-snapshot-frames';repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext';sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *v:subprocess.check_output(['git',*v],cwd=repo)
head='932d5ca62a4c636a04e5c06b8307f802cdd66f13';base='f12d6d357a2a67087db7022060fae798733d3ce7';actual='2728ba604d8af75e06d00c57880876a23d1794c3'
for label,run in [('native_canvas',42438391343),('compliance',42438391329)]:
 d=json.loads((root/(label+'-first-run.json')).read_bytes());assert d['id']==run and d['head_sha']==head and d['run_attempt']==1 and d['conclusion']=='success'
 with zipfile.ZipFile(root/(label+'-complete-first-workflow-logs.zip')) as z:assert z.testzip() is None
r=json.loads((a/'snapshot-frame-receipt.json').read_bytes());o=json.loads((a/'snapshot-frame-observations.json').read_bytes());assert r['checkout']==actual and git('show','-s','--format=%P',actual).decode().split()==[base,head]
tree=git('rev-parse',actual+'^{tree}').decode().strip();assert tree==git('merge-tree','--write-tree',base,head).decode().splitlines()[0]==git('rev-parse',head+'^{tree}').decode().strip()
fixed=['.github/hosted-export-acceptance/ReadSnapshotFrames.swift','MacDown2/MacDown2/PDFSnapshotFallback.swift','MacDown2/MacDown2/PDFExportAdapter.swift','MacDown2/Packages/MacDownKit/Sources/ExportService/PDFCanvasStylesheet.swift','.github/scripts/read-pdf-snapshot-frames.py','.github/scripts/test-pdf-snapshot-result.py','.github/scripts/test-actual-export-pdf-readback.py','.github/scripts/read-actual-export-pdf.py','.github/scripts/prepare-hosted-public-focus.py','.github/workflows/pdf-snapshot-frames.yml','planning/downstream/evidence/actual-ordinary-export-pdf-2026-11-08/manifest.json']
# The input manifest path is pinned by the actual reader module's packet, never guessed from receipt contents.
reader=git('show',actual+':.github/scripts/read-actual-export-pdf.py').decode();import re
packet=re.search(r"PACKET = .* / '([^']+)'",reader)
if packet: fixed[-1]=packet.group(1)+'/manifest.json'
# Verify exact producer path literal independently when the constant uses a joined path.
manifest_paths=[p for p in r['source_sha256'] if p.endswith('/manifest.json') and 'pdf-scrollbar-prototype' not in p];assert len(manifest_paths)==1
assert manifest_paths[0] in reader or manifest_paths[0].rsplit('/',1)[0] in reader
fixed[-1]=manifest_paths[0]
expected=set(fixed)|set(git('ls-tree','-r','--name-only',actual,'--','planning/downstream/evidence/pdf-scrollbar-prototype-qualified-2026-11-08').decode().splitlines());assert set(r['source_sha256'])==expected
for p,h in r['source_sha256'].items():assert sha(git('show',actual+':'+p))==h,p
assert r['compiled_sha256']==sha((a/'read-snapshot-frames').read_bytes())
for p,h in r['output_sha256'].items():assert sha((a/p).read_bytes())==h,p
assert r['native_returncode']==0 and r['timed_out'] is False and r['complete_comparison'] and r['rendering_regression_controls_passed'] and r['diagnostic_only'] is True and r['qualification_candidate'] is False
assert (a/'native-stdout.log').read_bytes()==(a/'native-stderr.log').read_bytes()==b''
assert sha((a/'original.html').read_bytes())=='7e6cab53fe7ce75713efb9d50aa15c685f8824b8ff59428a8d16930ec70d2d17'
assert [c['case'] for c in o['completed_cases']]==['original','paper','minimal','boundary-original','boundary-paper','css-paper','css-boundary-paper'];rows={}
for c in o['completed_cases']:
 name=c['case'];data=(a/(name+'-hardened.html')).read_bytes();assert len(data)==c['hardened_html_bytes'] and sha(data)==c['hardened_html_sha256']
 html=data.decode();assert html.count('BOUNDARY_REVIEW_CANARY')==(20 if 'boundary' in name else 0)
 assert html.count('<style>html { scrollbar-width: none !important; }</style>')==(1 if name.startswith('css-') else 0)
 for suffix,size,digest in [('snapshot',c['snapshot_bytes'],c['snapshot_sha256']),('paginated',c['paginated_bytes'],c['paginated_sha256'])]:
  raw=(a/(name+'-'+suffix+'.pdf')).read_bytes();assert len(raw)==size and sha(raw)==digest
 wanted={'original':[3692,0],'paper':[3692],'minimal':[3828],'boundary-original':[15482,0],'boundary-paper':[15798,0],'css-paper':[3692],'css-boundary-paper':[15482,0]}[name];assert len(c['pages'])==len(wanted);hashes=[]
 for i,p in enumerate(c['pages']):
  png=a/f'{name}-page-{i+1}.png';im=Image.open(png).convert('RGB');assert im.size==(612,792);assert sum(min(x)<245 for x in im.getdata())==p['actual_raster_nonwhite_pixels']==wanted[i];hashes.append(sha(png.read_bytes()))
 rows[name]={'box':c['snapshot_media_box'],'ink':wanted,'png':hashes,'text':[p['raw_text'] for p in c['pages']]}
assert rows['css-paper']['box']==[0,0,794,1038] and rows['css-boundary-paper']['box']==[0,0,794,1053]
assert rows['boundary-paper']['box']==[0,0,777,1053]
assert rows['css-paper']['png']==rows['original']['png'][:1] and rows['css-paper']['text']==rows['original']['text'][:1]
assert rows['css-boundary-paper']['png']==rows['boundary-original']['png'] and rows['css-boundary-paper']['text']==rows['boundary-original']['text']
proof={'source':head,'actual_checkout':actual,'base':base,'tested_source_computed_tree':tree,'canonical_source_bindings':len(expected),'downloaded_actual_helper_and_every_input_output_hash_verified':True,'all_seven_actual_native_controls':'PASS','cases':rows,'scope':'Production viewport and shared stylesheet compiled directly; exact reference short/boundary PNGs and text restored, authored2pages retained. Not whole ordinary-menu/normalQuit/finalRC acceptance.'}
(root/'first-native-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({k:v for k,v in proof.items() if k!='cases'},indent=2))
