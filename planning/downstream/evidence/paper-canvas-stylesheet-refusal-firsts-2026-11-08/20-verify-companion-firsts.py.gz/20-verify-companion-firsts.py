import hashlib,io,json,pathlib,re,subprocess,zipfile
root=pathlib.Path(__file__).parent;repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext';head='932d5ca62a4c636a04e5c06b8307f802cdd66f13';actual='2728ba604d8af75e06d00c57880876a23d1794c3';git=lambda *v:subprocess.check_output(['git',*v],cwd=repo);sha=lambda b:hashlib.sha256(b).hexdigest();canonical=json.loads(git('show',head+':MacDown2/Packages/MacDownKit/Package.resolved'))['pins']
proof={}
for label,run,conclusion in [('compliance',42438391329,'success'),('native_canvas',42438391343,'success'),('native_pdf',42438391296,'success'),('public_CLI',42438391307,'success'),('heading_anchors',42438391292,'success'),('full_CI',42438391290,'failure'),('shared_math_heading',42438391349,'success')]:
 d=json.loads((root/(label+'-first-run.json')).read_bytes());assert d['id']==run and d['head_sha']==head and d['run_attempt']==1 and d['conclusion']==conclusion and d['status']=='completed',label
 with zipfile.ZipFile(root/(label+'-complete-first-workflow-logs.zip')) as z:assert z.testzip() is None
 proof[label]={'run':run,'complete_first':conclusion,'whole_log_archive_sha256':sha((root/(label+'-complete-first-workflow-logs.zip')).read_bytes())}

def sources(receipt,expected):
 assert receipt['checkout']==actual and set(receipt['source_sha256'])==expected
 stream=io.BytesIO(git('cat-file','--batch') if False else subprocess.check_output(['git','cat-file','--batch'],cwd=repo,input=''.join(head+':'+p+'\n' for p in sorted(expected)).encode()))
 for p in sorted(expected):
  header=stream.readline().split();assert header[1]==b'blob';raw=stream.read(int(header[2]));assert stream.read(1)==b'\n' and sha(raw)==receipt['source_sha256'][p],p
for p in sorted((root/'heading_anchors-first-artifact').glob('*/receipt.json')):
 r=json.loads(p.read_bytes());allnames=git('ls-tree','-r','--name-only',head,'--','MacDown2/Packages/MacDownKit').decode().splitlines();source_root='MacDown2/Packages/MacDownKit/'
 tests=['Tests/ExportServiceTests/'+n for n in ['HeadingAnchorPreparationTests.swift','HeadingFragmentStructureTests.swift','HeadingPublicationIntegrationTests.swift','HeadingPreparationWorkerTests.swift','HeadingSVGNamespaceTests.swift','ExportTestSupport.swift']]+['Tests/PreviewTests/'+n for n in ['PreviewHeadingLinkTests.swift','PreviewLinkActionTests.swift','QueuedHeadingJumpTests.swift']]+['Tests/ContributionsTests/TOCLinkedContributionTests.swift']
 expected={x for x in allnames if x.startswith(source_root+'Sources/') and x.endswith('.swift')}|{source_root+'Package.swift'}|{source_root+t for t in tests};sources(r,expected)
 assert r['pins']=={p['identity']:[p['location'],p['state']['revision']] for p in canonical};assert json.loads((p.parent/'Package.resolved').read_bytes())['pins']==canonical
 log=(p.parent/'probe.log').read_text();assert re.search(r'Test run with 68 tests in 9 suites passed',log) and not re.search(r'✘|recorded an issue|(?:Test|Suite)[^\n]*\b(?:skipped|disabled)\b',log,re.I)
 proof.setdefault('heading_actual_configurations',[]).append({'configuration':p.parent.name,'canonical_sources':len(expected),'actual_tests':68,'actual_suites':9,'pins':24,'limits':'No downloaded compiled binary/raw test bundle; actual complete native Swift test log and source/pin receipts'})
for p in sorted((root/'shared_math_heading-first-artifact').glob('*/receipt.json')):
 r=json.loads(p.read_bytes());expected=set(git('ls-tree','-r','--name-only',head,'--','MacDown2','.github/scripts/verify-shared-app-probe.py','.github/workflows/shared-math-app-integration.yml','.github/scripts/run-owned-app-tests.py','.github/scripts/test-run-owned-app-tests.py').decode().splitlines());sources(r,expected);assert r['pins']==canonical
 log=(p.parent/'probe.log').read_text();assert re.search(r'Test run with 29 tests in 9 suites passed',log) and not re.search(r'✘|recorded an issue|(?:Test|Suite)[^\n]*\b(?:skipped|disabled)\b',log,re.I)
 assert 'TOC-PHASE configuration='+r['configuration'] in log
 status=json.loads((p.parent/'diagnostics/status.json').read_bytes());identity=json.loads((p.parent/'diagnostics/identity.json').read_bytes());assert identity['checkout']==actual and status['returncode']==0 and status['timed_out'] is False and status['cancelled'] is False and status['app_cleanup_requested']==[] and 0<status['elapsed_seconds']<600
 cmd=identity['command'];assert cmd[0]=='xcodebuild' and cmd[cmd.index('-configuration')+1]==r['configuration'] and 'test-without-building' in cmd
 proof.setdefault('shared_actual_configurations',[]).append({'configuration':r['configuration'],'canonical_sources':len(expected),'actual_tests':29,'actual_suites':9,'pins':24,'owned':status,'limits':'Actual app/helper hashes are runner records, no downloaded binary-byte claim in this lane'})
assert len(proof['heading_actual_configurations'])==len(proof['shared_actual_configurations'])==2
with zipfile.ZipFile(root/'full_CI-complete-first-workflow-logs.zip') as z:
 logs='\n'.join(z.read(n).decode(errors='replace') for n in z.namelist() if n.startswith('build-and-test/') and 'Package build' in n)
assert 'Test run with 3721 tests in 537 suites failed' in logs and 'with 1 issue.' in logs
assert 'pdfCanvasPolicyIsCoveredBySVGValidationAndLeavesHTMLScrollbarsAlone() recorded an issue' in logs
package=root/'full_CI-first-artifact/owned-package-test-result-42438391290-1';identity=json.loads((package/'identity.json').read_bytes());status=json.loads((package/'status.json').read_bytes());assert status['returncode']==1
proof['actual_failed_CI']={'package_test_count':3721,'package_suites':537,'issues':1,'failed_function':'pdfCanvasPolicyIsCoveredBySVGValidationAndLeavesHTMLScrollbarsAlone','app_tests':'NOT_RUN after package failure','actual_owned_package_status':status,'actual_owned_identity':identity}
proof['source']=head;proof['actual_checkout']=actual;proof['qualification']='NOT_READY: genuine new integration refusal; all prior outcomes retained, no waiver/unchanged retry';proof['scope']='Independent readback of source/pins/raw native logs and owned status; production fix not yet merged and no whole issue closure'
(root/'all-seven-firsts-independently-reviewed.json').write_text(json.dumps(proof,indent=2)+'\n');print('All seven actual whole firsts reviewed; one genuine CI refusal, no waiver')
