import importlib.util,sys,unittest
from pathlib import Path
sys.dont_write_bytecode=True
repo=Path('/Volumes/Fast SSD/CORTANA-GitHub/worktrees/github/mostlytext-quicklook-reply-lifecycle')
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
tests=module('inventory_tests',repo/'.github/scripts/test-quicklook-cancellation-probe.py')
if sys.argv[1]=='before':tests.MODULE=module('old_inventory',Path(__file__).with_name('old-preparation.py'))
result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(tests.ExecutionInputInventoryTests))
expected=3 if sys.argv[1]=='before' else 0
if len(result.failures)!=expected or result.errors or result.testsRun!=4:raise RuntimeError('Actual before/after capture discrimination differs')
print('Actual pure inventory control',sys.argv[1],'failures',len(result.failures),'of',result.testsRun)
