from pathlib import Path
import hashlib,json,plistlib,subprocess,zipfile
root=Path(__file__).parent;a=root/'native-first-artifact/actual-renderer-quicklook-deadline';repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext'
r=json.loads((a/'receipt.json').read_bytes());head='9132b7302084f288b701d3a3f9b45808bf1f7af5';base='52652b07ff2d3b953e137e82836b544bdfb79786';actual='e5226ab488e985ee4c8c8763671a4c6b1463df58'
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
def sha(raw):return hashlib.sha256(raw).hexdigest()
assert r['checkout']==actual and git('show','-s','--format=%P',actual).decode().strip().split()==[base,head]
assert git('merge-tree','--write-tree',base,head).decode().splitlines()[0]==git('rev-parse',actual+'^{tree}').decode().strip()
names=list(r['source_sha256']);data=git('cat-file','--batch') if not names else subprocess.check_output(['git','cat-file','--batch'],input=('\n'.join(actual+':'+n for n in names)+'\n').encode(),cwd=repo)
position=0
for name in names:
 end=data.index(b'\n',position);fields=data[position:end].split();assert fields[1]==b'blob',name
 count=int(fields[2]);start=end+1;raw=data[start:start+count];assert sha(raw)==r['source_sha256'][name],name;position=start+count+1
assert position==len(data)
for name,expected in r['fixture_source_sha256'].items():
 raw=(a/'original-project.yml.txt').read_bytes() if name=='project.yml' else (a/'fixture'/name).read_bytes()
 assert sha(raw)==expected,name
for name,expected in r['generated_sha256'].items():assert sha((a/'fixture'/name).read_bytes())==expected,name
lock=json.loads(git('show',actual+':MacDown2/Packages/MacDownKit/Package.resolved'));assert lock['pins']==r['package_pins'] and len(lock['pins'])==24
assert sha(git('show',actual+':MacDown2/Packages/MacDownKit/Package.resolved'))==r['package_lock_sha256']
assert plistlib.loads((a/'provider-actual-entitlements.plist').read_bytes())=={'com.apple.security.app-sandbox':True,'com.apple.security.files.user-selected.read-only':True}
gate=json.loads((a/'gate-controls.json').read_bytes());assert gate['build_returncode']==1 and gate['phases']==[]
for name,digest in gate['sources'].items():assert sha((a/'fixture'/name.split('/fixture/')[1]).read_bytes())==digest
error=(a/'gate-controls-build.log').read_text();assert "passing closure as a 'sending' parameter risks causing data races" in error and "closure captures 'selected'" in error
z=zipfile.ZipFile(root/'native-complete-first-workflow-logs.zip');build=z.read(next(n for n in z.namelist() if n.startswith('cold-finder/') and 'Compile and ad-hoc' in n)).decode('utf-8-sig');assert '** TEST BUILD SUCCEEDED **' in build and 'Actual hosted gate controls did not compile' in build
for label,conclusion in [('native','failure'),('compliance','success')]:
 run=json.loads((root/(label+'-first-run.json')).read_bytes());assert run['head_sha']==head and run['run_attempt']==1 and run['status']=='completed' and run['conclusion']==conclusion
assert not (a/'Finder.xcresult').exists() and not (a/'owned').exists() and 'compiled_before_test' not in r
proof={'head':head,'actual_checkout':actual,'canonical_inputs_verified':len(names),'copied_source_inputs_verified':len(r['fixture_source_sha256']),'generated_inputs_verified':len(r['generated_sha256']),'locked_pins_verified':24,'actual_fixture_build':'TEST BUILD SUCCEEDED','provider_recorded_permissions_exact':True,'primary_failure':'Hosted Swift6.2 optimized emission rejects TaskGroup closure capturing main-actor local noncopyable Mutex selection counter; no runtime data race is claimed.','gate_console_compilation_returncode':1,'gate_console_modes':'NOT_RUN','actual_Finder_and_renderer_runtime':'NOT_RUN','complete_compiled_role_inventory':'NOT_RETAINED because helper build refused before final capture; never called qualified runtime proof','secondary_post_failure':'Missing built_before_test field after helper refusal; complete original raw failure retained','scope':'First native failure remains failure. Correct only explicit Sendable reference ownership of the shared counter and preserve built bundle bytes before helper refusal; keep64tasks/assertions/strict/O/hostguards/nativebounds/product unchanged.'}
(root/'first-refusal-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
