import ast,collections,hashlib,importlib.util,io,json,pathlib,re,subprocess,zipfile
root=pathlib.Path(__file__).parent;repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext';fork='/Volumes/Fast SSD/CORTANA-GitHub/Textual-attachment-publication';head='b752b5c08ff54b25cc184164411d91fe6da3fe1e';base='6cad56275c1d9a71a9ee95daa066bd1fcae68965';pin='dd123d4f7052d84032cafb22c62cd467916518dd';sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *v:subprocess.check_output(['git',*v],cwd=repo)
for label,run,conclusion in [('native',42446874718,'failure'),('compliance',42446879983,'success')]:
 d=json.loads((root/(label+'-first-run.json')).read_bytes());assert d['id']==run and d['head_sha']==head and d['run_attempt']==1 and d['status']=='completed' and d['conclusion']==conclusion
 with zipfile.ZipFile(root/(label+'-complete-first-workflow-logs.zip')) as z:assert z.testzip() is None
assert git('diff','--name-only',base,head,'--','MacDown2').decode().splitlines()==['MacDown2/MacDown2Tests/BufferedPublicationDiagnosticTests.swift','MacDown2/MacDown2Tests/ProductionPreviewResourceRoutingTests.swift','MacDown2/MacDown2Tests/SecuredMarkdownMountedTests+Support.swift']
source=pathlib.Path('/Volumes/Fast SSD/CORTANA-GitHub/worktrees/github/mostlytext-preview-first-failure-diagnostics/.github/scripts/patch-textual-publication-stages.py');assert source.read_bytes()==git('show',head+':.github/scripts/patch-textual-publication-stages.py');spec=importlib.util.spec_from_file_location('frozen_actual_patcher',source);patcher=importlib.util.module_from_spec(spec);spec.loader.exec_module(patcher)
source_ast=ast.parse(git('show',head+':.github/scripts/verify-preview-grant-probe.py'));input_paths=None
for node in ast.walk(source_ast):
 if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=='check_output' and node.args and isinstance(node.args[0],ast.List):
  try:values=ast.literal_eval(node.args[0])
  except ValueError:continue
  if values[:3]==['git','ls-files','-z']:input_paths=values[3:];break
assert input_paths
expected_paths=set(git('ls-tree','-r','--name-only',head,'--',*input_paths).decode().splitlines());canonical_pins=json.loads(git('show',head+':MacDown2/Packages/MacDownKit/Package.resolved'))['pins'];proof={'source':head,'canonical_product_original_tests_pin_graph_base':base,'variants':{}}
for variant in ['original','inline-only','fragment-only']:
 a=root/'native-first-artifact'/('preview-grant-app-tests-Release-revision-'+variant);r=json.loads((a/'receipt.json').read_bytes());m=json.loads((a/'textual-effective-source.json').read_bytes());assert r['checkout']==head and r['diagnostic_variant']==m['variant']==variant and r['effective_textual_source_modified'] is True and r['qualification_candidate'] is False and set(r['source_sha256'])==expected_paths and r['pins']==canonical_pins and len(r['pins'])==24
 stream=io.BytesIO(subprocess.check_output(['git','cat-file','--batch'],cwd=repo,input=''.join(head+':'+p+'\n' for p in sorted(expected_paths)).encode()))
 for p in sorted(expected_paths):
  header=stream.readline().split();assert header[1]==b'blob';raw=stream.read(int(header[2]));assert stream.read(1)==b'\n' and sha(raw)==r['source_sha256'][p],p
 assert m['original_pin']==pin and m['effective_source_modified'] is True and len(m['before'])==296 and len(m['after'])==297
 original_names=subprocess.check_output(['git','ls-tree','-r','--name-only',pin],cwd=fork).decode().splitlines();assert set(original_names)==set(m['before']);assert m['original_tree']==subprocess.check_output(['git','rev-parse',pin+'^{tree}'],cwd=fork).decode().strip()
 stream=io.BytesIO(subprocess.check_output(['git','cat-file','--batch'],cwd=fork,input=''.join(pin+':'+p+'\n' for p in m['before']).encode()))
 for p,row in m['before'].items():
  header=stream.readline().split();assert header[1]==b'blob';raw=stream.read(int(header[2]));assert stream.read(1)==b'\n' and sha(raw)==row['sha256'] and len(raw)==row['bytes'] and raw==(a/row['blob']).read_bytes()
 changed=patcher.transformed({p:(a/m['before'][p]['blob']).read_bytes() for p in patcher.EXPECTED},variant);assert sorted(changed)==m['changed_paths'] and len(changed)==5
 for p,row in m['after'].items():
  raw=(a/row['blob']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256'] and raw==(changed[p] if p in changed else (a/m['before'][p]['blob']).read_bytes())
 assert r['failure_only_assertion_markers'] is True and r['original_assertion_statements_preserved'] is True
 assert not (a/'compiled-initial.json').exists() and not (a/'actual-initial.xcresult').exists() and not (a/'diagnostics/status.json').exists()
 with zipfile.ZipFile(root/'native-complete-first-workflow-logs.zip') as z:
  name=f'preview-consumers (Release, revision, {variant})/8_Compile real app and test bundles.txt'
  raw=z.read(name);log=raw.decode();errors=[l for l in log.splitlines() if 'error:' in l]
  assert len(errors)==1 and "ProductionPreviewResourceRoutingTests.swift:152:13: error: referencing operator function '+'" in errors[0] and '** TEST BUILD FAILED **' in log
  assert not any('11_Execute the actual three consumer paths' in n and variant+')/' in n for n in z.namelist())
 proof['variants'][variant]={'source_bindings':len(expected_paths),'all296original297effective_files_verified':True,'five_exact_transform_files_verified':True,'compile_error':errors[0],'compile_log_sha256':sha(raw),'native_functions_executed':0,'compiled_binding':'NOT_CREATED','native_comparison':'NOT_RUN'}
proof['scope']='All three first variants genuinely fail test compilation at a joined literal not accepted by Swift Testing Comment. No native comparison ran. Full original first logs/artifacts preserved before correction; pin and canonical product unchanged.'
proof['whole_first_archive_sha256']={p.name:sha(p.read_bytes()) for p in root.glob('*complete-first-workflow-logs.zip')}
(root/'all-three-compile-firsts-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
