from pathlib import Path
import json,subprocess,hashlib,plistlib,zipfile
root=Path(__file__).parent;a=root/'native-first-artifact/javascriptcore-d2-quicklook-compatibility';repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext'
git=lambda *x:subprocess.check_output(['git',*x],cwd=repo)
sha=lambda b:hashlib.sha256(b).hexdigest()
head='ee7898a90fde4feed1b7edcffa87c6de3469320e';base='5115e73409d78d53fbc9ee52b37e9c98d7169594';actual='b0fd0bb9f6b9fc63eac7a6df2327994883662594';r=json.loads((a/'receipt.json').read_bytes())
for label,run,c in [('native',42421419006,'failure'),('compliance',42421419136,'success')]:
 d=json.loads((root/(label+'-first-run.json')).read_bytes());assert d['id']==run and d['head_sha']==head and d['run_attempt']==1 and d['status']=='completed' and d['conclusion']==c
 with zipfile.ZipFile(root/(label+'-complete-first-workflow-logs.zip')) as z:assert z.testzip() is None
assert r['checkout']==actual and git('show','-s','--format=%P',actual).decode().strip().split()==[base,head]
assert git('rev-parse',actual+'^{tree}').decode().strip()==git('merge-tree','--write-tree',base,head).decode().splitlines()[0]
for name,h in r['source_sha256'].items():assert sha(git('show',actual+':'+name))==h
for key in ['fixture_source_sha256','generated_sha256']:
 for name,h in r[key].items():assert sha((a/'fixture'/name).read_bytes())==h
for role,row in r['compiled_before_test'].items():
 raw=(a/row['blob']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],role
assert [len(r[k]) for k in ['source_sha256','fixture_source_sha256','generated_sha256','compiled_before_test']]==[31, 21, 24, 75]
expected=['host.js','control.js','d2-browser.js','D2-LICENSE.txt','D2-NOTICE.txt','THIRD_PARTY_NOTICES.md']
for name in expected:
 roles=[row for role,row in r['compiled_before_test'].items() if role.endswith('/Contents/Resources/'+name)];assert len(roles)==1
 raw=(a/roles[0]['blob']).read_bytes();assert raw==(a/'fixture/Resources'/name).read_bytes() and sha(raw)==r['built']['resource_sha256'][name]
project=(a/'fixture/QuickLookReplyProbe.xcodeproj/project.pbxproj').read_text();assert 'PBXResourcesBuildPhase' in project and all(name in project for name in expected)
ref=r['reference_module'];assert ref['returncode']==0 and ref['copy_controls']['result']['passed']==12 and ref['copy_controls']['result']['failed']==0
svg=(a/'reference-actual.svg').read_bytes();assert len(svg)==ref['result']['svg_bytes']==10928 and sha(svg)==ref['result']['svg_sha256']==r['reference_module']['actual_reference_svg_sha256']
provider=a/r['compiled_before_test']['provider']['blob'];e=subprocess.run(['codesign','--display','--entitlements',':-',str(provider)],capture_output=True,check=True);(root/'actual-downloaded-provider-entitlements.plist').write_bytes(e.stdout);assert plistlib.loads(e.stdout)=={'com.apple.security.app-sandbox':True,'com.apple.security.files.user-selected.read-only':True}
summary=json.loads((root/'actual-independent-summary.json').read_bytes());assert {k:summary[k] for k in ['totalTestCount','passedTests','failedTests','skippedTests','expectedFailures']}=={'totalTestCount':2,'passedTests':1,'failedTests':1,'skippedTests':0,'expectedFailures':0}
assert len(summary['testFailures'])==1 and summary['testFailures'][0]['testIdentifierString'].startswith('JSCD2FinderTests/')
owned=json.loads((a/'owned/status.json').read_bytes());assert owned['returncode']==65 and not owned['timed_out'] and not owned['cancelled'] and owned['app_cleanup_requested']==[]
events=json.loads((a/'provider-events.json').read_bytes());messages=[x['eventMessage'] for x in events]
assert sum('callback id=' in x for x in messages)==2 and any('factory id=1' in x for x in messages)
phases=[x.split('phase=',1)[1] for x in messages if x.startswith('QL_JSCD2_PROBE phase=')]
assert phases[-1]=='render-end' and all(name in phases for name in ['engine-ready','compile-end','render-end'])
assert len([x for x in messages if x.startswith('QL_JSCD2_PROBE result id=2 ')])==1 and 'QL_JSCD2_PROBE factory id=2 bytes=11151' in messages
import base64
rows=[json.loads(base64.b64decode(x.split('base64=',1)[1])) for x in messages if x.startswith('QL_JSCD2_PROBE async-control-base64=')]
assert len(rows)==1
control=rows[0];assert control['answer']==42 and control['old_blocking_poll_completed'] is False and all(control[k] is True for k in ['same_thread','exception_absent','rejection_absent','diagnostic_only'])
assert control['module_bytes']==39 and control['module_sha256']=='ccf59f0f7a7625ee380ed228905aadfa11072ac14cea1c53d1e7f3953d4d48c6'
assert 0.25<=control['blocked_elapsed_seconds']<0.5 and 0<control['pumped_elapsed_seconds']<2
chunks=[x for x in messages if x.startswith('QL_JSCD2_PROBE chunk id=2 ')];assert len(chunks)==17
assert sum(x.endswith('<…>') for x in chunks)==16
assert summary['testFailures'][0]['failureText']=='failed - Require actual provider capability metadata, not a simulated JS result'
observer=json.loads((a/'observer-result.json').read_bytes());assert not observer['errors'] and not observer['stream_forced_cleanup'] and not observer['timed_out'] and not observer['stream_unexpected_exit']
for row in observer['snapshots']:
 raw=(a/row['file']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
raw=(a/'observer-stream.log').read_bytes();assert len(raw)==observer['stream_bytes'] and sha(raw)==observer['stream_sha256']
proof={'head':head,'actual_checkout':actual,'canonical':len(r['source_sha256']),'copied':len(r['fixture_source_sha256']),'generated':len(r['generated_sha256']),'actual_downloaded_compiled_roles':len(r['compiled_before_test']),'all_six_actual_resources_present_byte_equal_and_bound':True,'reference_copy_controls_passed':12,'actual_reference_svg_bytes_and_hash_verified':True,'actual_native_cases':2,'passed':1,'failed':1,'skipped':0,'expected_failures':0,'cold_static_Finder_positive':True,'actual_native_phase_history':phases,'actual_same_thread_async_control':control,'actual_D2_phase':'render-end and real11151byte reply factory observed; actual Finder graph visible','record_transport':'16of17base64 log chunks explicitly truncated with actual <…> marker','actual_native_raw_SVG_bytes':'UNAVAILABLE: never backfill with Node SVG or missing bytes','actual_test_failure':'Complete provider metadata reconstruction, after original actual SVG heading assertion succeeded','provider_permissions_exact':True,'owned_no_forced_cleanup':True,'complete_firsts_retained':True,'scope':'Actual native engine/render and public-loop diagnostic positive evidence, but full first qualification FAILS on truncated log transport. No complete native raw-SVG/hash correlation, fidelity, deadline/fallback/worker retirement or production acceptance inferred.'}
(root/'first-log-transport-failure-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof)
