import hashlib,io,json,pathlib,subprocess,zipfile,importlib.util,collections
root=pathlib.Path(__file__).parent;a=root/'native-first-artifact/preview-grant-app-tests-Release-revision';repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext';fork='/Volumes/Fast SSD/CORTANA-GitHub/Textual-attachment-publication';head='f44f01354936d6d0abaf76c5e388249ee295b0d5';base='6cad56275c1d9a71a9ee95daa066bd1fcae68965';pin='dd123d4f7052d84032cafb22c62cd467916518dd';sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *v:subprocess.check_output(['git',*v],cwd=repo)
for label,run in [('native',42435579859),('compliance',42435602291)]:
 d=json.loads((root/(label+'-first-run.json')).read_bytes());assert d['id']==run and d['head_sha']==head and d['run_attempt']==1 and d['conclusion']=='success'
 with zipfile.ZipFile(root/(label+'-complete-first-workflow-logs.zip')) as z:assert z.testzip() is None
r=json.loads((a/'receipt.json').read_bytes());m=json.loads((a/'textual-effective-source.json').read_bytes());obs=json.loads((a/'textual-stage-observations.json').read_bytes());assert r['checkout']==head and r['diagnostic_only'] is True and r['qualification_candidate'] is False and r['effective_textual_source_modified'] is True;assert git('rev-parse',head+':MacDown2')==git('rev-parse',base+':MacDown2')
paths=sorted(r['source_sha256']);stream=io.BytesIO(subprocess.check_output(['git','cat-file','--batch'],cwd=repo,input=''.join(head+':'+p+'\n' for p in paths).encode()))
for p in paths:
 header=stream.readline().split();assert header[1]==b'blob';raw=stream.read(int(header[2]));assert stream.read(1)==b'\n' and sha(raw)==r['source_sha256'][p],p
assert len(paths)==1637 and len(r['pins'])==24 and next(p['state']['revision'] for p in r['pins'] if p['identity']=='textual')==pin
assert m['original_pin']==pin and m['qualification_candidate'] is False and m['effective_source_modified'] is True and len(m['before'])==296 and len(m['after'])==297
assert m['original_tree']==subprocess.check_output(['git','rev-parse',pin+'^{tree}'],cwd=fork).decode().strip()
stream=io.BytesIO(subprocess.check_output(['git','cat-file','--batch'],cwd=fork,input=''.join(pin+':'+p+'\n' for p in m['before']).encode()))
for p,row in m['before'].items():
 header=stream.readline().split();assert header[1]==b'blob';raw=stream.read(int(header[2]));assert stream.read(1)==b'\n' and sha(raw)==row['sha256'] and len(raw)==row['bytes']
missing=[]; downloaded={'before':0,'after':0}
for label in ['before','after']:
 for p,row in m[label].items():
  path=a/row['blob']
  if not path.exists():
   assert any(part.startswith('.') for part in pathlib.Path(p).parts) and p in m['before'] and row['sha256']==m['before'][p]['sha256'] and row['bytes']==m['before'][p]['bytes'];missing.append({'phase':label,'path':p,'manifest_sha256':row['sha256']});continue
  raw=path.read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],p;downloaded[label]+=1
source='/Volumes/Fast SSD/CORTANA-GitHub/worktrees/github/mostlytext-preview-first-failure-diagnostics/.github/scripts/patch-textual-publication-stages.py';assert sha(pathlib.Path(source).read_bytes())==r['source_sha256']['.github/scripts/patch-textual-publication-stages.py'];spec=importlib.util.spec_from_file_location('actual_patch',source);patcher=importlib.util.module_from_spec(spec);spec.loader.exec_module(patcher);expected=patcher.transformed({p:(a/m['before'][p]['blob']).read_bytes() for p in patcher.EXPECTED});assert sorted(expected)==m['changed_paths']
for p,row in m['after'].items():
 if (a/row['blob']).exists():assert (a/row['blob']).read_bytes()==(expected[p] if p in expected else (a/m['before'][p]['blob']).read_bytes())
 else:assert p not in expected
assert len(missing)==22 and downloaded=={'before':285,'after':286}
compiled_raw=(a/'compiled-initial.json').read_bytes();compiled=json.loads(compiled_raw);binding=json.loads((a/'textual-compiled-binding.json').read_bytes());assert binding['effective_source_manifest_sha256']==obs['effective_source_manifest_sha256']==sha((a/'textual-effective-source.json').read_bytes()) and binding['compiled_manifest_sha256']==sha(compiled_raw)
assert compiled['phase']=='initial' and compiled['configuration']=='Release' and len(compiled['inputs'])==5
for role,row in compiled['inputs'].items():
 raw=(a/row['blob']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256']==binding['actual_compiled_role_hashes'][role]
identity=json.loads((a/'diagnostics/identity.json').read_bytes());owned=json.loads((a/'diagnostics/status.json').read_bytes());assert identity['checkout']==head and identity['app_sha256']==compiled['inputs']['app_executable']['sha256'] and owned==obs['actual_owned_status'] and owned['returncode']==0 and not owned['timed_out'] and not owned['cancelled'] and owned['app_cleanup_requested']==[]
raw=subprocess.check_output(['xcrun','xcresulttool','get','test-results','summary','--path',str(a/'actual-initial.xcresult')]);actual=json.loads(raw);assert actual==obs['actual_summary'];assert {k:actual[k] for k in ['totalTestCount','passedTests','failedTests','skippedTests','expectedFailures']}=={'totalTestCount':57,'passedTests':57,'failedTests':0,'skippedTests':0,'expectedFailures':0};(root/'actual-independent-summary.json').write_bytes(raw)
lines=[l for l in (a/'probe.log').read_text().splitlines() if 'TEXTUAL_PUBLICATION' in l];assert lines==obs['actual_trace_lines'] and len(lines)==2957 and obs['trace_limit_reached'] is False
stages=collections.Counter(l.split('stage=')[-1].split()[0] for l in lines if 'stage=' in l)
proof={'source':head,'unchanged_product_test_pin_graph_base':base,'canonical_source_bindings':len(paths),'original_fork_pin':pin,'original_tracked_fork_hash_metadata_verified_against_pin':296,'actual_downloaded_original_files':285,'actual_downloaded_effective_files':286,'hidden_metadata_archive_files_not_uploaded':missing,'all5_actual_modified_effective_Swift_files_exact':True,'exact_transformed_existing_files_plus_helper':len(expected),'all_actual_compiled_roles_downloaded_and_verified':5,'actual_native':'57PASS/0FAIL/0skip/0expected','owned':owned,'trace_count':2957,'trace_stages':dict(stages),'interpretation':'All stages publish during this passing instrumented run; logging can alter timing. This does not reproduce or explain original6cad failures, and is not sole-cause evidence.','diagnostic_only':True,'qualification_candidate':False,'limits':'Original pin metadata is unchanged but effective compiled source IS DELIBERATELY MODIFIED. All5modified Swift files are downloaded/exact;11hidden metadata files per phase were omitted by upload-artifact default, only their pin-matching hash metadata retained. Include hidden controlled archive files before claiming complete source download. Not canonical Preview/fullsixpair/release acceptance.'};(root/'first-native-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
