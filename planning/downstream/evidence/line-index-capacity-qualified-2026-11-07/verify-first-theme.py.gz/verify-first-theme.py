import hashlib,io,json,pathlib,re,subprocess
r=pathlib.Path(__file__).parent;repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext';head='6acab2ec81504ee77ad2888bff2fbf6fbc379483';checkout='34c77b5c181e768f042f28b840914e4c32e136d9';baseline='6667bc9c1cb74534eafc417d921c3a37c55628b0';common='MacDown2/Packages/MacDownKit/Tests/HighlightingTests/CurrentLineRoleBitmapTests.swift'
git=lambda *a:subprocess.check_output(['git',*a],cwd=repo);sha=lambda x:hashlib.sha256(x).hexdigest();paths=['MacDown2','.github/scripts/run-current-line-theme-probe.py','.github/workflows/current-line-theme-probe.yml','.github/scripts/run-owned-app-tests.py','.github/scripts/test-run-owned-app-tests.py'];rows=[];orientations=[]
def contents(commit,names):
 requests=[commit+':'+n for n in names];s=io.BytesIO(subprocess.check_output(['git','cat-file','--batch'],cwd=repo,input=('\n'.join(requests)+'\n').encode()));out={}
 for req in requests:
  h=s.readline().split();assert h[1]==b'blob';raw=s.read(int(h[2]));assert s.read(1)==b'\n';out[req.split(':',1)[1]]=raw
 return out
latest_common=git('show',head+':'+common)
for config in ['debug','release']:
 a=r/'theme-first-artifact'/('current-line-theme-'+config)
 for kind,commit in [('baseline',baseline),('candidate',checkout)]:
  p=a/kind;d=json.loads((p/'receipt.json').read_bytes());expected=set(git('ls-tree','-r','--name-only',commit,'--',*paths).decode().splitlines())|{common};blobs=contents(commit,sorted(expected-{common}));blobs[common]=latest_common
  assert d['checkout']==commit and d['configuration']==config and d['baseline']==(kind=='baseline') and set(d['source_sha256'])==expected
  assert {k:sha(v) for k,v in blobs.items()}==d['source_sha256'] and d['pins']==json.loads(blobs['MacDown2/Packages/MacDownKit/Package.resolved'])['pins']
  if kind=='baseline':copied={'Tests/HighlightingTests/CurrentLineRoleBitmapTests.swift':sha(latest_common)}
  else:copied={n.removeprefix('MacDown2/Packages/MacDownKit/'):sha(raw) for n,raw in blobs.items() if n.endswith('.swift') and any(n.startswith('MacDown2/Packages/MacDownKit/Tests/'+group+'/') for group in ['EditorCoreTests','HighlightingTests','ThemesTests'])}
  assert d['copied_test_sha256']==copied
  status=json.loads((p/'status.json').read_bytes());log=re.sub(r'\x1b\[[0-9;]*m','',(p/'probe.log').read_text())
  if kind=='baseline':
   assert status=={'returncode':1} and re.search('Test run with 2 tests in 1 suite failed .* with 2 issues',log)
   for name in ['anAppliedThemePaintsAndRemovesTheCurrentLineInTheRealScrolledEditor','aShapeIdentifiesThePrimaryLineEvenWhenTheEditorFontIsAlreadyBold']:assert 'Test '+name+'() failed' in log
   for msg in ['production theme application and draw path must paint the current row','current row needs a shape cue beyond font weight']:assert msg in log
  else:
   assert status=={'returncode':0} and 'Test run with 1087 tests in 145 suites passed' in log and 'recorded an issue' not in log
   assert 'Test "keystroke with incremental line-index update stays within budget on a 10 MB document" passed' in log and 'Restarting after unexpected' not in log
   skips=[line.split('➜ ',1)[1] for line in log.splitlines() if '➜ ' in line and line.endswith(' skipped.')]
   old=pathlib.Path('/Volumes/Fast SSD/CORTANA-Builds/current-main-preview-acceptance-20261107/fc29-theme-artifact')/('current-line-theme-'+config)/'candidate/probe.log'
   prior=[line.split('➜ ',1)[1] for line in old.read_text().splitlines() if '➜ ' in line and line.endswith(' skipped.')]
   assert skips==prior, 'No additional skipped declaration is permitted'
   rows.append({'configuration':config,'unchanged_original_opt_in_declarations_not_executed':skips})
  rows.append({'configuration':config,'phase':kind,'checkout':commit,'source_inputs_verified':len(expected),'pins':len(d['pins']),'copied_native_test_hashes_verified':len(copied),'status':status,'actual_issues':[l for l in log.splitlines() if 'recorded an issue' in l],'phase_observations':[l for l in log.splitlines() if 'HIGHLIGHT_PHASE' in l or 'CURRENT-LINE-PHASE' in l],'worker_execution_hash_metadata':d['execution_sha256']})
 records=json.loads((a/'orientation-results.json').read_bytes());source=git('show',checkout+':MacDown2/Packages/MacDownKit/Sources/EditorCore/EditorGutterView.swift');mutant=source.replace(b'cgContext.textMatrix = Self.coreTextMatrix(forFlippedView: isFlipped)',b'cgContext.textMatrix = .identity');assert mutant!=source
 assert len(records)==2
 for row,phase,raw,code in [(records[0],'orientation-mutant',mutant,1),(records[1],'orientation-restored',source,0)]:
  assert row['phase']==phase and row['source_sha256']==sha(raw) and row['returncode']==code
  log=(a/(phase+'.log')).read_text();assert ('Test run with 1 test in 1 suite '+('failed' if code else 'passed')) in log
  if code:assert "the production-drawn '2' must be upright" in log
 assert records[0]['host_sha256']!=records[1]['host_sha256'];orientations.append({'configuration':config,'records':records})
proof={'head':head,'actual_pr_checkout':checkout,'candidate_debug_and_release':'Both complete selections report1087tests/145suites passed, including unchanged50ms10MBincremental-keystroke assertion; original opt-in skipped declarations separately retained','original_baseline_bitmap':'Both original two failures retained in each configuration','rows':rows,'both_orientation_controls':orientations,'scope':'First complete allocation-source native selections. Source/pins/copied-test hashes and raw logs verified; native execution hashes are worker-recorded, not downloaded binaries. No sole cause for old62.876833ms, whole-edit1MBRelease budget, old Debug abort, Preview, owner/signed/final-artifact acceptance inferred.'}
(r/'theme-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({k:v for k,v in proof.items() if k not in ['rows','both_orientation_controls']},indent=2))
