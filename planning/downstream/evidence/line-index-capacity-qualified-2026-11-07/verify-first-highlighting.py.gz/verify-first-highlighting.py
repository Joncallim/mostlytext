import hashlib,io,json,pathlib,re,subprocess
root=pathlib.Path(__file__).parent;repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext';head='6acab2ec81504ee77ad2888bff2fbf6fbc379483';checkout='34c77b5c181e768f042f28b840914e4c32e136d9'
git=lambda *a:subprocess.check_output(['git',*a],cwd=repo);sha=lambda b:hashlib.sha256(b).hexdigest()
paths=['MacDown2','.github/scripts/run-highlight-read-diagnostics.py','.github/scripts/record_highlight_read.py','.github/scripts/test-highlight-replay-result.py','.github/scripts/run-owned-app-tests.py','.github/scripts/test-run-owned-app-tests.py','.github/workflows/highlight-read-diagnostics.yml']
expected=sorted(set(git('ls-tree','-r','--name-only',head,'--',*paths).decode().splitlines()));requests=[head+':'+n for n in expected];s=io.BytesIO(subprocess.check_output(['git','cat-file','--batch'],cwd=repo,input=('\n'.join(requests)+'\n').encode()));blobs={}
for req in requests:
 hdr=s.readline().split();assert hdr[1]==b'blob';raw=s.read(int(hdr[2]));assert s.read(1)==b'\n';blobs[req.split(':',1)[1]]=raw
rows=[]
for config in ['debug','release']:
 p=root/'highlighting-first-artifact'/('controlled-highlight-read-'+config);d=json.loads((p/'receipt.json').read_text())
 assert d['checkout']==checkout and d['configuration']==config and set(d['source_sha256'])==set(expected)
 assert {n:sha(b) for n,b in blobs.items()}==d['source_sha256'] and d['pins']==json.loads(blobs['MacDown2/Packages/MacDownKit/Package.resolved'])['pins']
 copied={}
 for n,raw in blobs.items():
  prefix='MacDown2/Packages/MacDownKit/'
  if not n.startswith(prefix+'Tests/HighlightingTests/') or not n.endswith('.swift'):continue
  executed=raw
  if n.endswith('/NeonReplacementEditTests.swift'):
   annotation=b'@Test(.enabled(if: !isDebugBuild))';assert raw.count(annotation)==1;executed=raw.replace(annotation,b'@Test')
  copied[n.removeprefix(prefix)]={'original_sha256':sha(raw),'executed_sha256':sha(executed)}
 assert copied==d['copied_tests']
 assert d['controlled_replay_qualified'] is True and d['original_assertion_captured'] is False and d['original_trigger_resolved'] is False
 phases=[('direct',d['direct_status'])]+([('probe',d['debugger_status'])] if config=='debug' else [])
 for label,status in phases:
  assert status==json.loads((p/(label+'-diagnostics/status.json')).read_text()) and status['returncode']==0 and not status['timed_out'] and not status['cancelled'] and status['app_cleanup_requested']==[]
  log=(p/(label+'.log')).read_text();assert 'Test run with 2 tests in 2 suites passed' in log and 'recorded an issue at' not in log
  marker=re.search(r'HIGHLIGHT_READ_CONTROL events=(\[[^\n]*\]) sourceBytes=(\d+)',log);assert marker
  events=json.loads(marker[1]);assert events.count('background-held')==1 and 'released' in events and 'hold-timed-out' not in events
  assert not any(t in log for t in ['Program crashed:','stop reason = signal','Fatal error:','Restarting after unexpected'])
  if label=='probe':assert re.search(r'Process \d+ exited with status = 0\b',log)
 assert not (p/'assertion-frame.json').exists()
 rows.append({'configuration':config,'canonical_inputs_verified':len(expected),'pins':len(d['pins']),'copied_original_and_executed_tests_verified':len(copied),'owned_phases_verified':[x[0] for x in phases],'source_assertion_dependency':d['assertion_dependency'],'worker_execution_hashes':d['execution_sha256']})
proof={'head':head,'actual_checkout':checkout,'rows':rows,'scope':'Both strict controlled replays and actual Debug debugger pass with source/pin/copied-test/raw log/owned status checks. The original old Debug assertion is not reproduced or explained. Native binaries and dependency source hashes are worker-recorded, not independently downloaded bytes. No issue19 closure or whole-app/Release50ms inference.'}
(root/'highlighting-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
