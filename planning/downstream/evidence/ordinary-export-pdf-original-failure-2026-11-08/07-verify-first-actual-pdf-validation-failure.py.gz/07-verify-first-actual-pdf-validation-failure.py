import hashlib,io,json,pathlib,plistlib,re,subprocess,zipfile
root=pathlib.Path(__file__).parent;a=root/'native-first-artifact/ordinary-release-export-panel';repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext';head='734db2f2cd083c040365919134163b55ed57f41f';actual='718a7d40433b14594743557f71d5df0f0ccaad2d';parent='ed5a9409dcfbe62263dda0dd8157d8ea4f827e7f';git=lambda *x:subprocess.check_output(['git',*x],cwd=repo);sha=lambda b:hashlib.sha256(b).hexdigest();d=json.loads((a/'receipt.json').read_bytes())
for label,run,c in [('native',42424848502,'failure'),('compliance',42425333637,'success')]:
 row=json.loads((root/(label+'-first-run.json')).read_bytes());assert row['id']==run and row['head_sha']==head and row['run_attempt']==1 and row['conclusion']==c
 with zipfile.ZipFile(root/(label+'-complete-first-workflow-logs.zip')) as z:assert z.testzip() is None
assert d['checkout']==actual and git('show','-s','--format=%P',actual).decode().split()==[parent,head]
assert git('rev-parse',actual+'^{tree}').decode().strip()==git('merge-tree','--write-tree',parent,head).decode().splitlines()[0]
assert git('rev-parse',actual+':MacDown2').decode().strip()==git('rev-parse',parent+':MacDown2').decode().strip()==d['ordinary_export']['product_tree']=='1b01b78e3415d8261fa18bfb4c90c180ffa22a7f'
requests=[actual+':'+p for p in sorted(d['source_sha256'])];stream=io.BytesIO(git('cat-file','--batch') if False else subprocess.check_output(['git','cat-file','--batch'],cwd=repo,input=('\n'.join(requests)+'\n').encode()));blobs={}
for request in requests:
 header=stream.readline().split();assert header[1]==b'blob';raw=stream.read(int(header[2]));assert stream.read(1)==b'\n';name=request.split(':',1)[1];assert sha(raw)==d['source_sha256'][name];blobs[name]=raw
assert len(blobs)==1639 and d['pins']==json.loads(blobs['MacDown2/Packages/MacDownKit/Package.resolved'])['pins'] and len(d['pins'])==24
for name,h in d['generated_sha256'].items():assert sha((a/'fixture'/name).read_bytes())==h
for role,row in d['export_compiled_before'].items():
 raw=(a/row['blob']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
assert len(d['export_compiled_before'])==411
settings=next(x['buildSettings'] for x in d['ordinary_export']['actual_build_settings'] if x['target']=='MacDown2');assert settings['CONFIGURATION']=='Release' and not settings.get('SWIFT_ACTIVE_COMPILATION_CONDITIONS','').split() and settings['ONLY_ACTIVE_ARCH']=='YES' and settings['ARCHS']=='arm64' and d['ordinary_export']['actual_executable_architectures']=='arm64'
for label,passed,failed in [('positive',1,0),('export',1,0)]:
 row=d['ui_results'][label];summary=json.loads((root/(label+'-actual-independent-summary.json')).read_bytes());owned=json.loads((a/(label+'-owned/status.json')).read_bytes());assert row['summary']==summary and row['owned']==owned
 assert {k:summary[k] for k in ['totalTestCount','passedTests','failedTests','skippedTests','expectedFailures']}=={'totalTestCount':1,'passedTests':passed,'failedTests':failed,'skippedTests':0,'expectedFailures':0}
 assert owned['returncode']==(65 if failed else 0) and not owned['timed_out'] and not owned['cancelled'] and owned['app_cleanup_requested']==[]
assert d['criteria']=={'benign_control':True,'file_open_acknowledged':True,'actual_export_save_and_cancel':True} and d['errors'] and d['passed'] is False
assert [x['operation'] for x in d['applications']]==['launch','inspect','cleanup']
launch,inspection,cleanup=d['applications'];assert inspection['pid']==launch['pid'] and cleanup['pid'] in [launch['pid'],-1]
assert len({(x['birth'],x['executable']) for x in d['applications']})==1
commands={x['label']:x for x in d['commands']}
assert commands['app-cleanup']['command'][-2:]==[str(launch['pid']),str(launch['birth'])] and cleanup['terminated'] is True
v=commands['actual-pdfkit-output-validation'];assert v['returncode']==-5 and 'ValidateActualExportPDF.Refusal.invalid' in v['stderr']
source=a/'documents'/pathlib.PurePosixPath(d['source_file']).name;assert sha(source.read_bytes())==d['source_file_sha256']==d['ordinary_export']['source_sha256'] and {x.name for x in (a/'documents').iterdir()}=={source.name,'ordinary-export.html','ordinary-export.pdf'}
import importlib.util,sys
module_path=pathlib.Path('/Volumes/Fast SSD/CORTANA-GitHub/worktrees/github/mostlytext-quicklook-reply-lifecycle/.github/scripts/run-ordinary-export-acceptance.py');assert sha(module_path.read_bytes())==d['source_sha256']['.github/scripts/run-ordinary-export-acceptance.py']
sys.path.insert(0,str(module_path.parent));spec=importlib.util.spec_from_file_location('actual_html_oracle',module_path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
html=module.validate_html((a/'documents/ordinary-export.html').read_bytes())
from pypdf import PdfReader
pdf=a/'documents/ordinary-export.pdf';reader=PdfReader(pdf);assert len(reader.pages)==2
pages=[{'bounds':list(p.mediabox),'extracted_text':p.extract_text()} for p in reader.pages]
assert all('NA TIVE_EXPORT_CANARY' in p['extracted_text'] for p in pages)
proof={'head':head,'actual_checkout':actual,'parent':parent,'canonical_inputs':len(blobs),'pins':24,'generated':len(d['generated_sha256']),'actual_downloaded_compiled_roles':411,'ordinary_Release_ARM_no_added_test_flags':True,'actual_benign_and_full_UI_Save_Cancel_HTML_PDF_cases':{'passed':2,'failed_skipped_expected':0},'source_preserved':True,'actual_HTML_output':html,'actual_PDF':{'bytes':pdf.stat().st_size,'sha256':sha(pdf.read_bytes()),'pages':pages,'actual_original_PDFKit_guard':'FAILED generic Refusal.invalid; not yet attributed to a specific guard','independent_visual_readback':'Actual Poppler pages inspected: correct-looking first page followed by blank second. pypdf repeats clipped form text; not two visibly duplicated pages.','visual_files':['pdf-independent-readback/page-1.png','pdf-independent-readback/page-2.png']},'normal_Quit':'NOT_RUN after actual PDF validation refusal; force cleanup command bound to actual PID/birth, post-termination PID field is-1','whole_journey':'FAILED','scope':'Actual current ordinary menu saves and positive cases only; preserve failure and investigate PDF guard/extra blank page. No PDF acceptance, normalQuit, finalRC, parity or resource-budget claim.'}
(root/'first-actual-pdf-validation-failure-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({k:v for k,v in proof.items() if k!='actual_PDF'},indent=2))
