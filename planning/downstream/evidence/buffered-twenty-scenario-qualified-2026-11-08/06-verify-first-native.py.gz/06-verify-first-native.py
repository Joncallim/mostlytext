import hashlib,io,json,pathlib,subprocess,zipfile,importlib.util,collections
root=pathlib.Path(__file__).parent;a=root/'native-first-artifact/preview-grant-app-tests-Release-revision';repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext';fork='/Volumes/Fast SSD/CORTANA-GitHub/Textual-attachment-publication';head='9cce9dbcea0b85c899c65fb751a42153fa26d546';base='6cad56275c1d9a71a9ee95daa066bd1fcae68965';pin='dd123d4f7052d84032cafb22c62cd467916518dd';sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *v:subprocess.check_output(['git',*v],cwd=repo)
for label,run in [('native',42440909585),('compliance',42440922359)]:
 d=json.loads((root/(label+'-first-run.json')).read_bytes());assert d['id']==run and d['head_sha']==head and d['run_attempt']==1 and d['conclusion']=='success'
 with zipfile.ZipFile(root/(label+'-complete-first-workflow-logs.zip')) as z:assert z.testzip() is None
r=json.loads((a/'receipt.json').read_bytes());m=json.loads((a/'textual-effective-source.json').read_bytes());assert r['checkout']==head and r['diagnostic_only'] is True and r['qualification_candidate'] is False and r['effective_textual_source_modified'] is True;assert git('diff','--name-only',base,head,'--','MacDown2').decode().splitlines()==['MacDown2/MacDown2Tests/BufferedPublicationDiagnosticTests.swift']
paths=sorted(r['source_sha256']);stream=io.BytesIO(subprocess.check_output(['git','cat-file','--batch'],cwd=repo,input=''.join(head+':'+p+'\n' for p in paths).encode()))
for p in paths:
 header=stream.readline().split();assert header[1]==b'blob';raw=stream.read(int(header[2]));assert stream.read(1)==b'\n' and sha(raw)==r['source_sha256'][p],p
assert 'MacDown2/MacDown2Tests/BufferedPublicationDiagnosticTests.swift' in paths and len(paths)>1637 and len(r['pins'])==24 and next(p['state']['revision'] for p in r['pins'] if p['identity']=='textual')==pin
assert m['original_pin']==pin and m['qualification_candidate'] is False and m['effective_source_modified'] is True and len(m['before'])==296 and len(m['after'])==297
assert m['original_tree']==subprocess.check_output(['git','rev-parse',pin+'^{tree}'],cwd=fork).decode().strip()
stream=io.BytesIO(subprocess.check_output(['git','cat-file','--batch'],cwd=fork,input=''.join(pin+':'+p+'\n' for p in m['before']).encode()))
for p,row in m['before'].items():
 header=stream.readline().split();assert header[1]==b'blob';raw=stream.read(int(header[2]));assert stream.read(1)==b'\n' and sha(raw)==row['sha256'] and len(raw)==row['bytes']
missing=[]; downloaded={'before':0,'after':0}
for label in ['before','after']:
 for p,row in m[label].items():
  path=a/row['blob']
  if not path.exists():
   assert any(part.startswith('.') for part in pathlib.Path(p).parts) and p in m['before'] and row['sha256']==m['before'][p]['sha256'] and row['bytes']==m['before'][p]['bytes'];missing.append({'phase':label,'path':p,'manifest_sha256':row['sha256']});continue
  raw=path.read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],p;downloaded[label]+=1
source='/Volumes/Fast SSD/CORTANA-GitHub/worktrees/github/mostlytext-preview-first-failure-diagnostics/.github/scripts/patch-textual-publication-stages.py';assert sha(pathlib.Path(source).read_bytes())==r['source_sha256']['.github/scripts/patch-textual-publication-stages.py'];spec=importlib.util.spec_from_file_location('actual_patch',source);patcher=importlib.util.module_from_spec(spec);spec.loader.exec_module(patcher);expected=patcher.transformed({p:(a/m['before'][p]['blob']).read_bytes() for p in patcher.EXPECTED});assert sorted(expected)==m['changed_paths']
for p,row in m['after'].items():
 if (a/row['blob']).exists():assert (a/row['blob']).read_bytes()==(expected[p] if p in expected else (a/m['before'][p]['blob']).read_bytes())
 else:assert p not in expected
assert len(missing)==0 and downloaded=={'before':296,'after':297}
compiled_raw=(a/'compiled-initial.json').read_bytes();compiled=json.loads(compiled_raw);binding=json.loads((a/'textual-compiled-binding.json').read_bytes());assert binding['effective_source_manifest_sha256']==sha((a/'textual-effective-source.json').read_bytes()) and binding['compiled_manifest_sha256']==sha(compiled_raw)
assert compiled['phase']=='initial' and compiled['configuration']=='Release' and len(compiled['inputs'])==5
for role,row in compiled['inputs'].items():
 raw=(a/row['blob']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256']==binding['actual_compiled_role_hashes'][role]
identity=json.loads((a/'diagnostics/identity.json').read_bytes());owned=json.loads((a/'diagnostics/status.json').read_bytes());assert identity['checkout']==head and identity['app_sha256']==compiled['inputs']['app_executable']['sha256'] and owned['returncode']==0 and not owned['timed_out'] and not owned['cancelled'] and owned['app_cleanup_requested']==[]
raw=subprocess.check_output(['xcrun','xcresulttool','get','test-results','summary','--path',str(a/'actual-initial.xcresult')]);actual=json.loads(raw);assert {k:actual[k] for k in ['totalTestCount','passedTests','failedTests','skippedTests','expectedFailures']}=={'totalTestCount':58,'passedTests':58,'failedTests':0,'skippedTests':0,'expectedFailures':0};(root/'actual-independent-summary.json').write_bytes(raw)


obs=json.loads((a/'textual-stage-observations.json').read_bytes());assert obs['actual_summary']==actual and obs['actual_owned_status']==owned and obs['effective_source_manifest_sha256']==sha((a/'textual-effective-source.json').read_bytes()) and obs['scenario_errors']==[] and obs['trace_limit_reached'] is False
host=json.loads((a/'textual-diagnostic-host.json').read_bytes());assert host==obs['actual_diagnostic_host'];assert {k:host[k] for k in ['uid','effective_uid','user','home','GITHUB_ACTIONS','GITHUB_REPOSITORY','RUNNER_TEMP']}=={'uid':501,'effective_uid':501,'user':'runner','home':'/Users/runner','GITHUB_ACTIONS':'true','GITHUB_REPOSITORY':'Joncallim/mostlytext','RUNNER_TEMP':'/Users/runner/work/_temp'}
names=['initial',*[f'{i:02d}-{j}' for i in range(10) for j in ['production','revision']],'final'];assert [s['scenario'] for s in obs['buffered_scenarios']]==names
counts=[];stages=collections.Counter()
for name,row in zip(names,obs['buffered_scenarios']):
 assert row==json.loads((a/'textual-scenarios'/(name+'.json')).read_bytes()) and row['diagnostic_only'] is True and row['qualification_candidate'] is False and row['threw'] is False and row['overflow'] is False and len(row['events'])<4000
 if name not in ['initial','final']:assert any('attachments-ready' in e and 'attachedRuns=1' in e for e in row['events'])
 for e in row['events']:stages[e.split('stage=')[-1].split()[0]]+=1
 counts.append({'scenario':name,'events':len(row['events'])})
log=(a/'probe.log').read_text();lines=[l for l in log.splitlines() if 'TEXTUAL_SCENARIO name=' in l];assert len(lines)==22 and lines==obs['actual_trace_lines'] and 'recorded an issue' not in log
proof={'source':head,'canonical_source_bindings':len(paths),'original57andproduction_pin_graph_base':base,'original_fork_pin':pin,'effective_dependency_source_modified':True,'all_original_effective_dependency_files_downloaded_verified':downloaded,'all_actual_compiled_roles_downloaded_verified':5,'actual_native':'58PASS/0FAIL/0skip/0expected; original57 plus one aggregate that invokes20fresh journeys','actual_diagnostic_host':host,'actual_owned':owned,'all20fixed_fresh_scenarios':'PASS, each records a real attachment-ready stage;22actualJSONfiles including entry/final snapshots','scenario_counts':counts,'stage_counts':dict(stages),'interpretation':'Nooriginalfailure reproduced; instrumentation can altertiming. This qualifies only this diagnostic and explicit host transport, not canonical PR146 or solecause/renderer remediation.','trace_scope':'Initial snapshotactually0events, driver ranbeforeoriginal57;20scenario buffers archived, original57latertrace is not fully archived. Final duplicates lastscenario intentionally, not another independentjourney.'}
(root/'first-native-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print('Allactual58tests/20freshscenarios/22buffers/296original297effectivefiles/5compiledroles/currenthostfacts verified; no originalcauseclaim')
