from pathlib import Path
import json,subprocess,hashlib,zipfile
root=Path(__file__).parent;a=root/'native-first-artifact/javascriptcore-d2-quicklook-compatibility';repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext'
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
def sha(raw):return hashlib.sha256(raw).hexdigest()
r=json.loads((a/'receipt.json').read_bytes());head='dff0b156101755d1105d75a69047c71699ad65e7';base='5115e73409d78d53fbc9ee52b37e9c98d7169594';actual='92beb896ed255815dd1ef9a68da6cbde42f9b90f'
for label,run,result in [('native',42414107222,'failure'),('compliance',42414107131,'success')]:
 record=json.loads((root/(label+'-first-run.json')).read_bytes());assert record['id']==run and record['head_sha']==head and record['run_attempt']==1 and record['status']=='completed' and record['conclusion']==result
 with zipfile.ZipFile(root/(label+'-complete-first-workflow-logs.zip')) as z:assert z.testzip() is None and z.namelist()
assert r['checkout']==actual and git('show','-s','--format=%P',actual).decode().strip().split()==[base,head]
assert git('merge-tree','--write-tree',base,head).decode().splitlines()[0]==git('rev-parse',actual+'^{tree}').decode().strip()
for name,digest in r['source_sha256'].items():assert sha(git('show',actual+':'+name))==digest,name
for name,digest in r['fixture_source_sha256'].items():assert sha((a/'fixture'/name).read_bytes())==digest,name
assert len(r['source_sha256'])==28 and len(r['fixture_source_sha256'])==19
for filename,source in [('d2-browser.js','MacDown2/Packages/MacDownKit/Sources/D2Rendering/Resources/d2-browser.js'),('D2-LICENSE.txt','MacDown2/Packages/MacDownKit/Sources/D2Rendering/Resources/D2-LICENSE.txt'),('D2-NOTICE.txt','MacDown2/Packages/MacDownKit/Sources/D2Rendering/Resources/NOTICE.txt'),('THIRD_PARTY_NOTICES.md','compliance/generated/THIRD_PARTY_NOTICES.md')]:assert (a/'fixture/Resources'/filename).read_bytes()==git('show',actual+':'+source)
ref=json.loads((a/'reference-module.json').read_bytes());assert ref['returncode']==1 and ref['source_sha256']==sha((a/'fixture/reference.cjs').read_bytes())
log=(a/'reference-module.log').read_text();assert 'Script execution timed out after 15000ms' in log and 'reference.cjs:22:6' in log and 'ERR_SCRIPT_EXECUTION_TIMEOUT' in log
assert ref['command'][1:]==['/Users/runner/work/_temp/mostlytext-qljscd2/fixture/reference.cjs','/Users/runner/work/_temp/mostlytext-qljscd2/fixture']
assert r['diagnostic_only'] is True and r['qualification_candidate'] is False
assert not any(k in r for k in ['generated_sha256','built_before_test','compiled_before_test','actual_ui_summary','reference_module'])
assert not (a/'Finder.xcresult').exists() and not (a/'compiled-inputs').exists()
proof={'head':head,'base':base,'actual_checkout':actual,'tree':git('rev-parse',actual+'^{tree}').decode().strip(),'canonical_inputs':28,'copied_inputs':19,'original_D2_asset_and_notices_exact':True,'reference_outcome':'Node VM Script execution timed out after15000ms at reference.cjs22; exact asset/engine phase not observed','native_run':42414107222,'native_conclusion':'failure','compliance_run':42414107131,'compliance_conclusion':'success','generated_project':'NOT_RUN','native_build':'NOT_RUN','native_Finder':'NOT_RUN','actual_D2_SVG':'NOT_OBSERVED','compiled_execution_admission':False,'original_complete_first_outcomes_retained':True,'scope':'Primary reference-engine timeout, not native platform denial or D2 compatibility pass. Secondary always-verifier missing reference_module is distinct. No padded deadline, waived control or unchanged retry.'}
(root/'first-reference-failure-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
