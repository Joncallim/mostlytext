import hashlib,io,json,pathlib,re,subprocess,zipfile
root=pathlib.Path(__file__).parent;repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext';head='fd23e3e264e9f34dd093151bb0f5474b0466f8c7';actual='c8ddad4ecc7ded70e9b0990d30314466b51833a3';git=lambda *v:subprocess.check_output(['git',*v],cwd=repo);sha=lambda b:hashlib.sha256(b).hexdigest();canonical=json.loads(git('show',head+':MacDown2/Packages/MacDownKit/Package.resolved'))['pins']
proof={}
for label,run,conclusion in [('compliance',42440443046,'success'),('native_canvas',42440443155,'success'),('native_pdf',42440443112,'success'),('public_CLI',42440443176,'success'),('heading_anchors',42440443036,'success'),('full_CI',42440443061,'success'),('shared_math_heading',42440443292,'success')]:
 d=json.loads((root/(label+'-first-run.json')).read_bytes());assert d['id']==run and d['head_sha']==head and d['run_attempt']==1 and d['conclusion']==conclusion and d['status']=='completed',label
 with zipfile.ZipFile(root/(label+'-complete-first-workflow-logs.zip')) as z:assert z.testzip() is None
 proof[label]={'run':run,'complete_first':conclusion,'whole_log_archive_sha256':sha((root/(label+'-complete-first-workflow-logs.zip')).read_bytes())}

def sources(receipt,expected):
 assert receipt['checkout']==actual and set(receipt['source_sha256'])==expected
 stream=io.BytesIO(git('cat-file','--batch') if False else subprocess.check_output(['git','cat-file','--batch'],cwd=repo,input=''.join(head+':'+p+'\n' for p in sorted(expected)).encode()))
 for p in sorted(expected):
  header=stream.readline().split();assert header[1]==b'blob';raw=stream.read(int(header[2]));assert stream.read(1)==b'\n' and sha(raw)==receipt['source_sha256'][p],p
for p in sorted((root/'heading_anchors-first-artifact').glob('*/receipt.json')):
 r=json.loads(p.read_bytes());allnames=git('ls-tree','-r','--name-only',head,'--','MacDown2/Packages/MacDownKit').decode().splitlines();source_root='MacDown2/Packages/MacDownKit/'
 tests=['Tests/ExportServiceTests/'+n for n in ['HeadingAnchorPreparationTests.swift','HeadingFragmentStructureTests.swift','HeadingPublicationIntegrationTests.swift','HeadingPreparationWorkerTests.swift','HeadingSVGNamespaceTests.swift','ExportTestSupport.swift']]+['Tests/PreviewTests/'+n for n in ['PreviewHeadingLinkTests.swift','PreviewLinkActionTests.swift','QueuedHeadingJumpTests.swift']]+['Tests/ContributionsTests/TOCLinkedContributionTests.swift']
 expected={x for x in allnames if x.startswith(source_root+'Sources/') and x.endswith('.swift')}|{source_root+'Package.swift'}|{source_root+t for t in tests};sources(r,expected)
 assert r['pins']=={p['identity']:[p['location'],p['state']['revision']] for p in canonical};assert json.loads((p.parent/'Package.resolved').read_bytes())['pins']==canonical
 log=(p.parent/'probe.log').read_text();assert re.search(r'Test run with 68 tests in 9 suites passed',log) and not re.search(r'✘|recorded an issue|(?:Test|Suite)[^\n]*\b(?:skipped|disabled)\b',log,re.I)
 proof.setdefault('heading_actual_configurations',[]).append({'configuration':p.parent.name,'canonical_sources':len(expected),'actual_tests':68,'actual_suites':9,'pins':24,'limits':'No downloaded compiled binary/raw test bundle; actual complete native Swift test log and source/pin receipts'})
for p in sorted((root/'shared_math_heading-first-artifact').glob('*/receipt.json')):
 r=json.loads(p.read_bytes());expected=set(git('ls-tree','-r','--name-only',head,'--','MacDown2','.github/scripts/verify-shared-app-probe.py','.github/workflows/shared-math-app-integration.yml','.github/scripts/run-owned-app-tests.py','.github/scripts/test-run-owned-app-tests.py').decode().splitlines());sources(r,expected);assert r['pins']==canonical
 log=(p.parent/'probe.log').read_text();assert re.search(r'Test run with 29 tests in 9 suites passed',log) and not re.search(r'✘|recorded an issue|(?:Test|Suite)[^\n]*\b(?:skipped|disabled)\b',log,re.I)
 assert 'TOC-PHASE configuration='+r['configuration'] in log
 status=json.loads((p.parent/'diagnostics/status.json').read_bytes());identity=json.loads((p.parent/'diagnostics/identity.json').read_bytes());assert identity['checkout']==actual and status['returncode']==0 and status['timed_out'] is False and status['cancelled'] is False and status['app_cleanup_requested']==[] and 0<status['elapsed_seconds']<600
 cmd=identity['command'];assert cmd[0]=='xcodebuild' and cmd[cmd.index('-configuration')+1]==r['configuration'] and 'test-without-building' in cmd
 proof.setdefault('shared_actual_configurations',[]).append({'configuration':r['configuration'],'canonical_sources':len(expected),'actual_tests':29,'actual_suites':9,'pins':24,'owned':status,'limits':'Actual app/helper hashes are runner records, no downloaded binary-byte claim in this lane'})
assert len(proof['heading_actual_configurations'])==len(proof['shared_actual_configurations'])==2

with zipfile.ZipFile(root/'full_CI-complete-first-workflow-logs.zip') as z:
 package_names=[n for n in z.namelist() if n.startswith('build-and-test/') and 'Package build' in n];app_names=[n for n in z.namelist() if n.startswith('build-and-test/') and 'Run MacDown2Tests' in n]
 if len(package_names)==len(app_names)==1:
  package_log=z.read(package_names[0]).decode(errors='replace');app_log=z.read(app_names[0]).decode(errors='replace');log_layout='complete individual step logs'
 else:
  aggregated=[n for n in z.namelist() if '/' not in n and n.endswith('_build-and-test.txt')];assert len(aggregated)==1 and not package_names and not app_names
  package_log=app_log=z.read(aggregated[0]).decode(errors='replace');log_layout='complete aggregated build-and-test job log, both distinct original summaries and function events verified'

 assert re.search(r'Test run with 3721 tests in 537 suites passed',package_log)
 assert re.search(r'Test pdfCanvasPolicyIsCoveredBySVGValidationAndLeavesHTMLScrollbarsAlone\(\) passed',package_log)
 assert re.search(r'Test aChangedStructuralStylesheetCannotCertifyClosedReferences\(\) passed',package_log)
 assert re.search(r'Test run with 680 tests in 143 suites passed',app_log)
 assert re.search(r'Test pdfAdapterInputPreservesTheAcceptedHTMLBytes\(\) passed',app_log)
 assert 'recorded an issue' not in package_log and 'recorded an issue' not in app_log and '✘' not in package_log and '✘' not in app_log
 proof['actual_full_CI']={'package_tests':3721,'package_suites':537,'app_tests':680,'app_suites':143,'new_failing_before_SVG_PDF_HTML_integration':'actualPASS','both_exact_owned_sheets_and_unknown_CSS_refusals':'actualPASS','actual_app_accepted_HTML_UTF8_SVG_policy_destination_checks':'actualPASS','whole_actual_log_summaries_independently_read':True,'actual_archive_layout':log_layout}
package=root/'full_CI-first-artifact/owned-package-test-result-42440443061-1';identity=json.loads((package/'identity.json').read_bytes());status=json.loads((package/'status.json').read_bytes());assert status['returncode']==0 and identity['checkout']==actual
proof['source']=head;proof['actual_checkout']=actual;proof['qualification']='All seven whole first workflows PASS; actual3721package/680app/9genuinePDF/7canvas/6CLI/DebugRelease29sharedand68heading controls read back';proof['scope']='Actual current source/pins/raw native logs and owned state. Not whole ordinary-menu/normalQuit/technical PDF corpus/finalRC acceptance.'
(root/'all-seven-firsts-independently-reviewed.json').write_text(json.dumps(proof,indent=2)+'\n');print('All seven current whole firsts PASS; former real integration refusal fixed without changing its test')
