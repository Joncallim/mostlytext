import pathlib,subprocess,json,time
root=pathlib.Path(__file__).parent;run=42372088511;done=set()
while len(done)<2:
 raw=subprocess.check_output(['gh','api',f'repos/Joncallim/mostlytext/actions/runs/{run}/jobs?per_page=100']);d=json.loads(raw);(root/'9f76-first-jobs-current.json').write_bytes(raw)
 artifacts=json.loads(subprocess.check_output(['gh','api',f'repos/Joncallim/mostlytext/actions/runs/{run}/artifacts?per_page=100']))['artifacts'];(root/'9f76-first-artifacts-current.json').write_text(json.dumps(artifacts,indent=2)+'\n')
 for job in d['jobs']:
  scenario=job['name'].split('(')[-1].rstrip(')').split(',')[0].strip();assert scenario in ['valid-profile','future-session'],job['name']
  if scenario in done or job['status']!='completed':continue
  prefix='9f76-'+scenario;(root/(prefix+'-first-job.json')).write_text(json.dumps(job,indent=2)+'\n')
  with (root/(prefix+'-complete-first-job.log')).open('wb') as f:subprocess.run(['gh','api','--allow-escape-sequences',f'repos/Joncallim/mostlytext/actions/jobs/{job["id"]}/logs'],stdout=f,check=True)
  matching=[a for a in artifacts if a['name']=='hosted-normal-migration-'+scenario]
  if matching:
   artifact=root/(prefix+'-artifact');artifact.mkdir(exist_ok=False)
   result=subprocess.run(['gh','run','download',str(run),'-R','Joncallim/mostlytext','--name',matching[0]['name'],'--dir',str(artifact)],capture_output=True)
   (root/(prefix+'-download.log')).write_bytes(result.stdout+result.stderr)
   if result.returncode:raise RuntimeError('First job retained but original artifact download failed: '+scenario)
  else:(root/(prefix+'-no-artifact.json')).write_text(json.dumps({'job':job['id'],'conclusion':job['conclusion'],'scope':'No published artifact in first completed-job snapshot; preserve actual log, never infer native execution.'})+'\n')
  done.add(scenario);print(scenario,job['conclusion'],'complete first job/log/artifact outcome retained',flush=True)
 if len(done)<2:time.sleep(30)
for run,label in [(42372088511,'migration'),(42372088495,'compliance')]:
 d=json.loads(subprocess.check_output(['gh','api',f'repos/Joncallim/mostlytext/actions/runs/{run}']));(root/('9f76-'+label+'-run.json')).write_text(json.dumps(d,indent=2)+'\n')
 with (root/('9f76-'+label+'-complete-first-workflow-logs.zip')).open('wb') as f:subprocess.run(['gh','api',f'repos/Joncallim/mostlytext/actions/runs/{run}/logs'],stdout=f,check=True)
print('Both first normal scenarios and compliance original records retained',flush=True)
