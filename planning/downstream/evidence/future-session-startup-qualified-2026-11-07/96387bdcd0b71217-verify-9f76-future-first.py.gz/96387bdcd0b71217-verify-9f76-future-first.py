import hashlib,io,json,pathlib,plistlib,re,subprocess
r=pathlib.Path(__file__).parent;repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext';head='9f76ebef9ffc47061deae8667755955c10b3d456';checkout='c4d329d8295d9022c56ebe495c9284cef08bfd5f';base='d29358412585f669264e55e0f3666f456038b228'
a=r/'9f76-future-session-artifact';d=json.loads((a/'receipt.json').read_text());git=lambda *args:subprocess.check_output(['git',*args],cwd=repo);sha=lambda b:hashlib.sha256(b).hexdigest()
assert d['migration_scenario']=='future-session' and d['migration_qualified_main']==d['migration_future_qualified_main']==base
assert d['checkout']==checkout and git('show','-s','--format=%P',checkout).decode().split()==[base,head] and git('rev-parse',checkout+'^{tree}')==git('rev-parse',head+'^{tree}')
paths=['MacDown2','.github/hosted-public-focus','.github/scripts/prepare-hosted-public-focus.py','.github/scripts/run-hosted-public-focus.py','.github/scripts/test-hosted-focus-guard.py','.github/scripts/test-run-owned-app-tests.py','.github/scripts/native-cli-app-host.swift','.github/scripts/native_cli_endpoint_probe.py','.github/scripts/run-owned-app-tests.py','.github/workflows/hosted-public-focus.yml','.github/workflows/status-bar-layout.yml','.github/workflows/hosted-license-notices.yml','.github/scripts/test-hosted-license-notices.py','LICENSE','compliance/generated/THIRD_PARTY_NOTICES.md','.github/hosted-migration','.github/scripts/prepare-hosted-migration.py','.github/scripts/run-hosted-migration.py','.github/scripts/migration_profile_evidence.py','.github/scripts/test-hosted-migration.py','.github/scripts/test-migration-seed-admission.py','.github/workflows/hosted-migration.yml']
expected=set(git('ls-tree','-r','--name-only',head,'--',*paths).decode().splitlines());assert expected==set(d['source_sha256'])
requests=[head+':'+p for p in sorted(expected)];stream=io.BytesIO(subprocess.check_output(['git','cat-file','--batch'],cwd=repo,input=('\n'.join(requests)+'\n').encode()));blobs={}
for req in requests:
 h=stream.readline().split();assert h[1]==b'blob';raw=stream.read(int(h[2]));assert stream.read(1)==b'\n';p=req.split(':',1)[1];assert sha(raw)==d['source_sha256'][p],p;blobs[p]=raw
assert len(expected)==1624 and d['pins']==json.loads(blobs['MacDown2/Packages/MacDownKit/Package.resolved'])['pins'] and len(d['pins'])==24
for p,h in d['generated_sha256'].items():assert sha((a/'fixture'/p).read_bytes())==h
for p,h in d['seed_generated_sha256'].items():assert sha((a/'seed'/p).read_bytes())==h
assert (a/'seed/Package.resolved').read_bytes()==blobs['MacDown2/Packages/MacDownKit/Package.resolved']
assert sha((a/'seed/.build/release/SeedMigrationProfile').read_bytes())==d['seed_executable_sha256']
assert len(d['migration_compiled_downloads'])==len(d['migration_compiled_sha256'])==4
assert set(d['migration_compiled_downloads'].values())==set(d['migration_compiled_sha256'].values())
for p,h in d['migration_compiled_downloads'].items():assert sha((a/p).read_bytes())==h
import copy
from pathlib import Path
from urllib.parse import unquote,urlparse
run_path=next(p for p in d['migration_compiled_sha256'] if p.endswith('.xctestrun'))
run_hash=d['migration_compiled_sha256'][run_path]
run_copy=next(p for p,h in d['migration_compiled_downloads'].items() if h==run_hash)
run_plan=plistlib.loads((a/run_copy).read_bytes());target=run_plan['HostedFocusDriverTests']
assert target['TestHostPath']=='__TESTROOT__/Release/HostedFocusDriverTests-Runner.app' and target['TestBundlePath']=='__TESTHOST__/Contents/PlugIns/HostedFocusDriverTests.xctest' and target['UITargetAppPath']=='__TESTROOT__/Release/HostedFocusControl.app' and target['IsUITestBundle'] is True

assert d['criteria']=={'benign_control':True} and d['migration_execution_started'] is True and d['passed'] is True and d['blocked_startup_complete'] is True and not d['errors'] and not d.get('cleanup_errors')
for forbidden in ['migration_complete','migration_first_ui_passed','migration_first_normal_quit_verified']:
 assert forbidden not in d,forbidden
public={p.removeprefix('.github/hosted-public-focus/'):raw for p,raw in blobs.items() if p.startswith('.github/hosted-public-focus/')}
for path,raw in public.items():assert (a/'fixture'/path).read_bytes()==raw
for name in ['MigrationTests.swift','FutureSessionTests.swift']:assert (a/'fixture/Driver'/name).read_bytes()==blobs['.github/hosted-migration/Driver/'+name]
assert set(d['generated_sha256'])==set(public)|{'Driver/MigrationTests.swift','Driver/FutureSessionTests.swift','Driver/HostedFocusInputs.swift','HostedPublicFocus.xcodeproj/project.pbxproj','HostedPublicFocus.xcodeproj/project.xcworkspace/contents.xcworkspacedata','HostedPublicFocus.xcodeproj/xcshareddata/xcschemes/HostedPublicFocus.xcscheme'}
for name in ['SeedAdmission.swift','SeedProfile.swift','Package.swift.in']:assert (a/'seed'/name).read_bytes()==blobs['.github/hosted-migration/Fixture/'+name]
template=blobs['.github/hosted-migration/Fixture/Package.swift.in'];assert template.count(b'__BOUND_KIT_PATH__')==1
assert (a/'seed/Package.swift').read_bytes()==template.replace(b'__BOUND_KIT_PATH__',json.dumps('/Users/runner/work/mostlytext/mostlytext/MacDown2/Packages/MacDownKit').encode())
assert set(d['ui_results'])=={'positive','blocked'}
for label,method in [('positive','testBenignInputControl'),('blocked','testNormalFutureSessionBlocksOrdinaryEditing')]:
 row=d['ui_results'][label];summary=json.loads(subprocess.check_output(['xcrun','xcresulttool','get','test-results','summary','--path',str(a/(label+'.xcresult'))]));assert summary==row['summary']
 for k,v in {'totalTestCount':1,'passedTests':1,'failedTests':0,'skippedTests':0,'expectedFailures':0}.items():assert type(summary[k]) is int and summary[k]==v
 assert summary['testFailures']==[] and summary['result']=='Passed'
 owned=json.loads((a/(label+'-owned/status.json')).read_bytes());assert owned==row['owned'] and row['returncode']==owned['returncode']==0 and not owned['timed_out'] and not owned['cancelled'] and owned['app_cleanup_requested']==[] and 0<owned['elapsed_seconds']<600
 assert row['selected']=='HostedFocusDriverTests/PublicFocusTests/'+method
 log=(a/(label+'.log')).read_text();pattern=r"Test Case '-\[HostedFocusDriverTests\.PublicFocusTests "+method+r"\]' "
 assert len(re.findall(pattern+'started',log))==len(re.findall(pattern+'passed',log))==1 and not re.search(pattern+'failed|Restarting after unexpected',log)
 (r/('9f76-future-'+label+'-actual-summary.json')).write_text(json.dumps(summary,indent=2)+'\n')
assert all(row['returncode']==0 for row in d['commands'])
commands={row['label']:row for row in d['commands']}
for phase in ['before-positive','after-positive-before-seed','blocked-before-launch','blocked-before-quit','blocked-after-normal-quit','blocked-after-preservation-readback']:assert commands[phase]['returncode']==0
assert commands['seed-profile']['command'][-1]=='--seed-future-session'
assert 'change-current-indentation-only' not in commands
apps=d['applications'];assert [row['operation'] for row in apps]==['launch','inspect','terminate']
launch,inspect,quit=apps;assert all(row['pid']==launch['pid'] and row['birth']==launch['birth'] and row['executable']==launch['executable'] for row in apps) and quit['terminated'] is True
assert len(commands['app-launch-0']['command'])==3
for name in ['app-inspect-1','app-terminate-2']:assert commands[name]['command'][-2:]==[str(launch['pid']),str(launch['birth'])]
assert set(d['live_endpoints'])=={'blocked'}
peer=d['live_endpoints']['blocked'];assert peer['application_frames_sent']==0 and peer['attempts'] and all(not row['exists'] and not row['ready'] for row in peer['attempts'])
facts=d['actual_gui'];assert facts['uid']==501 and facts['on_console'] and facts['login_done'] and facts['screen_lock_field'] is not True and facts['keyboard_input_source']=='com.apple.keylayout.US' and facts['screens']
seed=json.loads((a/'migration-seed.json').read_bytes());assert sha((a/'migration-seed.json').read_bytes())==d['migration_seed_sha256'] and len(seed['session']['tabs'])==2
current=re.search(rb'public static let currentVersion = (\d+)',blobs['MacDown2/Packages/MacDownKit/Sources/Workspace/WorkspaceSession.swift']);assert current and seed['session']['version']==int(current.group(1))+1
before=json.loads((a/'profile-seeded.json').read_bytes());after=json.loads((a/'profile-blocked.json').read_bytes());assert before['state']==before['preserved']==before['installation']=={} and after['old']==before['old'] and after['state']=={} and after['preserved']=={}
for label,trees in [('seeded',before),('blocked',after)]:
 for kind,rows in trees.items():
  for path,row in rows.items():
   if row['kind']=='file':assert sha((a/('profile-'+label+'-'+kind)/path).read_bytes())==row['sha256']
assert json.loads((a/'profile-seeded-old/session.json').read_bytes())==json.loads((a/'profile-blocked-old/session.json').read_bytes())==seed['session']
for name in after['installation']:
 assert not(name=='installation-v1' or name.startswith('installation-v1/') or name in {'installation-preferences.json','installation-paths.json','installation-complete.json'}),name
expected_domains=['com.joncallim.MacDown2','com.joncallim.macdown2.workspace','app.mostlytext.MostlyText','app.mostlytext.MostlyText.workspace','com.uranusjr.macdown','com.uranusjr.macdown.workspace']
def domains(label):
 raw=(a/('migration-domains-'+label+'.plist')).read_bytes();assert sha(raw)==d['migration_domain_evidence_sha256'][label];rows=plistlib.loads(raw);assert [row['domain'] for row in rows]==expected_domains
 assert all(type(row['present']) is bool for row in rows)
 return {row['domain']:row['value'] if row['present'] else None for row in rows}
initial=domains('seeded');assert domains('blocked')==initial and all(initial[name] is None for name in expected_domains[1:]) and json.loads(initial[expected_domains[0]]['appSettings.editor'])['indentationWidth']==2
assert sha((a/'documents/migration-external.txt').read_bytes())==seed['externalSHA256']
assert (a/'documents/migration-external.txt').read_bytes().decode()=='Generated external migration document\r\nUnicode: cafe\u0301 \U0001f642\r\n'
assert len(before['old'])==len(after['old']) and any(p.is_file() and p.read_bytes()==seed['unsavedText'].encode() for p in (a/'profile-blocked-old/Recovery').rglob('*'))
assert all(value is True for value in d['blocked_startup_readback'].values()) and len(d['blocked_startup_readback'])==6
proof={'head':head,'actual_checkout':checkout,'actual_tree':git('rev-parse',checkout+'^{tree}').decode().strip(),'all_canonical_inputs_verified':len(expected),'pins':24,'all13_generated_driver_and5_seed_files_verified':True,'all_actual_compiled_seed_and4_driver_downloads_verified':True,'actual_positive_and_blocked_selected_cases_pass_once':True,'no_skips_expected_failures_timeouts_cancellations_forced_cleanup':True,'canonical_session_future_version':seed['session']['version'],'actual_blocked_surface_no_ordinary_tabs_editors_welcome_continue_verified_by_source_bound_native_case':True,'no_ready_or_existing_endpoint_in_all_recorded_fixed10second_poll_observations':len(peer['attempts']),'application_frames_sent':0,'normal_same_pid_birth_executable_quit_verified':True,'original_full_profile_inodes_modes_owners_bytes_unchanged':True,'all_six_persistent_domains_unchanged_and_current_domains_absent':True,'exact_future_session_and_unsaved_recovery_bytes_preserved':True,'no_authoritative_generation_state_preference_path_completion_publication':True,'private_uncommitted_staging_and_plan_writes_captured_not_zero_filesystem_writes':sorted(after['installation']),'external_CRLF_NFD_emoji_bytes_unchanged':True,'sentinel_absence_measured_by_source_bound_controller':True,'normal_adoption_relaunch_success_flags_absent':True,'scope':'Actual normal ad-hoc Release fictional future-session refusal with independent source/compiled/owned/actual results and full raw before/after profile/domain readback. No installed/signed/real-owner/VoiceOver/update/public-release or continuous-between-poll endpoint absence inference. Normal product app hash is a before/after hosted binding, not an independently downloaded app binary.'}
(r/'9f76-future-first-outcome-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
