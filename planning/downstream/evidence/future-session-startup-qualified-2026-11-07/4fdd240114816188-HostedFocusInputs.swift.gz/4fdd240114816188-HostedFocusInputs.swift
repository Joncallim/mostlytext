// Generated from the exact hosted build; never executed locally.
enum HostedFocusInputs {
    static let identity = "/Users/runner/work/_temp/mostlytext-focus/current-application.json"
    static let application = "/Users/runner/work/_temp/mostlytext-focus/app/Build/Products/Release/MacDown2.app"
    static let executable = "/Users/runner/work/_temp/mostlytext-focus/app/Build/Products/Release/MacDown2.app/Contents/MacOS/MacDown2"
    static let appSHA256 = "22e7451a4868ac3fcee2d43af79902fbdcdd65971bbeceb45d0a1e105a7c7a60"
    static let fileName = "focus-42372088511.md"
    static let folder = "/Users/runner/work/_temp/mostlytext-focus/documents"
}
