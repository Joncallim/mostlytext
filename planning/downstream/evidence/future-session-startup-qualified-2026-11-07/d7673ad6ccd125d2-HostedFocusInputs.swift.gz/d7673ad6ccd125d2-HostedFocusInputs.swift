// Generated from the exact hosted build; never executed locally.
enum HostedFocusInputs {
    static let identity = "/Users/runner/work/_temp/mostlytext-focus/current-application.json"
    static let application = "/Users/runner/work/_temp/mostlytext-focus/app/Build/Products/Release/MacDown2.app"
    static let executable = "/Users/runner/work/_temp/mostlytext-focus/app/Build/Products/Release/MacDown2.app/Contents/MacOS/MacDown2"
    static let appSHA256 = "e5e63efbab6c5af6213f8ce1481ecaa9efb79dd9692b96b0f03a86622b4dc403"
    static let fileName = "focus-42372088511.md"
    static let folder = "/Users/runner/work/_temp/mostlytext-focus/documents"
}
