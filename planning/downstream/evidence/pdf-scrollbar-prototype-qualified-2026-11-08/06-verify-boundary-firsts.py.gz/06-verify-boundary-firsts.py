import hashlib,json,pathlib,subprocess,zipfile
from PIL import Image
root=pathlib.Path(__file__).parent;repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext';sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *v:subprocess.check_output(['git',*v],cwd=repo);base='3c23e399786089d8ae116a00ac2c80c55369ba59';style='<style>html { scrollbar-width: none !important; }</style>'
for short,head,runs in [('a35abe57','a35abe572b4d64a3ce089708f80724577f3d4026',[42436428460,42436524450]),('3a4507ec','3a4507ec776b1866ea4ff36ad402e208b2926644',[42437419599,42437498897])]:
 r=root/('first-'+short);a=r/'native-first-artifact/native-pdf-snapshot-frames'
 for label,run in zip(['native','compliance'],runs):
  d=json.loads((r/(label+'-first-run.json')).read_bytes());assert d['id']==run and d['head_sha']==head and d['run_attempt']==1 and d['conclusion']=='success'
  with zipfile.ZipFile(r/(label+'-complete-first-workflow-logs.zip')) as z:assert z.testzip() is None
 receipt=json.loads((a/'snapshot-frame-receipt.json').read_bytes());o=json.loads((a/'snapshot-frame-observations.json').read_bytes());assert receipt['checkout']==head and receipt['native_returncode']==0 and receipt['timed_out'] is False and receipt['complete_comparison'] and receipt['qualification_candidate'] is False
 assert git('rev-parse',head+':MacDown2')==git('rev-parse',base+':MacDown2')
 assert len(receipt['source_sha256'])==8
 for p,h in receipt['source_sha256'].items():assert sha(git('show',head+':'+p))==h,p
 assert receipt['compiled_sha256']==sha((a/'read-snapshot-frames').read_bytes())
 for p,h in receipt['output_sha256'].items():assert sha((a/p).read_bytes())==h,p
 assert (a/'native-stdout.log').read_bytes()==(a/'native-stderr.log').read_bytes()==b''
 assert sha((a/'original.html').read_bytes())=='7e6cab53fe7ce75713efb9d50aa15c685f8824b8ff59428a8d16930ec70d2d17'
 names=['original','paper','minimal','boundary-original','boundary-paper']+(['css-paper','css-boundary-paper'] if short=='3a4507ec' else [])
 assert [c['case'] for c in o['completed_cases']]==names and o['qualification_candidate'] is False
 rows={}
 for c in o['completed_cases']:
  name=c['case'];data=(a/(name+'-hardened.html')).read_bytes();assert len(data)==c['hardened_html_bytes'] and sha(data)==c['hardened_html_sha256'];html=data.decode();boundary='boundary' in name
  assert html.count('BOUNDARY_REVIEW_CANARY')==(20 if boundary else 0) and html.count('height:700px')==(1 if boundary else 0) and html.count(style)==(1 if name.startswith('css-') else 0)
  for suffix,size,digest in [('snapshot',c['snapshot_bytes'],c['snapshot_sha256']),('paginated',c['paginated_bytes'],c['paginated_sha256'])]:
   raw=(a/(name+'-'+suffix+'.pdf')).read_bytes();assert len(raw)==size and sha(raw)==digest
  expected_ink={'original':[3692,0],'paper':[3692],'minimal':[3828],'boundary-original':[15482,0],'boundary-paper':[15798,0],'css-paper':[3692],'css-boundary-paper':[15482,0]}[name]
  assert len(c['pages'])==len(expected_ink)
  pngs=[]
  for i,p in enumerate(c['pages']):
   raw=(a/f'{name}-page-{i+1}.png').read_bytes();im=Image.open(a/f'{name}-page-{i+1}.png').convert('RGB');assert im.size==(612,792);ink=sum(min(pixel)<245 for pixel in im.getdata());assert ink==p['actual_raster_nonwhite_pixels']==expected_ink[i];pngs.append(sha(raw))
  rows[name]={'snapshot_box':c['snapshot_media_box'],'actual_page_count':len(c['pages']),'independent_PNG_ink':expected_ink,'PNG_SHA256':pngs,'hardened_HTML_SHA256':c['hardened_html_sha256']}
 assert rows['boundary-original']['snapshot_box']==[0,0,794,1123] and rows['boundary-paper']['snapshot_box']==[0,0,777,1053]
 assert rows['original']['PNG_SHA256'][0]==rows['paper']['PNG_SHA256'][0]=='99297b58780851bf0380dfdf0520ac5e4646c9e1389de396e5893d99e5996a93'
 if short=='3a4507ec':
  assert rows['css-paper']['snapshot_box']==[0,0,794,1038] and rows['css-boundary-paper']['snapshot_box']==[0,0,794,1053]
  assert rows['css-paper']['PNG_SHA256']==rows['paper']['PNG_SHA256'] and rows['css-boundary-paper']['PNG_SHA256']==rows['boundary-original']['PNG_SHA256']
  for original,css in [('paper','css-paper'),('boundary-original','css-boundary-paper')]:
   assert (a/(css+'-hardened.html')).read_text().replace(style,'')==(a/(original+'-hardened.html')).read_text()
   lhs=next(c for c in o['completed_cases'] if c['case']==original);rhs=next(c for c in o['completed_cases'] if c['case']==css)
   assert [p['raw_text'] for p in lhs['pages']]==[p['raw_text'] for p in rhs['pages']]
 proof={'source':head,'complete_native_and_compliance_firsts':'PASS','eight_canonical_source_bindings_and_actual_downloaded_helper_verified':True,'every_original_derived_HTML_raw_PDF_PNG_output_hash_verified':True,'product_tests_packages_pins_exact_base':base,'cases':rows,'finding':'Paper-only geometry introduces actual17point gutter/typography drift at authored height boundary','prototype':('Static root scrollbar-width:none restores794width and exact short/boundary page PNGs/raw text, while preserving2authored-space pages' if short=='3a4507ec' else 'Not present in this original first'),'limits':'Private native mechanism only; no production CSS decision/implementation, accepted-HTML rewrite, historical generation-branch, whole ordinary-menu or finalRC claim'}
 (r/'first-boundary-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print(short,'all actual source/binary/output bindings verified;',proof['prototype'])
