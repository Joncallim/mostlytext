import pathlib,subprocess,time,json
root=pathlib.Path(__file__).parent
last=set()
while True:
 ready={p.name for p in root.glob('ab48-final-B??-download.log')}
 if ready!=last:
  result=subprocess.run(['python3',str(root/'verify-ab48-final-matrix-first-outcomes.py')],capture_output=True)
  (root/('ab48-final-matrix-reader-'+str(len(ready))+'-batches-first.log')).write_bytes(result.stdout+result.stderr)
  if result.returncode:
   print('First independent matrix reader refused; inspect retained log before any correction',result.returncode,flush=True);break
  proof=json.loads((root/'ab48-final-matrix-first-outcomes-independently-verified.json').read_text())
  print({k:proof[k] for k in ['actual_completed_batches_independently_reviewed','rows_reviewed','counts','pending_batches','all38_originals_pass']},flush=True)
  last=ready
  if len(ready)==10:break
 time.sleep(30)
