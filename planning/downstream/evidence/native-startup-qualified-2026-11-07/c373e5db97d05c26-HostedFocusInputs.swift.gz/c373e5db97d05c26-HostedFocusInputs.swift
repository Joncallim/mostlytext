// Generated from the exact hosted build; never executed locally.
enum HostedFocusInputs {
    static let identity = "/Users/runner/work/_temp/mostlytext-focus/current-application.json"
    static let application = "/Users/runner/work/_temp/mostlytext-focus/app/Build/Products/Release/MacDown2.app"
    static let executable = "/Users/runner/work/_temp/mostlytext-focus/app/Build/Products/Release/MacDown2.app/Contents/MacOS/MacDown2"
    static let appSHA256 = "43ff4a838172bf9ecf8a57ed5b7cf2d29697bc261f8daa59d2b03c358ce65f4f"
    static let fileName = "focus-42365840367.md"
    static let folder = "/Users/runner/work/_temp/mostlytext-focus/documents"
}
