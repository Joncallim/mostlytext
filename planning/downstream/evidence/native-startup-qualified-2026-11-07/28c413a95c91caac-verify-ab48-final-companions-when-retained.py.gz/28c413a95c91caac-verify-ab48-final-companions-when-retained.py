import json,pathlib,subprocess,time,zipfile
root=pathlib.Path(__file__).parent
items={'ownership':('startup','placeholder-window-classifier','Probe','ownership-actual-summary.json'),'cli':('cli','normal-release-public-cli',None,None),'focus':('public-focus','hosted-normal-public-focus','focus','focus-xcresult-summary.json'),'license':('license','hosted-normal-license-notices','focus','license-xcresult-summary.json'),'status':('status','hosted-normal-status-layout','focus','status-focus-actual-summary.json'),'original':('original-focus','hosted-original-focus','original','original-xcresult-summary.json'),'critical-first':('critical',None,None,None),'migration-first':('migration',None,None,None),'full-ci':('full-ci',None,None,None)}
done={}
while len(done)<len(items):
 for name,(label,sub,case,summary) in items.items():
  if name in done:continue
  archive=root/('ab48-final-'+label+'-full-logs.zip')
  if not archive.exists():continue
  try:
   with zipfile.ZipFile(archive) as z:
    if z.testzip() is not None:continue
  except zipfile.BadZipFile:continue
  a=root/('ab48-final-'+label+'-artifact')
  if not a.exists():continue
  prep=[]
  if summary:prep.append(['xcrun','xcresulttool','get','test-results','summary','--path',str(a/sub/(case+'.xcresult'))])
  try:
   if prep:
    raw=subprocess.check_output(prep[0]);(root/('ab48-final-'+summary)).write_bytes(raw)
   if name=='status':
    target=root/'ab48-final-status-actual-attachments';target.mkdir(exist_ok=False)
    subprocess.run(['xcrun','xcresulttool','export','attachments','--path',str(a/sub/'focus.xcresult'),'--output-path',str(target)],check=True,capture_output=True)
   command=['python3',str(root/('verify-ab48-final-'+name+'.py'))]
   run=subprocess.run(command,capture_output=True);(root/('ab48-final-'+name+'-reader-first.log')).write_bytes(run.stdout+run.stderr)
   done[name]={'returncode':run.returncode,'reader':command[-1]}
  except Exception as error:
   done[name]={'preparation_error':repr(error)}
  (root/'ab48-final-reader-first-outcomes.json').write_text(json.dumps(done,indent=2)+'\n')
  print(name,done[name],flush=True)
 if len(done)<len(items):time.sleep(30)
print('All first companion evidence readers completed; inspect any nonzero/refusal, never infer a pass',flush=True)
