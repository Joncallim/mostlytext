# Native CLI fixture

Untouched source.
