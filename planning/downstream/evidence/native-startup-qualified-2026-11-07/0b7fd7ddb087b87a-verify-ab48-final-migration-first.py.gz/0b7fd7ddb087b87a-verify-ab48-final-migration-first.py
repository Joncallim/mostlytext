import hashlib,io,json,pathlib,plistlib,re,subprocess
r=pathlib.Path(__file__).parent;repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext';head='ab485fc0e99022428ab59b773b2929bf348b5967';checkout='e7bcdf04e81ca7757de711f6db33ca378ca0871f';base='ef93ab2d4fbda72cdd126560ffb19cd7e012a5d9'
a=r/'ab48-final-migration-artifact/hosted-normal-migration';d=json.loads((a/'receipt.json').read_text());git=lambda *args:subprocess.check_output(['git',*args],cwd=repo);sha=lambda b:hashlib.sha256(b).hexdigest()
assert d['checkout']==checkout and git('show','-s','--format=%P',checkout).decode().split()==[base,head] and git('rev-parse',checkout+'^{tree}')==git('rev-parse',head+'^{tree}')
paths=['MacDown2','.github/hosted-public-focus','.github/scripts/prepare-hosted-public-focus.py','.github/scripts/run-hosted-public-focus.py','.github/scripts/test-hosted-focus-guard.py','.github/scripts/test-run-owned-app-tests.py','.github/scripts/native-cli-app-host.swift','.github/scripts/native_cli_endpoint_probe.py','.github/scripts/run-owned-app-tests.py','.github/workflows/hosted-public-focus.yml','.github/workflows/status-bar-layout.yml','.github/workflows/hosted-license-notices.yml','.github/scripts/test-hosted-license-notices.py','LICENSE','compliance/generated/THIRD_PARTY_NOTICES.md','.github/hosted-migration','.github/scripts/prepare-hosted-migration.py','.github/scripts/run-hosted-migration.py','.github/scripts/migration_profile_evidence.py','.github/scripts/test-hosted-migration.py','.github/scripts/test-migration-seed-admission.py','.github/workflows/hosted-migration.yml']
expected=set(git('ls-tree','-r','--name-only',head,'--',*paths).decode().splitlines());assert expected==set(d['source_sha256'])
requests=[head+':'+p for p in sorted(expected)];stream=io.BytesIO(subprocess.check_output(['git','cat-file','--batch'],cwd=repo,input=('\n'.join(requests)+'\n').encode()));blobs={}
for req in requests:
 h=stream.readline().split();assert h[1]==b'blob';raw=stream.read(int(h[2]));assert stream.read(1)==b'\n';p=req.split(':',1)[1];assert sha(raw)==d['source_sha256'][p],p;blobs[p]=raw
assert len(expected)==1623 and d['pins']==json.loads(blobs['MacDown2/Packages/MacDownKit/Package.resolved'])['pins'] and len(d['pins'])==24
for p,h in d['generated_sha256'].items():assert sha((a/'fixture'/p).read_bytes())==h
for p,h in d['seed_generated_sha256'].items():assert sha((a/'seed'/p).read_bytes())==h
assert (a/'seed/Package.resolved').read_bytes()==blobs['MacDown2/Packages/MacDownKit/Package.resolved']
assert sha((a/'seed/.build/release/SeedMigrationProfile').read_bytes())==d['seed_executable_sha256']
assert len(d['migration_compiled_downloads'])==len(d['migration_compiled_sha256'])==4
assert set(d['migration_compiled_downloads'].values())==set(d['migration_compiled_sha256'].values())
for p,h in d['migration_compiled_downloads'].items():assert sha((a/p).read_bytes())==h
import copy
from pathlib import Path
from urllib.parse import unquote,urlparse
run_path=next(p for p in d['migration_compiled_sha256'] if p.endswith('.xctestrun'))
run_hash=d['migration_compiled_sha256'][run_path]
run_copy=next(p for p,h in d['migration_compiled_downloads'].items() if h==run_hash)
run_plan=plistlib.loads((a/run_copy).read_bytes());target=run_plan['HostedFocusDriverTests']
assert target['TestHostPath']=='__TESTROOT__/Release/HostedFocusDriverTests-Runner.app' and target['TestBundlePath']=='__TESTHOST__/Contents/PlugIns/HostedFocusDriverTests.xctest' and target['UITargetAppPath']=='__TESTROOT__/Release/HostedFocusControl.app' and target['IsUITestBundle'] is True
assert d['criteria']=={'benign_control':True} and d['migration_execution_started'] and d['migration_complete'] and d['passed'] and not d['errors'] and not d.get('cleanup_errors')
assert d['migration_first_ui_passed'] and d['migration_first_normal_quit_verified']
public={p.removeprefix('.github/hosted-public-focus/'):raw for p,raw in blobs.items() if p.startswith('.github/hosted-public-focus/')}
for path,raw in public.items():assert (a/'fixture'/path).read_bytes()==raw
assert (a/'fixture/Driver/MigrationTests.swift').read_bytes()==blobs['.github/hosted-migration/Driver/MigrationTests.swift']
assert set(d['generated_sha256'])==set(public)|{'Driver/MigrationTests.swift','Driver/HostedFocusInputs.swift','HostedPublicFocus.xcodeproj/project.pbxproj','HostedPublicFocus.xcodeproj/project.xcworkspace/contents.xcworkspacedata','HostedPublicFocus.xcodeproj/xcshareddata/xcschemes/HostedPublicFocus.xcscheme'}
for name in ['SeedAdmission.swift','SeedProfile.swift','Package.swift.in']:assert (a/'seed'/name).read_bytes()==blobs['.github/hosted-migration/Fixture/'+name]
template=blobs['.github/hosted-migration/Fixture/Package.swift.in'];assert template.count(b'__BOUND_KIT_PATH__')==1
assert (a/'seed/Package.swift').read_bytes()==template.replace(b'__BOUND_KIT_PATH__',json.dumps('/Users/runner/work/mostlytext/mostlytext/MacDown2/Packages/MacDownKit').encode())
assert set(d['ui_results'])=={'positive','first','relaunch'}
for label,method in [('positive','testBenignInputControl'),('first','testNormalDevelopmentProfileAdoption'),('relaunch','testNormalMigratedProfileRelaunch')]:
 row=d['ui_results'][label];summary=json.loads(subprocess.check_output(['xcrun','xcresulttool','get','test-results','summary','--path',str(a/(label+'.xcresult'))]));assert summary==row['summary']
 for k,v in {'totalTestCount':1,'passedTests':1,'failedTests':0,'skippedTests':0,'expectedFailures':0}.items():assert type(summary[k]) is int and summary[k]==v
 assert summary['testFailures']==[] and summary['result']=='Passed'
 owned=json.loads((a/(label+'-owned/status.json')).read_bytes());assert owned==row['owned'] and row['returncode']==owned['returncode']==0 and not owned['timed_out'] and not owned['cancelled'] and owned['app_cleanup_requested']==[] and 0<owned['elapsed_seconds']<600
 assert row['selected']=='HostedFocusDriverTests/PublicFocusTests/'+method
 log=(a/(label+'.log')).read_text();pattern=r"Test Case '-\[HostedFocusDriverTests\.PublicFocusTests "+method+r"\]' "
 assert len(re.findall(pattern+'started',log))==len(re.findall(pattern+'passed',log))==1 and not re.search(pattern+'failed|Restarting after unexpected',log)
 (r/('ab48-final-migration-'+label+'-actual-summary.json')).write_text(json.dumps(summary,indent=2)+'\n')
assert all(x['returncode']==0 for x in d['commands'])
commands={x['label']:x for x in d['commands']}
for phase in ['before-positive','after-positive-before-seed','first-before-launch','first-before-quit','first-after-normal-quit','relaunch-before-launch','relaunch-before-quit','relaunch-after-normal-quit']:assert commands[phase]['returncode']==0
apps=d['applications'];assert [x['operation'] for x in apps]==['launch','inspect','terminate']*2
for triplet,label in [(apps[:3],'first'),(apps[3:],'relaunch')]:
 launch,observed,quit=triplet;assert all(x['pid']==launch['pid'] and x['birth']==launch['birth'] and x['executable']==launch['executable'] for x in triplet) and quit['terminated'] is True
 peer=d['live_endpoints'][label];assert peer['application_frames_sent']==0 and peer['attempts'][-1]['ready'] and peer['attempts'][-1]['peer_pid']==launch['pid'] and peer['attempts'][-1]['peer_uid']==501 and peer['attempts'][-1]['mode']=='0o600'
assert apps[0]['pid']!=apps[3]['pid']
facts=d['actual_gui'];assert facts['uid']==501 and facts['on_console'] and facts['login_done'] and facts['screen_lock_field'] is not True and facts['keyboard_input_source']=='com.apple.keylayout.US' and facts['screens']
seed=json.loads((a/'migration-seed.json').read_bytes());assert sha((a/'migration-seed.json').read_bytes())==d['migration_seed_sha256'] and len(seed['session']['tabs'])==2
before=json.loads((a/'profile-seeded.json').read_bytes());assert before['state']==before['preserved']==before['installation']=={}
def domains(label):
 raw=(a/('migration-domains-'+label+'.plist')).read_bytes();assert sha(raw)==d['migration_domain_evidence_sha256'][label];rows=plistlib.loads(raw);return {x['domain']:x['value'] if x['present'] else None for x in rows}
initial=domains('seeded');assert list(initial)==['com.joncallim.MacDown2','com.joncallim.macdown2.workspace','app.mostlytext.MostlyText','app.mostlytext.MostlyText.workspace','com.uranusjr.macdown','com.uranusjr.macdown.workspace']
assert all(v is None for k,v in list(initial.items())[1:])
old_editor=initial['com.joncallim.MacDown2']['appSettings.editor'];assert json.loads(old_editor)['indentationWidth']==2
expected_session=copy.deepcopy(seed['session'])
for tab in expected_session['tabs']:
 url=Path(unquote(urlparse(tab['fileURL']).path))
 if url.is_relative_to(seed['old']):tab['fileURL']=(Path('/Users/runner/Library/Application Support/MostlyText/installation-v1/State')/url.relative_to(seed['old'])).as_uri()
for label,width in [('first',2),('relaunch',8)]:
 after=json.loads((a/('profile-'+label+'.json')).read_bytes());assert after['old']==before['old']
 for kind in ['old','preserved','state','installation']:
  for path,row in after[kind].items():
   if row['kind']=='file':assert sha((a/('profile-'+label+'-'+kind)/path).read_bytes())==row['sha256']
 assert set(after['preserved'])==set(before['old'])
 for path,row in before['old'].items():
  preserved=after['preserved'][path];assert all(row.get(k)==preserved.get(k) for k in ['kind','size','sha256','uid','gid']) and preserved['mode']&0o077==0
 actual=domains(label)
 for domain in list(initial)[:2]+list(initial)[4:]:assert actual[domain]==initial[domain]
 assert json.loads(actual['app.mostlytext.MostlyText']['appSettings.editor'])['indentationWidth']==width
 assert json.loads((a/('profile-'+label+'-state/session.json')).read_bytes())==expected_session
 assert any(p.is_file() and p.read_bytes()==seed['unsavedText'].encode() for p in (a/('profile-'+label+'-state/Recovery')).rglob('*'))
 for path in ['snippets.json','Themes/migration-fixture.json','Commands/must-not-run.command']:assert after['state'][path]['sha256']==before['old'][path]['sha256']
 plan=json.loads((a/('profile-'+label+'-installation/installation-plan.json')).read_bytes());assert plan['adoptsDevelopment'] is True and plan['beforePreferenceDigests']==['absent','absent']
 for phase in ['preferences','paths','complete']:assert json.loads((a/('profile-'+label+'-installation/installation-'+phase+'.json')).read_bytes())['phase']==phase
 assert d['migration_readback'][label]['original_unchanged'] and d['migration_readback'][label]['current_indentation']==width and d['migration_readback'][label]['old_indentation']==2 and d['migration_readback'][label]['sentinel_absent']
assert domains('first')['app.mostlytext.MostlyText']['appSettings.editor']==old_editor
changed=plistlib.loads((a/'migration-current-preferences-after-change.plist').read_bytes());first=domains('first')['app.mostlytext.MostlyText'];left=dict(first);right=dict(changed);before_editor=json.loads(left.pop('appSettings.editor'));after_editor=json.loads(right.pop('appSettings.editor'));before_editor['indentationWidth']=8;assert before_editor==after_editor and left==right
assert domains('relaunch')['app.mostlytext.MostlyText']['appSettings.editor']==changed['appSettings.editor']
assert sha((a/'documents/migration-external.txt').read_bytes())==seed['externalSHA256'] and not (a/'MIGRATION_COMMAND_RAN').exists()
assert (a/'documents/migration-external.txt').read_bytes().decode()=='Generated external migration document\r\nUnicode: cafe\u0301 \U0001f642\r\n'
proof={'head':head,'actual_checkout':checkout,'actual_tree':git('rev-parse',checkout+'^{tree}').decode().strip(),'all_canonical_inputs_verified':len(expected),'pins':24,'all12_generated_driver_and5_seed_files_verified':True,'all_actual_compiled_seed_and4_driver_downloads_verified':True,'actual_positive_and_first_relaunch_1pass_each':True,'no_skips_expected_failures_timeouts_cancellations_forced_cleanup':True,'two_normal_same_pid_birth_executable_quits_verified':True,'two_actual_same_process_kernel_peers_verified':True,'original_profile_inodes_modes_owners_bytes_and_original_domains_unchanged':True,'complete_private_preserved_copy_independently_verified':True,'full_saved_session_objects_match_seed_except_managed_path_relocation':True,'exact_recovery_epochs_and_unsaved_draft_preserved_both_quits':True,'original_editor_data2_imported_exactly_then_only_current_width_changed_to8':True,'actual_UI_imported2_and_current8_relaunch_pass':True,'theme_snippets_command_data_files_and_external_CRLF_NFD_emoji_bytes_unchanged':True,'command_sentinel_absence_measured_by_source_bound_controller_at_both_readbacks':True,'complete_preference_path_journals_both_captures':True,'scope':'Normal unsigned/ad-hoc Release fictional-profile migration and two launches with actual native tabs/recovery, source/compiled/owned/actual result/raw-state bindings. Not real installed development build/update chain, bookmark reauthorization, selected custom-theme UI, owner/test-account/protected lane, failure/corrupt/future-session scenarios, signed exact artifact or public release acceptance. App digest is bound in generated native checks and hosted before/after verification, not an independently downloaded app binary.'}
(r/'ab48-final-migration-first-outcome-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
