// Generated from the exact hosted build; never executed locally.
enum HostedFocusInputs {
    static let identity = "/Users/runner/work/_temp/mostlytext-focus/current-application.json"
    static let application = "/Users/runner/work/_temp/mostlytext-focus/app/Build/Products/Release/MacDown2.app"
    static let executable = "/Users/runner/work/_temp/mostlytext-focus/app/Build/Products/Release/MacDown2.app/Contents/MacOS/MacDown2"
    static let appSHA256 = "b29a6e1f6cd6bdcb412b883ac67cc2664bfd5f357ec8f616c44ff058fc1bce1b"
    static let fileName = "focus-42365840472.md"
    static let folder = "/Users/runner/work/_temp/mostlytext-focus/documents"
}
