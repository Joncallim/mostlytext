// Generated from the exact hosted build; never executed locally.
enum HostedFocusInputs {
    static let identity = "/Users/runner/work/_temp/mostlytext-focus/current-application.json"
    static let application = "/Users/runner/work/_temp/mostlytext-focus/app/Build/Products/Release/MacDown2.app"
    static let executable = "/Users/runner/work/_temp/mostlytext-focus/app/Build/Products/Release/MacDown2.app/Contents/MacOS/MacDown2"
    static let appSHA256 = "ea2ca66ebada55fc5ac6b01866748d3ad8a075f575a7045778307dbbfa3431d8"
    static let fileName = "focus-42365840219.md"
    static let folder = "/Users/runner/work/_temp/mostlytext-focus/documents"
}
