// Generated from the exact hosted build; never executed locally.
enum HostedFocusInputs {
    static let identity = "/Users/runner/work/_temp/mostlytext-focus/current-application.json"
    static let application = "/Users/runner/work/_temp/mostlytext-focus/app/Build/Products/Release/MacDown2.app"
    static let executable = "/Users/runner/work/_temp/mostlytext-focus/app/Build/Products/Release/MacDown2.app/Contents/MacOS/MacDown2"
    static let appSHA256 = "83edd78fad47deddf19a93585c247db28bec8fab6ded33b83f63125d7dc5593a"
    static let fileName = "focus-42365840400.md"
    static let folder = "/Users/runner/work/_temp/mostlytext-focus/documents"
}
