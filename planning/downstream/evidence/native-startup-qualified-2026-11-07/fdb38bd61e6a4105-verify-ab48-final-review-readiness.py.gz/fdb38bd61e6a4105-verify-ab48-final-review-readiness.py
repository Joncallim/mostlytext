import hashlib,json,pathlib,subprocess
root=pathlib.Path(__file__).parent;repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext';head='ab485fc0e99022428ab59b773b2929bf348b5967';base='ef93ab2d4fbda72cdd126560ffb19cd7e012a5d9';checkout='e7bcdf04e81ca7757de711f6db33ca378ca0871f';tree='8c57223eeba8b888d96be1b87b9eb9faecae1dfe'
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
def api(path):return json.loads(subprocess.check_output(['gh','api','repos/Joncallim/mostlytext/'+path],text=True))
proof_names=['cli-first-outcome','focus-first-outcome','license-first-outcome','status-first-outcome','original-first-outcome','ownership-first-outcome','critical-first-outcome','migration-first-outcome','full-ci','matrix-first-outcomes']
records={}
for name in proof_names:
 file=root/('ab48-final-'+name+'-independently-verified.json');raw=file.read_bytes();d=json.loads(raw)
 assert d['head']==head and d.get('checkout',d.get('actual_checkout'))==checkout,name
 records[name]={'file':file.name,'sha256':hashlib.sha256(raw).hexdigest()}
matrix=json.loads((root/'ab48-final-matrix-first-outcomes-independently-verified.json').read_text());assert matrix['all38_originals_pass'] is True and matrix['counts']=={'PASSED':38} and matrix['pending_batches']==[] and len(matrix['batch_proofs'])==10 and all(x['actual_positive_passed'] is True for x in matrix['batch_proofs'])
readers=json.loads((root/'ab48-final-reader-first-outcomes.json').read_text());assert len(readers)==9 and all(v.get('returncode')==0 for v in readers.values())
mounted=json.loads((root/'ab48-final-mounted-settings-actual-pass.json').read_text());assert mounted['head']==head and mounted['checkout']==checkout and mounted['new_mounted_settings_case_actual_passed_once'] is True
assert git('status','--porcelain=v1')=='' and git('rev-parse','HEAD')==base
assert git('show','-s','--format=%P',checkout).split()==[base,head]
assert git('rev-parse',head+'^{tree}')==git('rev-parse',checkout+'^{tree}')==git('merge-tree','--write-tree',base,head).splitlines()[0]==tree
refs=git('ls-remote','origin','refs/heads/main','refs/heads/epic/03-hosted-installation-rehearsal').splitlines();actual={line.split()[1]:line.split()[0] for line in refs};assert actual=={'refs/heads/main':base,'refs/heads/epic/03-hosted-installation-rehearsal':head}
runs=[42365840286,42365840212,42365840296,42365840249,42365840472,42365840400,42365840248,42365840266,42365840219,42365840270,42365840367];outcomes=[]
for run in runs:
 d=api('actions/runs/'+str(run));assert d['head_sha']==head and d['event']=='pull_request' and d['status']=='completed' and d['conclusion']=='success',(run,d['status'],d['conclusion']);outcomes.append({'run':run,'name':d['name'],'conclusion':d['conclusion']})
pr=api('pulls/130');assert pr['state']=='open' and pr['merged'] is False and pr['head']['sha']==head and pr['base']['sha']==base and pr['merge_commit_sha']==checkout and pr['mergeable'] is True
reviews=api('pulls/130/reviews?per_page=100');assert not any(x['state']=='CHANGES_REQUESTED' for x in reviews)
checks=json.loads(subprocess.check_output(['gh','pr','checks','130','--repo','Joncallim/mostlytext','--json','name,state'],text=True));assert checks and all(c['state']=='SUCCESS' for c in checks)
proof={'head':head,'base':base,'checkout':checkout,'tree':tree,'all11_final_workflows_actual_success':outcomes,'all38_originals_and10_positives_independently_verified':True,'all9_companion_readers_zero':True,'new_mounted_settings_regression_actual_pass':True,'evidence_records':records,'canonical_main_clean_at_base':True,'remote_head_and_main_verified':True,'all_status_checks_success':checks,'review_states':[x['state'] for x in reviews],'ready_for_review_and_expected_head_merge':True,'scope':'Engineering qualification of exact source/actual synthetic tree; no external reviewer, installed/signed/owner/native-language/VoiceOver/update/future/Preview/final-release acceptance. Check live inline threads again before metadata transition.'}
(root/'ab48-final-ready-for-review-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print({'head':head,'tree':tree,'workflows':len(outcomes),'originals':38,'positives':10,'companion_readers':9,'all_checks_success':True,'ready':True})
