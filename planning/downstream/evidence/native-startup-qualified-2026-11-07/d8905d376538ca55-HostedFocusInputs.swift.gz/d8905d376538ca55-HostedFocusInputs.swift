// Generated from the exact hosted build; never executed locally.
enum HostedFocusInputs {
    static let identity = "/Users/runner/work/_temp/mostlytext-focus/current-application.json"
    static let application = "/Users/runner/work/_temp/mostlytext-focus/app/Build/Products/Release/MacDown2.app"
    static let executable = "/Users/runner/work/_temp/mostlytext-focus/app/Build/Products/Release/MacDown2.app/Contents/MacOS/MacDown2"
    static let appSHA256 = "df0b9c3ff40c4ddd3cabd46d0eae45703cfda9ad0f8d6fe92f61088b7dc831da"
    static let fileName = "focus-42363976593.md"
    static let folder = "/Users/runner/work/_temp/mostlytext-focus/documents"
}
