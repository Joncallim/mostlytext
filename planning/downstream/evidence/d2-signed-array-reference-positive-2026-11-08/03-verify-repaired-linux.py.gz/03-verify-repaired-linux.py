from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path(__file__).parent;a=root/'linux-first-artifact/fixed-d2-linux-reference-first';repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext'
git=lambda *x:subprocess.check_output(['git',*x],cwd=repo)
sha=lambda x:hashlib.sha256(x).hexdigest()
head='ff92199387fec0ef650103a62f36e785fc78f4fd';before='e8c45c57c34ef081e16865d44c4405627952166f';r=json.loads((a/'diagnostic-receipt.json').read_bytes());run=json.loads((root/'linux-first-run.json').read_bytes());assert run['id']==42416702780 and run['head_sha']==head and run['run_attempt']==1 and run['status']=='completed' and run['conclusion']=='success'
with zipfile.ZipFile(root/'linux-complete-first-workflow-logs.zip') as z:assert z.testzip() is None
for name,h in r['source_sha256'].items():assert sha(git('show',head+':'+name))==h
for name,h in r['copied_sha256'].items():assert sha((a/'fixture'/name).read_bytes())==h
assert r['checkout']==head and r['returncode']==0 and all(r[k] is True for k in ['source_unchanged_after','copies_unchanged_after','node_unchanged_after','diagnostic_only']) and r['native_qualification'] is False
old=git('show',before+':.github/quicklook-jscd2-probe/Resources/host.js');new=git('show',head+':.github/quicklook-jscd2-probe/Resources/host.js')
assert new==old.replace(b'    if (value instanceof Uint8Array) return value.slice();',b'''    if (ArrayBuffer.isView(value)) {
      const buffer = value.buffer.slice(value.byteOffset, value.byteOffset + value.byteLength);
      return value instanceof DataView ? new DataView(buffer) : new value.constructor(buffer);
    }''')
for path in ['MacDown2','.github/quicklook-jscd2-probe/Resources/control.js','.github/quicklook-jscd2-probe/reference.cjs','.github/quicklook-jscd2-probe/clone-counterexamples.cjs']:
 assert git('diff',before,head,'--',path)==b'',path
c=r['clone_counterexamples'];assert len(c['cases'])==12 and c['passed']==12 and c['failed']==0 and all(x['passed'] is True and x['kind']==x['copiedKind'] and x['expectedBytes']==x['copiedBytes'] for x in c['cases'])
value=json.loads((a/'reference-output.log').read_bytes());assert value==r['result'] and value['real_d2_svg'] is True and value['svg_bytes']==10928 and value['svg_sha256']=='45d283939b9d7837024413965a00235bd15b3e87a290d84005f1d12bfda4b5a8'
assert value['assets']=={name:sha((a/'fixture/Resources'/f'{name}.js').read_bytes()) for name in ['host','d2-browser','control']}
phases=json.loads((a/'reference-phases.json').read_bytes());assert len(phases)==28 and phases[-1]['phase']=='render-end' and phases[-1]['uptime_ms']<15000 and 'wasm-type-int8array' in [x['phase'] for x in phases]
assert value['controls']=={'utf8':True,'base64':True,'randomBytes':32,'timer':True} and r['elapsed_seconds']<15
proof={'head':head,'run':42416702780,'conclusion':'success','canonical':len(r['source_sha256']),'copied':len(r['copied_sha256']),'actual_verbatim_clone_passed':12,'failed':0,'engine_control_reference_scripts_unchanged_from_actual_failed_copy_source':True,'only_host_function_change':'Preserve all BufferSource view types and exact visible bytes','real_fixed_D2_SVG_reported_bytes':10928,'reported_svg_sha256':value['svg_sha256'],'complete_phase_journal_count':28,'actual_render_end_process_uptime_ms':phases[-1]['uptime_ms'],'actual_reference_seconds':r['elapsed_seconds'],'actual_output_metadata_equal_receipt':True,'raw_svg_not_retained_in_this_first_reference':True,'native_qualification':False,'complete_first_retained':True,'scope':'Actual unchanged D2 Node reference positive after narrow signed-array repair; actual type/byte counterexamples fail11before/pass12after. No Mac/native/visual/theme/production/deadline/retirement acceptance.'}
(root/'repaired-linux-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof)
