import hashlib,json,pathlib,plistlib,re,subprocess,uuid,zipfile
root=pathlib.Path(__file__).parent
artifact=root/'native-first-artifact/javascriptcore-d2-quicklook-compatibility'
repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext'
head='fef09ea3c15d4797a51e5b4b16dd1f7bfe50ce57';base='5115e73409d78d53fbc9ee52b37e9c98d7169594';actual='68b2980d4709b7de0dea175a3e8b6b5a3dc2f0bd'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
def read(name):return json.loads((artifact/name).read_bytes())
r=read('receipt.json')
for label,run in [('native',42422289441),('compliance',42422289432)]:
 run_record=json.loads((root/(label+'-first-run.json')).read_bytes())
 assert run_record['id']==run and run_record['head_sha']==head and run_record['run_attempt']==1 and run_record['conclusion']=='success' and run_record['status']=='completed'
assert r['checkout']==actual
assert git('show','-s','--format=%P',actual).decode().strip().split()==[base,head]
assert git('merge-tree','--write-tree',base,head).decode().splitlines()[0]==git('rev-parse',actual+'^{tree}').decode().strip()
assert git('diff','--name-only',base,head,'--','MacDown2','.github/quicklook-reply-probe','.github/scripts/prepare-quicklook-reply-probe.py','.github/workflows/quicklook-reply-probe.yml')==b''
assert r['root_product_tree']==git('rev-parse',base+':MacDown2').decode().strip()
for name,digest in r['source_sha256'].items():assert sha(git('show',actual+':'+name))==digest,(name,'canonical')
for name,digest in r['fixture_source_sha256'].items():assert sha((artifact/'fixture'/name).read_bytes())==digest,(name,'copied')
for name,digest in r['generated_sha256'].items():assert sha((artifact/'fixture'/name).read_bytes())==digest,(name,'generated')
for role,row in r['compiled_before_test'].items():
 raw=(artifact/row['blob']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],role
assert len(r['compiled_before_test'])==75 and r['built']==r['built_before_test']
host_role='bundle:QLReplyProbeAutomationHost.app/Contents/MacOS/QLReplyProbeAutomationHost'
assert host_role in r['compiled_before_test']
for bundle in ['QLReplyProbeContainer.app','QLReplyProbeAutomationHost.app','QLReplyProbeFinderTests-Runner.app']:
 assert 'bundle:'+bundle+'/Contents/Info.plist' in r['compiled_before_test']
 assert 'bundle:'+bundle+'/Contents/_CodeSignature/CodeResources' in r['compiled_before_test']
for name in ['Testing','XCTestCore','XCTest','XCTestSupport','XCUIAutomation','XCTAutomationSupport','XCUnit']:
 assert any('Frameworks/'+name+'.framework/' in k for k in r['compiled_before_test'])
provider=artifact/r['compiled_before_test']['provider']['blob']
metadata=subprocess.run(['codesign','--display','--entitlements',':-',str(provider)],capture_output=True,check=True)
(root/'actual-downloaded-provider-entitlements.plist').write_bytes(metadata.stdout)
assert plistlib.loads(metadata.stdout)=={'com.apple.security.app-sandbox':True,'com.apple.security.files.user-selected.read-only':True}
for name in ['mostlytext-ql-reply-static.md','mostlytext-ql-jscd2.md']:assert (artifact/name).read_bytes()==b'# Hosted Quick Look fixture\n' and sha((artifact/name).read_bytes())==r['selected_fixture_sha256']
owned=read('owned/status.json');identity=read('owned/identity.json');driver=read('host-ui-driver.json');observer=read('observer-result.json')
assert owned['returncode']==0 and owned['timed_out'] is False and owned['cancelled'] is False and owned['app_cleanup_requested']==[]
assert identity['checkout']==driver['checkout']==observer['checkout']==actual and identity['app_sha256']==r['compiled_before_test']['provider']['sha256']
assert identity['command']==driver['command'][5:] and driver['command'][4]=='--'
assert driver['errors']==observer['errors']==[] and driver['ui_started'] is True and driver['ui_supervisor_returncode']==0
assert driver['observer_returncode']==0 and driver['observer_forced_cleanup'] is False and driver['observer_pid']==observer['pid']
assert observer['mode']=='live-ndjson' and observer['timed_out'] is False and observer['stopped_after_ui'] is True
assert observer['stream_forced_cleanup'] is False and observer['stream_unexpected_exit'] is False and observer['stream_returncode']==-15
assert driver['ui_completed_monotonic']<=driver['observer_stop_requested_monotonic']<=observer['stop_signal_monotonic']<=observer['finished_monotonic']
assert 0<observer['admitted_monotonic']-observer['started_monotonic']<5 and observer['elapsed_seconds']<300
assert observer['stream_command']==['/usr/bin/log','stream','--style','ndjson','--level','info','--predicate','(subsystem == "app.mostlytext.qljscd2probe") OR (subsystem == "app.mostlytext.qljscd2observer")']
nonce=observer['nonce'];assert str(uuid.UUID(nonce)).upper()==nonce
control_path='/Users/runner/work/_temp/mostlytext-qljscd2/observer-control'
assert observer['control_sha256']==r['compiled_before_test']['observer_control']['sha256']
build=read('observer-control-build.json');assert build['returncode']==0 and 'error' not in build and build['binary_sha256']==observer['control_sha256']
assert build['source_sha256']==r['generated_sha256']['ObserverControl.swift']
assert build['command']==['xcrun','swiftc','-O','-swift-version','6','-strict-concurrency=complete','-warnings-as-errors','-target','arm64-apple-macos26.0','-parse-as-library','/Users/runner/work/_temp/mostlytext-qljscd2/fixture/ObserverControl.swift','-o',control_path]
assert 1<=len(observer['control_attempts'])<=25
for attempt in observer['control_attempts']:
 assert attempt['command']==[control_path,nonce] and attempt['returncode']==0 and attempt['stdout']==attempt['stderr']==''
 assert observer['started_monotonic']<=attempt['started_monotonic']<=attempt['completed_monotonic']<=observer['admitted_monotonic'] and attempt['completed_monotonic']-attempt['started_monotonic']<3
stream=(artifact/'observer-stream.log').read_bytes();assert len(stream)==observer['stream_bytes'] and sha(stream)==observer['stream_sha256'] and stream.endswith(b'\n')
assert (artifact/'observer-stream-errors.txt').read_bytes()==b''
position=0;messages=[];generations=[];echoes=[];provider_events=[]
for line in stream.splitlines(keepends=True):
 position+=len(line)
 if line.startswith(b'Filtering the log data using '):continue
 event=json.loads(line);assert event['subsystem'] in ['app.mostlytext.qljscd2probe','app.mostlytext.qljscd2observer'] and event['userID']==501
 if event['subsystem']=='app.mostlytext.qljscd2observer':
  assert event['eventMessage']=='QL_OBSERVER_CONTROL nonce='+nonce and event['processImagePath']==control_path
  if not echoes:generations.append((position,[]))
  echoes.append(event)
 else:
  assert echoes and event['processImagePath']==identity['app']
  messages.append(event['eventMessage']);provider_events.append(event);generations.append((position,list(messages)))
assert len(generations)==len(observer['snapshots'])<=128
for index,(row,generation) in enumerate(zip(observer['snapshots'],generations)):
 assert row['file']==f'observer-journal/{index:03d}.json' and row['stream_position']==generation[0]
 raw=(artifact/row['file']).read_bytes();v=json.loads(raw)
 assert len(raw)==row['bytes']<=128*1024 and sha(raw)==row['sha256']
 assert v=={'kind':'mostlytext-qljscd2-host-observer','checkout':actual,'sequence':index,'messages':generation[1]}
assert (artifact/'provider-observer.json').read_bytes()==(artifact/observer['snapshots'][-1]['file']).read_bytes()
assert {x.name for x in (artifact/'observer-journal').iterdir()}=={f'{i:03d}.json' for i in range(len(generations))}
controls=read('observer-control-events.json');direct=read('provider-events.json')
for echo in echoes:assert any(all(x.get(k)==echo[k] for k in ['processID','machTimestamp','eventMessage','processImagePath']) for x in controls)
assert [x['eventMessage'] for x in direct]==messages
assert not any('container-launched-invalidates-cold-proof' in x for x in messages)
summary=json.loads((root/'actual-independent-summary.json').read_bytes());assert summary==r['actual_ui_summary']
assert {k:summary[k] for k in ['totalTestCount','passedTests','failedTests','skippedTests','expectedFailures']}=={'totalTestCount':2,'passedTests':2,'failedTests':0,'skippedTests':0,'expectedFailures':0}
assert r['diagnostic_only'] is True and r['qualification_candidate'] is False
import base64
reference=read('reference-module.json');assert reference==r['reference_module'] and reference['returncode']==0 and reference['copy_controls']['result']['passed']==12 and reference['copy_controls']['result']['failed']==0
native=r['javascriptcore_d2_observation'];parts=[];terminal=[]
for message in messages:
 match=re.fullmatch(r'QL_JSCD2_PROBE chunk id=2 index=(\d+) count=(\d+) base64=([A-Za-z0-9+/=]+)',message)
 if match:parts.append((int(match[1]),int(match[2]),base64.b64decode(match[3],validate=True)))
 match=re.fullmatch(r'QL_JSCD2_PROBE result id=2 bytes=(\d+) sha256=([a-f0-9]{64})',message)
 if match:terminal.append((int(match[1]),match[2]))
assert parts and len(parts)<=171 and len(terminal)==1
for i,(index,count,part) in enumerate(parts):assert index==i and count==len(parts) and 0<len(part)<=384
raw=b''.join(x[2] for x in parts);assert len(raw)<=65536 and (len(raw),sha(raw))==terminal[0]
assert json.loads(raw)==native
actual_records=[]
for path in (root/'actual-independent-attachments').iterdir():
 if path.suffix=='.json':
  value=json.loads(path.read_bytes())
  if isinstance(value,dict) and value.get('kind')=='mostlytext-qljscd2-compatibility':
   assert path.read_bytes()==raw;actual_records.append(value)
assert actual_records==[native]
svg=native['svg'].encode();assert len(svg)==native['svg_bytes']<=48*1024 and sha(svg)==native['svg_sha256']
assert '<svg' in native['svg'] and all(x in native['svg'] for x in ['JSC_D2_ALPHA','JSC_D2_BETA']) and re.search(r'<(?:path|rect|polygon)\b',native['svg'])
assert not re.search(r"<(?:script|foreignObject)\b|(?:href|src)\s*=\s*['\"](?:https?:|//)|@import|url\(\s*['\"]?https?:",native['svg'],re.I)
assert native['controls']=={'utf8':True,'base64':True,'randomBytes':32,'timer':True}
assert native['diagnostic_only'] is True and native['qualification_candidate'] is False and native['request_id']==2
assert 0<native['observed_uptime']-native['started_uptime']<15
assert native['worker_transform']==reference['result']['worker_transform']
for key in ['host','d2-browser','control']:assert native['assets'][key]==sha((artifact/'fixture/Resources'/(key+'.js')).read_bytes())
for key,h in r['built']['resource_sha256'].items():
 roles=[row for role,row in r['compiled_before_test'].items() if role.endswith('/Contents/Resources/'+key)];assert len(roles)==1
 assert sha((artifact/roles[0]['blob']).read_bytes())==sha((artifact/'fixture/Resources'/key).read_bytes())==h
assert len(r['built']['resource_sha256'])==6
engine='MacDown2/Packages/MacDownKit/Sources/D2Rendering/Resources/d2-browser.js'
assert native['assets']['d2-browser']==sha(git('show',base+':'+engine))
control=native['async_control'];assert control['answer']==42 and control['old_blocking_poll_completed'] is False and all(control[k] is True for k in ['same_thread','exception_absent','rejection_absent','diagnostic_only'])
assert control['module_bytes']==39 and control['module_sha256']=='ccf59f0f7a7625ee380ed228905aadfa11072ac14cea1c53d1e7f3953d4d48c6'
assert 0.25<=control['blocked_elapsed_seconds']<0.5 and 0<control['pumped_elapsed_seconds']<2
separate=[json.loads(base64.b64decode(x.split('base64=',1)[1])) for x in messages if x.startswith('QL_JSCD2_PROBE async-control-base64=')];assert separate==[control]
assert all(len(x)<600 and '<…>' not in x for x in messages if x.startswith('QL_JSCD2_PROBE chunk '))
reference_svg=(artifact/'reference-actual.svg').read_bytes();assert len(reference_svg)==reference['result']['svg_bytes'] and sha(reference_svg)==reference['result']['svg_sha256']
# Native bytes are independently reconstructed, never substituted with the reference.
(root/'actual-independent-native.svg').write_bytes(svg)
proof={'head':head,'checkout':actual,'base':base,'tree':git('rev-parse',actual+'^{tree}').decode().strip(),'canonical_inputs':len(r['source_sha256']),'copied_inputs':len(r['fixture_source_sha256']),'generated_inputs':len(r['generated_sha256']),'compiled_roles':75,'all_three_bundles_captured':True,'all_six_actual_resources_byte_equal':True,'unchanged_shipped_D2_asset':True,'provider_permissions_exact':True,'raw_native_cases':2,'passed':2,'failed':0,'skipped':0,'expected_failures':0,'diagnostic_only':True,'qualification_candidate':False,'actual_native_SVG_bytes':len(svg),'actual_native_SVG_sha256':sha(svg),'actual_native_record_bytes':len(raw),'untruncated_parts':len(parts),'actual_39byte_async_control':control,'hosted_node_reference_valid':True,'native_seconds':native['observed_uptime']-native['started_uptime'],'OS':r['os'],'observer_generations':len(generations),'live_direct_and_actual_UI_attachment_bytes_exact':True,'control_nonce_correlated':True,'no_forced_cleanup':True,'scope':'Actual unchanged D2 fixed-input JavaScriptCore/Finder compatibility and real asynchronous run-loop diagnostic with exact sandbox/user-selected-read-only. No isolated/preemptible worker, untrusted-work deadline/fallback, physical retirement, product fidelity/performance, production or full QL-REPLY acceptance.'}
(root/'native-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
