import hashlib,importlib.util,json,pathlib,subprocess,sys,zipfile
root=pathlib.Path(__file__).parent;a=root/'42426662604-first-artifact/pdf-pagination-app-tests-Release';repo='/Volumes/Fast SSD/CORTANA-GitHub/mostlytext';head='6cad56275c1d9a71a9ee95daa066bd1fcae68965';actual='a0b06507e4a721ffb84c98c45824c21bf26849c7';base='324155cc9cfb45116d32a2a05c2f0d392507ecea';git=lambda *v:subprocess.check_output(['git',*v],cwd=repo);sha=lambda b:hashlib.sha256(b).hexdigest()
r=json.loads((a/'receipt.json').read_bytes());assert r['checkout']==actual and git('show','-s','--format=%P',actual).decode().split()==[base,head]
assert len(r['source_sha256'])==1625
for p,h in r['source_sha256'].items():assert sha(git('show',actual+':'+p))==h,p
assert r['pins']==json.loads(git('show',actual+':MacDown2/Packages/MacDownKit/Package.resolved'))['pins'] and len(r['pins'])==24
compiled=json.loads((a/'compiled-initial.json').read_bytes());assert compiled['configuration']=='Release' and compiled['phase']=='initial'
for row in compiled['inputs'].values():
 data=(a/row['blob']).read_bytes();assert len(data)==row['bytes'] and sha(data)==row['sha256']
scripts='/Volumes/Fast SSD/CORTANA-GitHub/worktrees/github/mostlytext-html-preview-accessibility/.github/scripts';sys.path.insert(0,scripts);spec=importlib.util.spec_from_file_location('pdf',scripts+'/verify-pdf-pagination-probe.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
for p in ['.github/scripts/verify-pdf-pagination-probe.py','.github/scripts/preview_compiled_inputs.py']:assert sha(pathlib.Path('/Volumes/Fast SSD/CORTANA-GitHub/worktrees/github/mostlytext-html-preview-accessibility',p).read_bytes())==r['source_sha256'][p]
status=json.loads((a/'diagnostics/status.json').read_bytes());identity=json.loads((a/'diagnostics/identity.json').read_bytes());assert identity['checkout']==actual;m.validate_execution((a/'probe.log').read_text(),identity,status)
raw=subprocess.check_output(['xcrun','xcresulttool','get','test-results','summary','--path',str(a/'actual-pdf.xcresult')]);m.validate_summary(json.loads(raw));(root/'pdf-actual-independent-summary.json').write_bytes(raw)
run=json.loads((root/'42426662604-first-run.json').read_bytes());assert run['head_sha']==head and run['run_attempt']==1 and run['conclusion']=='success'
with zipfile.ZipFile(root/'42426662604-complete-first-workflow-logs.zip') as z:assert z.testzip() is None
proof={'source':head,'actual_checkout':actual,'actual_parents':[base,head],'canonical_source_bindings':1625,'pins':24,'downloaded_actual_compiled_roles':len(compiled['inputs']),'actual_original_native_functions':'9PASS/1suite/0skip/0expected/0failure; actual raw result independently exported','actual_owned_status':status,'scope':'Qualified exact nine-function PDF lane only, not entire frozen14-workflow preview candidate; that candidate remains failed/pending and unchanged.'};(root/'pdf-first-independently-verified.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof)
